package main

import (
	"fmt"
	"github.com/BurntSushi/toml"
	"io/ioutil"
)

type LogLevel string

type Certificate struct {
	Cert string
	Key  string
}

type Upstream struct {
	SNI   string
	Proto string
	Addr  string
}

type Config struct {
	LogLevel     LogLevel
	MinTLSVer	 string
	Upstreams    []Upstream
	Certificates []Certificate
}

func LoadConfigFromFile(filename string) (*Config, error) {
	var confData []byte
	var err error
	confData, err = ioutil.ReadFile(filename)
	if err != nil {
		return nil, fmt.Errorf("Failed to read config file %v: %v", filename, err)
	}
	var conf *Config
	conf, err = LoadConfig(confData)
	if err != nil {
		return nil, err
	}
	return conf, nil
}

func LoadConfig(confData []byte) (*Config, error) {
	var conf = &Config{}
	var err error
	err = toml.Unmarshal(confData, conf)
	if err != nil {
		return nil, fmt.Errorf("Failed to load config: %v", err)
	}
	return conf, nil
}
