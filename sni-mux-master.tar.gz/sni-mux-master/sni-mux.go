package main

import (
	"flag"
	"log"
	"net"
)

var confFile = flag.String("c", "./conf.toml", "path to conf")
var listen = flag.String("l", "0.0.0.0:443", "the address to listen on")

func main() {
	flag.Parse()
	var conf *Config
	var err error
	conf, err = LoadConfigFromFile(*confFile)
	if err != nil {
		log.Fatal(err)
	}
	var renderedConf *RenderedConfig
	renderedConf, err = RenderConfig(conf)
	if err != nil {
		log.Fatal(err)
	}
	var handler = &Handler{RenderedConfig: renderedConf}
	var lis net.Listener
	lis, err = net.Listen("tcp", *listen)
	if err != nil {
		log.Fatal(err)
	}
	for {
		var conn net.Conn
		conn, err = lis.Accept()
		if err != nil {
			log.Println(err)
			continue
		}
		go func() {
			var err error
			err = handler.Handle(conn)
			if err != nil {
				log.Println(err)
			}
		}()
	}
}
