package main

import (
	"crypto/ed25519"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"fmt"
	"math/big"
	"net"
	"time"
)

type LogLevelT int

const (
	INFO LogLevelT = iota
	DEBUG
)

type Dialer struct {
	Type       string
	Network    string
	Addr       string
	RealDialer *net.Dialer
	TLSConf    *tls.Config
}

func (d *Dialer) Dial() (net.Conn, error) {
	switch d.Type {
	case "tcp":
		return d.RealDialer.Dial(d.Network, d.Addr)
	case "tls":
		return tls.DialWithDialer(d.RealDialer, d.Network, d.Addr, d.TLSConf)
	default:
		return nil, fmt.Errorf("Unrecognized dialer type: %v", d.Type)
	}
}

type RenderedConfig struct {
	LogLevel LogLevelT
	Upstream map[string]*Dialer
	TLSConf  *tls.Config
}

func RenderConfig(conf *Config) (*RenderedConfig, error) {
	var renderedConf = &RenderedConfig{}
	renderedConf.Upstream = make(map[string]*Dialer)

	renderedConf.TLSConf = &tls.Config{}
	switch conf.MinTLSVer {
	case "1.2":
		renderedConf.TLSConf.MinVersion = tls.VersionTLS12
	case "1.3":
		renderedConf.TLSConf.MinVersion = tls.VersionTLS13
	default:
		return nil, fmt.Errorf("Unrecognized TLS version: %v", conf.MinTLSVer)
	}

	switch conf.LogLevel {
	case "INFO":
		renderedConf.LogLevel = INFO
	case "DEBUG":
		renderedConf.LogLevel = DEBUG
	default:
		return nil, fmt.Errorf("Unrecognized LogLevel: %v", conf.LogLevel)
	}
	for index, upstream := range conf.Upstreams {
		var realDialer = &net.Dialer{} //Using the default dialer for now, tweaks may follow
		switch upstream.Proto {
		case "tcp":
			renderedConf.Upstream[upstream.SNI] = &Dialer{
				Type:       "tcp",
				Network:    "tcp",
				Addr:       upstream.Addr,
				RealDialer: realDialer,
				TLSConf:    nil,
			}
		case "tls":
			var tlsConf = &tls.Config{
				MinVersion: tls.VersionTLS12,
			}
			renderedConf.Upstream[upstream.SNI] = &Dialer{
				Type:       "tls",
				Network:    "tcp",
				Addr:       upstream.Addr,
				RealDialer: realDialer,
				TLSConf:    tlsConf,
			}
		default:
			return nil, fmt.Errorf("Unrecognized upstream proto: %v in upstream %v", upstream.Proto, index)
		}
	}
	for index, certificate := range conf.Certificates {
		var cert tls.Certificate
		var err error
		cert, err = tls.LoadX509KeyPair(certificate.Cert, certificate.Key)
		if err != nil {
			return nil, fmt.Errorf("Failed to load certficate from %v and %v in certificate %v",
				certificate.Cert, certificate.Key, index)
		}
		renderedConf.TLSConf.Certificates = append(renderedConf.TLSConf.Certificates, cert)
	}

	if len(renderedConf.TLSConf.Certificates) == 0 {
		var cert *tls.Certificate
		var err error
		cert, err = GenCert()
		if err != nil {
			return nil, fmt.Errorf("No certificate configured and failed to self-gen cert: %v", err)
		}
		renderedConf.TLSConf.Certificates = append(renderedConf.TLSConf.Certificates, *cert)
	}

	renderedConf.TLSConf.BuildNameToCertificate()
	return renderedConf, nil
}

func GenCert() (*tls.Certificate, error) {
	serialNumber, err := rand.Int(rand.Reader, new(big.Int).Lsh(big.NewInt(1), 128))
	if err != nil {
		return nil, fmt.Errorf("Failed to generate serial number: %v", err)
	}
	template := x509.Certificate{
		SerialNumber: serialNumber,
		Subject: pkix.Name{
			Organization: []string{"sni-mux self-generated cert"},
		},
		NotBefore:             time.Now(),
		NotAfter:              time.Now().Add(365 * 24 * time.Hour),
		KeyUsage:              x509.KeyUsageKeyEncipherment | x509.KeyUsageDigitalSignature,
		ExtKeyUsage:           []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		BasicConstraintsValid: true,
	}
	pub, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		return nil, fmt.Errorf("Failed to generate private key: %v", err)
	}
	cert, err := x509.CreateCertificate(rand.Reader, &template, &template, pub, priv)
	if err != nil {
		return nil, fmt.Errorf("Failed to create certificate: %v", err)
	}

	privEncoded, err := x509.MarshalPKCS8PrivateKey(priv)
	if err != nil {
		return nil, fmt.Errorf("Unable to marshal private key: %v", err)
	}

	keypair, err := tls.X509KeyPair(pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: cert}),
		pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: privEncoded}))
	if err != nil {
		return nil, fmt.Errorf("Failed to create keypair: %v", err)
	}
	return &keypair, nil
}
