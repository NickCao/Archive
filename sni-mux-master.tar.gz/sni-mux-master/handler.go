package main

import (
	"crypto/tls"
	"fmt"
	"io"
	"log"
	"net"
)

type Handler struct {
	RenderedConfig *RenderedConfig
}

func (h *Handler) Handle(conn net.Conn) error {
	var tlsConn *tls.Conn
	var err error
	tlsConn = tls.Server(conn, h.RenderedConfig.TLSConf)
	err = tlsConn.Handshake()
	if err != nil {
		tlsConn.Close()
		return fmt.Errorf("Failed to handshake: %v", err)
	}
	var dialer *Dialer
	var ok bool
	dialer, ok = h.RenderedConfig.Upstream[tlsConn.ConnectionState().ServerName]
	if !ok {
		tlsConn.Close()
		return fmt.Errorf("No upstream configured for servername: %v", tlsConn.ConnectionState().ServerName)
	}
	if h.RenderedConfig.LogLevel >= DEBUG {
		log.Printf("Forwarding to %v %v for %v", dialer.Type, dialer.Addr, tlsConn.ConnectionState().ServerName)
	}
	var upstreamConn net.Conn
	upstreamConn, err = dialer.Dial()
	if err != nil {
		tlsConn.Close()
		return fmt.Errorf("Failed to dial upstream: %v: %v", dialer.Addr, err)
	}
	go Forward(tlsConn, upstreamConn)
	return nil
}

func Forward(conn0 net.Conn, conn1 net.Conn) {
	go func() {
		defer conn0.Close()
		io.Copy(conn0, conn1)
	}()
	go func() {
		defer conn1.Close()
		io.Copy(conn1, conn0)
	}()
}
