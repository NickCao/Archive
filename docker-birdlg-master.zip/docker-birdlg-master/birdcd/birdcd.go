package main

import (
	"bufio"
	"flag"
	"fmt"
	"github.com/gin-gonic/gin"
	"log"
	"net"
	"net/http"
	"regexp"
)

var EOFFilter = regexp.MustCompile("^\\d{4}\\s.*$")
var CodeFilter = regexp.MustCompile("^\\d{4}")
var QueryFilter = regexp.MustCompile("^(|(show|eval)\\s.*)$")

var laddr = flag.String("l", ":9090", "address to listen on")
var caddr = flag.String("c", "/run/bird.ctl", "bird control socket to connect to")

var ErrInternal = []byte("8009 Internal error\n")
var ErrConnection = []byte("8008 Connection failed\n")
var ErrForbidden = []byte("8007 Access denied\n")

func main() {
	flag.Parse()
	gin.SetMode(gin.ReleaseMode)
	router := gin.Default()
	router.GET("/bird-query", handle)
	err := router.Run(*laddr)
	if err != nil {
		log.Fatal(err)
	}
}

func handle(c *gin.Context) {
	command := c.DefaultQuery("command", "")
	if !QueryFilter.MatchString(command) {
		c.Data(http.StatusForbidden, "text/plain", ErrForbidden)
		return
	}

	upstream, err := net.Dial("unix", *caddr)
	if err != nil {
		_ = c.Error(err)
		c.Data(http.StatusInternalServerError, "text/plain", ErrConnection)
		return
	}
	defer upstream.Close()
	scanner := bufio.NewScanner(upstream)

	if !scanner.Scan() || CodeFilter.FindString(scanner.Text()) != "0001" {
		c.Data(http.StatusInternalServerError, "text/plain", ErrInternal)
		return
	}

	if command == "" {
		c.Data(http.StatusOK, "text/plain", append(scanner.Bytes(), byte('\n')))
		return
	}

	_, err = fmt.Fprintln(upstream, "restrict")
	if err != nil {
		_ = c.Error(err)
		c.Data(http.StatusInternalServerError, "text/plain", ErrInternal)
		return
	}

	if !scanner.Scan() || CodeFilter.FindString(scanner.Text()) != "0016" {
		c.Data(http.StatusInternalServerError, "text/plain", ErrInternal)
		return
	}

	_, err = fmt.Fprintln(upstream, command)
	if err != nil {
		_ = c.Error(err)
		c.Data(http.StatusInternalServerError, "text/plain", ErrInternal)
		return
	}

	for scanner.Scan() {
		_, err := fmt.Fprintln(c.Writer, scanner.Text())
		if err != nil {
			_ = c.Error(err)
			return
		}
		if EOFFilter.MatchString(scanner.Text()) {
			break
		}
	}
	return
}
