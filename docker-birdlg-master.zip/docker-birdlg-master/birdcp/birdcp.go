package main

import (
	"bufio"
	"flag"
	"fmt"
	"gopkg.in/yaml.v2"
	"io"
	"io/ioutil"
	"log"
	"net"
	"net/http"
	"regexp"
	"strconv"
	"strings"
	"sync/atomic"
	"syscall"
)

var listenAddr = flag.String("l", "@bird.ctl", "unix socket to listen on")
var config = flag.String("c", "/etc/birdcp.yaml", "list of birds")

var ConfigureMatcher = regexp.MustCompile("^configure.*")
var ConfigureFilter = regexp.MustCompile("^configure\\s\\d+")

var birdsIndex atomic.Value
var birds []struct {
	Endpoint string `yaml:"endpoint"`
	Name     string `yaml:"name"`
	Desc     string `yaml:"desc"`
}

func main() {
	birdsIndex.Store(0)
	flag.Parse()
	data, err := ioutil.ReadFile(*config)
	if err != nil {
		log.Fatal(err)
	}
	err = yaml.Unmarshal(data, &birds)
	if err != nil {
		log.Fatal(err)
	}
	if len(birds) == 0 {
		log.Fatal("no bird configured")
	}

	_ = syscall.Unlink(*listenAddr)
	lis, err := net.Listen("unix", *listenAddr)
	if err != nil {
		log.Fatal(err)
	}

	defer lis.Close()
	for {
		conn, err := lis.Accept()
		if err != nil {
			log.Println(err)
		}
		go handle(conn)
	}
}

func usage(index int) string {
	var u = "0001 BIRD looking glass ready\n"
	u += "0001 INDEX\tNAME\tDESC\n"
	for i, b := range birds {
		if i == index {
			u += fmt.Sprintf("0001 [%d]\t%s\t%s\n", i, b.Name, b.Desc)
		} else {
			u += fmt.Sprintf("0001 %d\t%s\t%s\n", i, b.Name, b.Desc)
		}
	}
	u += "0001 Usage: configure [INDEX]\n"
	return u
}

func handle(conn net.Conn) {
	defer conn.Close()
	_, err := fmt.Fprint(conn, usage(birdsIndex.Load().(int)))
	if err != nil {
		return
	}
	scanner := bufio.NewScanner(conn)
	client := http.Client{}

	for scanner.Scan() {
		if ConfigureMatcher.MatchString(scanner.Text()) {
			if !ConfigureFilter.MatchString(scanner.Text()) {
				_, err = fmt.Fprint(conn, "8009 Syntax Error\n")
				if err != nil {
					log.Println(err)
					return
				}
				continue
			}

			newIndex, err := strconv.Atoi(strings.Split(scanner.Text(), " ")[1])
			if err != nil || newIndex < 0 || newIndex >= len(birds) {
				_, err = fmt.Fprint(conn, "8009 Invalid Index\n")
				if err != nil {
					log.Println(err)
					return
				}
				continue
			}
			birdsIndex.Store(newIndex)
			_, err = fmt.Fprint(conn, "8009 Connection Configured\n")
			if err != nil {
				log.Println(err)
				return
			}
			continue
		}

		req, err := http.NewRequest("GET", birds[birdsIndex.Load().(int)].Endpoint, nil)
		if err != nil {
			_, err = fmt.Fprint(conn, "8009 Internal Error\n")
			if err != nil {
				log.Println(err)
				return
			}
			continue
		}

		query := req.URL.Query()
		query.Set("command", scanner.Text())
		req.URL.RawQuery = query.Encode()

		resp, err := client.Do(req)
		if err != nil {
			_, err = fmt.Fprint(conn, "8009 Internal Error\n")
			if err != nil {
				log.Println(err)
				return
			}
			continue
		}

		_, err = io.Copy(conn, resp.Body)
		if err != nil {
			resp.Body.Close()
			_, err = fmt.Fprint(conn, []byte("8009 Internal Error\n"))
			if err != nil {
				log.Println(err)
				return
			}
			continue
		}
		resp.Body.Close()
	}
}
