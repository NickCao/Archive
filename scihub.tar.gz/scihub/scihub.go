package main

import (
	"database/sql"
	"encoding/base64"
	"github.com/avct/uasurfer"
	_ "github.com/go-sql-driver/mysql"
	"github.com/labstack/echo/v4"
	"github.com/labstack/echo/v4/middleware"
	"html/template"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"time"
)

var doiRegex = regexp.MustCompile(`(10\.\d{4,5}/[\d\:\.\,\(\)\;\[\]\_\<\>\&\-\+\/\\a-zA-Z]{1,200})`)
var pmidRegex = regexp.MustCompile(`([0-9]{1,8})`)

func main() {
	e := echo.New()
	e.Use(middleware.Logger())
	e.Renderer = &Template{template.Must(template.ParseGlob("templates/*.html"))}

	var db *sql.DB
	var err error
	if db, err = sql.Open("mysql", "root:473028c7abd49fbf@/scimag"); err != nil {
		e.Logger.Fatal(err)
	}
	db.SetConnMaxLifetime(time.Minute * 3)
	db.SetMaxOpenConns(100)
	db.SetMaxIdleConns(10)

	e.GET("/", func(ctx echo.Context) error {
		ua := uasurfer.Parse(ctx.Request().Header.Get("User-Agent"))
		if ua.DeviceType == uasurfer.DevicePhone {
			return ctx.Render(http.StatusOK, "index-m.html", nil)
		}
		return ctx.Render(http.StatusOK, "index.html", nil)
	})

	e.POST("/", func(ctx echo.Context) error {
		req := ctx.FormValue("request")
		if req == "" {
			return ctx.Redirect(http.StatusFound, "/")
		}

		var row *sql.Row
		if d := doiRegex.FindString(req); d != "" {
			row = db.QueryRow(`SELECT DOI FROM scimag WHERE ( DOI = ? OR DOI2 = ? )`, d, d)
		} else if d := pmidRegex.FindString(req); d != "" {
			row = db.QueryRow(`SELECT DOI FROM scimag WHERE ( pubmedid = ? OR DOI = ? )`, d, "10.0000/PMID"+d)
		} else {
			row = db.QueryRow(`SELECT DOI FROM scimag WHERE MATCH(Title) AGAINST('» +?»' IN BOOLEAN MODE)`, req)
		}

		if row != nil {
			var doi string
			if err = row.Scan(&doi); err == nil {
				return ctx.Redirect(http.StatusFound, "/"+doi)
			}
		}

		return ctx.String(http.StatusNotFound, "article not found")
	})

	e.GET("/*", func(ctx echo.Context) error {
		row := db.QueryRow(`SELECT DOI,Author,Year,Title,Journal,Volume,Issue,First_page,Last_page FROM scimag WHERE DOI = ?`, ctx.Request().URL.Path[1:])
		if row != nil {
			var doi, author, year, title, journal, volume, issue, first_page, last_page string
			if err = row.Scan(&doi, &author, &year, &title, &journal, &volume, &issue, &first_page, &last_page); err == nil {
				pdf := "https://sci.bban.top/pdf/" + encode(doi) + ".pdf"
				resp, err := http.Head(pdf)
				if err != nil || resp.StatusCode != http.StatusOK {
					//pdf = "https://dacemirror.sci-hub.do/journal-article/" + fmt.Sprintf("%x", md5.Sum([]byte(doi))) + "/" + year + ".pdf"
					pdf = "https://cyber.sci-hub.se/" + base64.StdEncoding.EncodeToString([]byte(strings.ToLower(doi))) + "/" + strings.ReplaceAll(url.PathEscape(doi), "%2F", "%40") + ".pdf"

				}

				m := map[string]string{
					"DOI":        doi,
					"Author":     author,
					"Year":       year,
					"Title":      title,
					"Journal":    journal,
					"Volume":     volume,
					"Issue":      issue,
					"First_page": first_page,
					"Last_page":  last_page,
					"PDF":        pdf,
				}
				return ctx.Render(http.StatusOK, "pdf.html", m)
			}
		}

		return ctx.String(http.StatusNotFound, "article not found")
	})

	e.Logger.Fatal(e.Start("127.0.0.1:8080"))
}
