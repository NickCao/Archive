package main

import (
	"github.com/labstack/echo/v4"
	"html/template"
	"io"
	"net/url"
	"strings"
)

type Template struct {
	templates *template.Template
}

func (t *Template) Render(w io.Writer, name string, data interface{}, c echo.Context) error {
	return t.templates.ExecuteTemplate(w, name, data)
}

func encode(s string) string{
	return strings.ReplaceAll(url.QueryEscape(strings.ReplaceAll(url.QueryEscape(s),"%2F","/")),"%2F","/")
}