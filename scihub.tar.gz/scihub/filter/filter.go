package main

import (
	"bytes"
	"flag"
	"fmt"
	"github.com/PuerkitoBio/goquery"
	"io/ioutil"
	"log"
	"net/http"
	"net/http/httputil"
	"net/url"
)

var listen = flag.String("L", "", "listen address")
var forward = flag.String("F", "", "forward address")

func main() {
	flag.Parse()
	log.Fatal(http.ListenAndServe(*listen, &httputil.ReverseProxy{
		Director: func(request *http.Request) {
			request.URL.Scheme = "https"
			request.URL.Host = request.Host
			if _, ok := request.Header["User-Agent"]; !ok {
				request.Header.Set("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36")
			}
			request.Header.Set("X-Forwarded-For","")
		},
		Transport: &http.Transport{Proxy: func(r *http.Request) (*url.URL, error) {
			p, err := url.Parse(*forward)
			if err != nil {
				log.Println(err)
			}
			return p, err
		}},
		ModifyResponse: func(response *http.Response) error {
			//log.Printf("%#v", response.Request)
			if loc, err := response.Location(); err == nil {
				if loc.Host != response.Request.URL.Host {
					return fmt.Errorf("重定向到了第三方站点: %s", loc.String())
				}
				return nil
			}

			body, err := ioutil.ReadAll(response.Body)
			if err != nil {
				return err
			}
			response.Body.Close()
			response.Body = ioutil.NopCloser(bytes.NewBuffer(body))

			doc, err := goquery.NewDocumentFromReader(bytes.NewBuffer(body))
			if err != nil {
				return fmt.Errorf("不是合法html: %s", response.Request.URL.Path)
			}

			/*
				if strings.HasPrefix(string(body), "статья не найдена / article not found") {
					return fmt.Errorf("未找到结果页面: %s, %s", response.Request.URL.Path, response.Request.PostForm.Encode())
				}

				if title := doc.Find("head > title").First(); title != nil {
					if title.Text() == "Science Journals catalog" ||
						title.Text() == "search is temporarily unavailable" ||
						title.Text() == "Для просмотра статьи разгадайте капчу" {
						return fmt.Errorf("搜索不可用页面或屏蔽页面: %s, %s", response.Request.URL.Path, response.Request.PostForm.Encode())
					}
				}
			*/
			if pdf := doc.Find("#pdf").Length(); pdf != 0 {
				return nil
			}
			return fmt.Errorf("页面中无pdf: %s", response.Request.URL.Path)
		},
	}))
}
