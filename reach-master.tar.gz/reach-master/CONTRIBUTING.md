0.Contributing directly to the master branch is not accepted,
  merge requests are welcomed.
  
1.The functionality and moduality are valued more than the quality.

2.Happy hacking.