package buyer

import (
	"context"
	"scraper/prober"
	"scraper/solver"
	"time"
)

type BuyerManager struct {
	Servers  []string
	Serial   string
	Sid      string
	Interval time.Duration
	buyers   []*Buyer
}

func NewBuyerManager(servers []string, serial, sid string) *BuyerManager {
	return &BuyerManager{
		Servers: servers,
		Serial:  serial,
		Sid:     sid,
	}
}

func (m *BuyerManager) Wait(ctx context.Context, solver *solver.Solver, p *prober.ProberManager) error {
	go solver.Poll(ctx)
	for _, s := range m.Servers {
		b, err := NewBuyer(s, m.Serial, m.Sid)
		if err != nil {
			return err
		}
		m.buyers = append(m.buyers, b)
	}
	if p.Wait(ctx) {
		for _, b := range m.buyers {
			err := b.SendRequest(solver.Get())
			if err != nil {
				continue
			} else {
				break
			}
		}
	}
	return nil
}
