package buyer

import (
	"context"
	"errors"
	"fmt"
	"github.com/silenceper/pool"
	"go.uber.org/zap"
	"io/ioutil"
	"net"
	"net/http"
	"os"
	"strings"
	"time"
)

const buyURL = "http://tl.cyg.changyou.com/transaction/buy"

type Buyer struct {
	Serial string
	Sid    string
	client *http.Client
}

func NewBuyer(server, serial, sid string) (*Buyer, error) {
	p, err := pool.NewChannelPool(&pool.Config{
		InitialCap:  5,
		MaxCap:      10,
		MaxIdle:     10,
		Factory:     func() (interface{}, error) { return net.Dial("tcp", server) },
		Close:       func(v interface{}) error { return v.(net.Conn).Close() },
		IdleTimeout: 5 * time.Second,
	})
	if err != nil {
		return nil, err
	}
	return &Buyer{
		Serial: serial,
		Sid:    sid,
		client: &http.Client{
			Transport: &http.Transport{
				DialContext: func(ctx context.Context, _, _ string) (net.Conn, error) {
					conn, err := p.Get()
					if err != nil {
						return nil, err
					}
					return conn.(net.Conn), nil
				},
			},
		},
	}, nil
}

func (p *Buyer) SendRequest(captcha string) error {
	logger := zap.S().Named("buyer.Buyer.SendRequest")
	logger.Infof("buy request started for %s", p.Serial)

	req, err := http.NewRequest("POST", buyURL, strings.NewReader(fmt.Sprintf("captcha_code=%s&goods_serial_num=%s", captcha, p.Serial)))
	if err != nil {
		logger.Errorf("buy request failed for %s, error %s", p.Serial, err)
		return err
	}

	req.AddCookie(&http.Cookie{Name: "sid", Value: p.Sid})
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	resp, err := p.client.Do(req)
	if err != nil {
		logger.Errorf("buy request failed for %s, error %s", p.Serial, err)
		return err
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		logger.Errorf("buy request failed for %s, error %s", p.Serial, err)
		return err
	}

	logger.Infof("buy request succeeded for %s, result %s", p.Serial, string(body))

	f, err := os.OpenFile(p.Serial+".log", os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
	if err != nil {
		logger.Errorf("failed to open log file for %s, error %s", p.Serial, err)
		return err
	}
	_, _ = f.Write(append(body, byte('\n')))

	if !strings.Contains(string(body), "success") {
		return errors.New("buy failed")
	}

	return nil
}
