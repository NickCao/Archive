package prober

import (
	"bufio"
	"context"
	"fmt"
	"go.uber.org/zap"
	netproxy "golang.org/x/net/proxy"
	"math/rand"
	"net"
	"net/http"
	"strings"
	"time"
)

const probeURL = "http://tl.cyg.changyou.com/goods/char_detail?serial_num=%s"

type Prober struct {
	Interval time.Duration
	Serial   string
	client   *http.Client
}

func NewProber(server, proxy, serial string, interval time.Duration) (*Prober, error) {
	logger := zap.S().Named("prober.NewProber")
	dialer, err := netproxy.SOCKS5("tcp", proxy, nil, netproxy.Direct)
	if err != nil {
		logger.Errorf("failed to initialize prober for %s, error %s", serial, err)
		return nil, err
	}

	logger.Infof("prober initialized for %s", serial)
	return &Prober{
		client: &http.Client{
			Transport: &http.Transport{
				DialContext: func(ctx context.Context, _, _ string) (net.Conn, error) {
					return dialer.Dial("tcp", server)
				},
			},
		},
		Interval: interval,
		Serial:   serial,
	}, nil
}

func (p *Prober) Probe() bool {
	logger := zap.S().Named("prober.Prober.Probe")

	resp, err := p.client.Get(fmt.Sprintf(probeURL, p.Serial))
	if err != nil {
		logger.Errorf("probe failed for %s, error %s", p.Serial, err)
		return false
	}
	defer resp.Body.Close()

	scanner := bufio.NewScanner(resp.Body)
	for scanner.Scan() {
		if strings.Contains(scanner.Text(), "立即购买") {
			logger.Infof("probe succeeded for %s, result true", p.Serial)
			return true
		}
	}
	logger.Infof("probe succeeded for %s, result false", p.Serial)
	return false
}

func (p *Prober) Poll(ctx context.Context, cancel context.CancelFunc, event chan struct{}) {
	logger := zap.S().Named("prober.Prober.Poll")
	logger.Infof("poll started for %s, interval %s", p.Serial, p.Interval)
	defer cancel()

	for <-time.After(time.Duration(rand.Intn(int(p.Interval)))); true; <-time.Tick(p.Interval) {
		select {
		case <-ctx.Done():
			logger.Infof("poll canceled for %s", p.Serial)
			return
		default:
			if p.Probe() {
				logger.Infof("poll succeeded for %s", p.Serial)
				select {
				case event <- struct{}{}:
				default:
				}
				return
			}
		}
	}
}
