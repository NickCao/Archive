package prober

import (
	"context"
	"time"
)

type ProberManager struct {
	Servers  []string
	Proxies  []string
	Serial   string
	Interval time.Duration
}

func NewProberManager(servers, proxies []string, serial string) *ProberManager {
	return &ProberManager{
		Servers:  servers,
		Proxies:  proxies,
		Serial:   serial,
		Interval: time.Second * 2,
	}
}

func (m *ProberManager) Start(ctx context.Context, event chan struct{}) error {
	ctx, cancel := context.WithCancel(ctx)
	for _, s := range m.Servers {
		for _, p := range m.Proxies {
			prober, err := NewProber(s, p, m.Serial, m.Interval)
			if err != nil {
				return err
			}
			go prober.Poll(ctx, cancel, event)
		}
	}
	return nil
}

func (m *ProberManager) Wait(ctx context.Context) bool {
	event := make(chan struct{})
	err := m.Start(ctx, event)
	if err != nil {
		return false
	}
	select {
	case <-ctx.Done():
		return false
	case <-event:
		return true
	}
}
