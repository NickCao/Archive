package main

import (
	"bufio"
	"bytes"
	"io/ioutil"
)

func LoadAddrList(file string) ([]string, error) {
	data, err := ioutil.ReadFile(file)
	if err != nil {
		return nil, err
	}
	scanner := bufio.NewScanner(bytes.NewBuffer(data))
	var arr []string
	for scanner.Scan() {
		arr = append(arr, scanner.Text())
	}
	return arr, nil
}
