package solver

import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"go.uber.org/zap"
	"io/ioutil"
	"net/http"
	"time"
)

const captchaURL = "http://tl.cyg.changyou.com/transaction/captcha-image?goods_serial_num=%s"
const solverURL = "http://%s/captcha/v1"

type Solver struct {
	Serial     string
	Sid        string
	SolverAddr string
	Captcha    string
	Interval   time.Duration
}

func NewSolver(serial, sid, solver string, interval time.Duration) *Solver {
	return &Solver{
		Serial:     serial,
		Sid:        sid,
		SolverAddr: solver,
		Interval:   interval,
	}
}

func (s *Solver) Get() string {
	return s.Captcha
}

func (s *Solver) Solve() error {
	logger := zap.S().Named("solver.Solver.Solve")

	req, err := http.NewRequest("GET", fmt.Sprintf(captchaURL, s.Serial), nil)
	if err != nil {
		logger.Errorf("solve failed for %s, stage %s, error %s", s.Serial, "new captcha image request", err)
		return err
	}
	req.AddCookie(&http.Cookie{Name: "sid", Value: s.Sid})

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		logger.Errorf("solve failed for %s, stage %s, error", s.Serial, "request captcha image", err)
		return err
	}
	defer resp.Body.Close()

	image, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		logger.Errorf("solve failed for %s, stage %s, error", s.Serial, "read captcha image", err)
		return err
	}

	var payload = bytes.NewBuffer(nil)
	err = json.NewEncoder(payload).Encode(struct {
		Image string `json:"image"`
	}{
		base64.StdEncoding.EncodeToString(image),
	})
	if err != nil {
		logger.Errorf("solve failed for %s, stage %s, error", s.Serial, "encode captcha image", err)
		return err
	}

	resp2, err := http.Post(fmt.Sprintf(solverURL, s.SolverAddr), "application/json", payload)
	if err != nil {
		logger.Errorf("solve failed for %s, stage %s, error", s.Serial, "request solver api", err)
		return err
	}
	defer resp2.Body.Close()

	var res = struct {
		Message string `json:"message"`
	}{}
	err = json.NewDecoder(resp2.Body).Decode(&res)
	if err != nil {
		logger.Errorf("solve failed for %s, stage %s, error", s.Serial, "decode solver api response", err)
		return err
	}

	logger.Infof("solve succeeded for %s, result %s", s.Serial, res.Message)
	s.Captcha = res.Message
	return nil
}

func (s *Solver) Poll(ctx context.Context) {
	logger := zap.S().Named("solver.Solver.Poll")
	logger.Infof("poll started for %s, interval %s", s.Serial, s.Interval)

	for ; true; <-time.Tick(s.Interval) {
		select {
		case <-ctx.Done():
			logger.Infof("poll canceled for %s", s.Serial)
			return
		default:
			err := s.Solve()
			if err != nil {
				logger.Errorf("poll encountered recoverable error for %s, error %s", s.Serial, err)
				continue
			}
		}
	}
}
