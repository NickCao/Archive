package main

import (
	"context"
	"flag"
	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
	"log"
	"net/http"
	"scraper/buyer"
	"scraper/prober"
	"scraper/solver"
	"time"
)

var servers, proxies []string
var solverAddr = flag.String("solver", "152.136.53.193:19952", "验证码接口地址")
var listenAddr = flag.String("listen", "0.0.0.0:31245", "监听地址")

var cancelers = make(map[string]context.CancelFunc)

func main() {
	flag.Parse()

	logger, err := zap.NewDevelopment()
	if err != nil {
		log.Fatal("无法创建logger")
	}
	zap.ReplaceGlobals(logger)

	servers, err = LoadAddrList("servers")
	if err != nil {
		log.Fatal(err)
	}
	proxies, err = LoadAddrList("proxies")
	if err != nil {
		log.Fatal(err)
	}

	engine := gin.New()
	engine.Use(gin.Logger())
	engine.GET("/submit", Handler)
	err = engine.Run(*listenAddr)
	if err != nil {
		log.Fatal("无法启动服务")
	}
}

func Handler(ctx *gin.Context) {
	if ctx.Query("sid") == "" || ctx.Query("serial") == "" {
		ctx.String(http.StatusBadRequest, "请求格式错误, 需要参数 serial, sid\n")
		return
	}

	if c, ok := cancelers[ctx.Query("serial")]; ok {
		c()
		delete(cancelers, ctx.Query("serial"))
	}

	go func() {
		s := solver.NewSolver(ctx.Query("serial"), ctx.Query("sid"), *solverAddr, time.Second*30)
		p := prober.NewProberManager(servers, proxies, ctx.Query("serial"))
		b := buyer.NewBuyerManager(servers, ctx.Query("serial"), ctx.Query("sid"))
		c, cancel := context.WithTimeout(context.Background(), time.Minute*45)
		cancelers[ctx.Query("serial")] = cancel
		_ = b.Wait(c, s, p)
		cancel()
		delete(cancelers, ctx.Query("serial"))
	}()

	ctx.String(http.StatusOK, "请求提交成功\n")
	return
}
