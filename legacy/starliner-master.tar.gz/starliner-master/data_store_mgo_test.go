package starliner

import (
	"testing"

	"github.com/mongodb/mongo-go-driver/bson"
)

var testurl = "mongodb+srv://user:pass@cluster0-mo7k5.mongodb.net/test?retryWrites=true"

func TestMongoDBDataStore(t *testing.T) {
	p, err := NewPost("NickCao", []string{"test1", "case1"}, "asfefwef")
	if err != nil {
		t.Fatal(err)
	}
	ds, err := NewMongoDBDataStore(testurl)
	if err != nil {
		t.Fatal(err)
	}
	err = ds.Init()
	if err != nil {
		t.Fatal(err)
	}
	defer ds.Close()
	id, err := ds.Commit(p)
	if err != nil {
		t.Fatal(err)
	}
	p, err = ds.Fetch(id)
	if err != nil {
		t.Fatal(err)
	}
	err = ds.Remove(id)
	if err != nil {
		t.Fatal(err)
	}
	ps, err := ds.FetchTimeline(3)
	if err != nil {
		t.Fatal(err)
	}
	for _, p := range ps {
		t.Log(p)
	}
	ps, err = ds.Filter(bson.D{{Key: "Tags", Value: "test1"}}, 2)
	if err != nil {
		t.Fatal(err)
	}
	for _, p := range ps {
		t.Log(p)
	}
	rev, err := ds.GetRev()
	if err != nil {
		t.Fatal(err)
	}
	t.Log(rev)
}
