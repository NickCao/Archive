package starliner

import (
	"strings"

	"time"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
	"gitlab.com/NickCao/starliner/authutil"
)

//Starliner ...
type Starliner struct {
	eng    *gin.Engine
	ds     *MongoDBDataStore
	config Config
}

//Config ...
type Config struct {
	DataStoreType string
	URL           string
	Listen        string
	Provider      string
	UserIDs       []string
}

//NewStarliner ...
func NewStarliner(config Config) (*Starliner, error) {
	sl := &Starliner{}
	sl.config = config
	var err error
	sl.ds, err = NewMongoDBDataStore(sl.config.URL)
	if err != nil {
		return nil, err
	}

	gin.SetMode(gin.ReleaseMode)
	eng := gin.Default()
	eng.Use(cors.New(cors.Config{
		AllowOrigins:     []string{"*"},
		AllowMethods:     []string{"GET", "POST", "DELETE", "PUT"},
		AllowCredentials: true,
		MaxAge:           12 * time.Hour,
	}))

	auth := eng.Group("/", sl.Auth)
	auth.POST("/commit", sl.commitEndpoint)
	auth.DELETE("/id/:id", sl.removeEndpoint)

	eng.GET("/id/:id", sl.fetchEndpoint)
	eng.GET("/rev", sl.getrevEndpoint)
	eng.GET("/timeline/:count", sl.fetchtimelineEndpoint)
	eng.GET("/timeline", sl.fetchtimelineEndpoint)
	eng.GET("/tag/:tag", sl.filterEndpoint)
	eng.GET("/tag/:tag/:count", sl.filterEndpoint)

	sl.eng = eng
	return sl, nil
}

//Start ...
func (sl *Starliner) Start() error {
	err := sl.ds.Init()
	if err != nil {
		return err
	}
	return sl.eng.Run(sl.config.Listen)
}

//Stop ...
func (sl *Starliner) Stop() error {
	return sl.ds.Close()
}

//Auth ...
func (sl *Starliner) Auth(c *gin.Context) {
	defer func() {
		r := recover()
		if r != nil {
			c.AbortWithStatus(500)
		}
	}()
	tokenstring := strings.Split(c.GetHeader("Authorization"), " ")[1]
	token, err := authutil.Verify(tokenstring, sl.config.Provider)
	if err != nil {
		c.AbortWithStatus(403)
		return
	}
	found := false
	for _, id := range sl.config.UserIDs {
		if id == token.Subject {
			found = true
		}
	}
	if !found {
		c.AbortWithStatus(403)
		return
	}
	c.Next()
}
