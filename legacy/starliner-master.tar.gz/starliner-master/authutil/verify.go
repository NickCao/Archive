package authutil

import (
	"context"

	oidc "github.com/coreos/go-oidc"
)

//Verify ...
func Verify(tokenstring, providerurl string) (*oidc.IDToken, error) {
	provider, err := oidc.NewProvider(context.Background(), providerurl)
	if err != nil {
		return nil, err
	}
	config := &oidc.Config{
		SkipClientIDCheck: true,
		SkipExpiryCheck:   false,
	}
	verifier := provider.Verifier(config)
	return verifier.Verify(context.Background(), tokenstring)
}
