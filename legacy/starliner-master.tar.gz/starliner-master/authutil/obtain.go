package authutil

import (
	"context"
	"crypto/rand"
	"encoding/base64"
	"errors"
	"log"
	"net/http"
	"net/url"
	"time"

	oidc "github.com/coreos/go-oidc"
	"github.com/pkg/browser"
	"golang.org/x/oauth2"
)

//OIDCStub ...
type OIDCStub struct {
	ProviderURL *url.URL
	RedirectURL *url.URL
	ClientID    string
	Provider    *oidc.Provider
	Server      *http.Server

	Err          chan error
	OAuth2Config *oauth2.Config
	Audience     string
	State        string
	Token        *oauth2.Token
	Done         chan struct{}
}

//NewOIDCStub ...
func NewOIDCStub(providerurl, redirectutl, clientid string) (*OIDCStub, error) {
	stub := &OIDCStub{}
	var err error
	stub.ProviderURL, err = url.Parse(providerurl)
	if err != nil {
		return nil, err
	}
	stub.RedirectURL, err = url.Parse(redirectutl)
	if err != nil {
		return nil, err
	}
	stub.ClientID = clientid
	stub.Provider, err = oidc.NewProvider(context.Background(), stub.ProviderURL.String())
	if err != nil {
		return nil, err
	}
	mux := http.NewServeMux()
	mux.HandleFunc("/callback", stub.CallbackHandler)
	stub.Server = &http.Server{
		Addr:    stub.RedirectURL.Host,
		Handler: mux,
	}
	stub.Err = make(chan error, 1)
	stub.Done = make(chan struct{}, 1)
	return stub, nil
}

func genstate() string {
	b := make([]byte, 16)
	rand.Read(b)
	return base64.URLEncoding.EncodeToString(b)
}

//Prepare ...
func (stub *OIDCStub) Prepare(aud string, scope []string) {
	stub.OAuth2Config = &oauth2.Config{
		RedirectURL: stub.RedirectURL.String(),
		ClientID:    stub.ClientID,
		Scopes:      append(scope, oidc.ScopeOpenID),
		Endpoint:    stub.Provider.Endpoint(),
	}
	stub.State = genstate()
	stub.Audience = aud
	stub.Token = nil
	return
}

//CallbackHandler ...
func (stub *OIDCStub) CallbackHandler(w http.ResponseWriter, r *http.Request) {
	defer func() {
		ctx, cancel := context.WithTimeout(context.Background(), time.Second*1)
		stub.Server.Shutdown(ctx)
		stub.Done <- struct{}{}
		cancel()
	}()
	newstate := r.URL.Query().Get("state")
	if newstate != stub.State {
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte("State mismatch"))
		stub.Err <- errors.New("State mismatch")
		return
	}
	var err error
	stub.Token, err = stub.OAuth2Config.Exchange(context.Background(), r.URL.Query().Get("code"))
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte(err.Error()))
		stub.Err <- err
		return
	}
	w.WriteHeader(http.StatusOK)
	w.Write([]byte("OK"))
	stub.Err <- nil
	return
}

//StartFlow ...
func (stub *OIDCStub) StartFlow() error {
	opt := oauth2.SetAuthURLParam("audience", stub.Audience)
	err := browser.OpenURL(stub.OAuth2Config.AuthCodeURL(stub.State, opt))
	if err != nil {
		log.Print(stub.OAuth2Config.AuthCodeURL(stub.State, opt))
		err = nil
	}
	err = stub.Server.ListenAndServe()
	if err != http.ErrServerClosed {
		return err
	}
	err = <-stub.Err
	if err != nil {
		return err
	}
	<-stub.Done
	return nil
}

//GetTokenString ...
func (stub *OIDCStub) GetTokenString() string {
	return stub.Token.Extra("id_token").(string)
}
