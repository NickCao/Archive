package starliner

import (
	"context"
	"time"

	"github.com/mongodb/mongo-go-driver/mongo/options"

	"github.com/mongodb/mongo-go-driver/bson"
	"github.com/mongodb/mongo-go-driver/mongo"
)

const timeout = 3

//MongoDBDataStore ...
type MongoDBDataStore struct {
	client *mongo.Client
	db     *mongo.Database
	coll   *mongo.Collection
}

//NewMongoDBDataStore ...
func NewMongoDBDataStore(url string) (*MongoDBDataStore, error) {
	ds := &MongoDBDataStore{}
	var err error
	ds.client, err = mongo.NewClient(url)
	if err != nil {
		return nil, err
	}
	return ds, nil
}

//Init ...
func (ds *MongoDBDataStore) Init() error {
	ctx, cancel := context.WithTimeout(context.Background(), timeout*time.Second)
	defer cancel()
	err := ds.client.Connect(ctx)
	if err != nil {
		return err
	}
	ds.db = ds.client.Database("starliner")
	ds.coll = ds.db.Collection("posts")
	return nil
}

//Close ...
func (ds *MongoDBDataStore) Close() error {
	ctx, cancel := context.WithTimeout(context.Background(), timeout*time.Second)
	defer cancel()
	err := ds.client.Disconnect(ctx)
	if err != nil {
		return err
	}
	return nil
}

//Commit ...
func (ds *MongoDBDataStore) Commit(p *Post) (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), timeout*time.Second)
	defer cancel()
	_, err := ds.coll.InsertOne(ctx, p)
	if err != nil {
		return "", err
	}
	return p.ID, nil
}

//Fetch ...
func (ds *MongoDBDataStore) Fetch(id string) (*Post, error) {
	ctx, cancel := context.WithTimeout(context.Background(), timeout*time.Second)
	defer cancel()
	filter := bson.D{{Key: "ID", Value: id}}
	res := ds.coll.FindOne(ctx, filter)
	if res.Err() != nil {
		return nil, res.Err()
	}
	post := &Post{}
	err := res.Decode(post)
	if err != nil {
		return nil, err
	}
	return post, nil
}

//Remove ...
func (ds *MongoDBDataStore) Remove(id string) error {
	ctx, cancel := context.WithTimeout(context.Background(), timeout*time.Second)
	defer cancel()
	filter := bson.D{{Key: "ID", Value: id}}
	res := ds.coll.FindOneAndDelete(ctx, filter)
	if res.Err() != nil {
		return res.Err()
	}
	return nil
}

//GetRev ...
func (ds *MongoDBDataStore) GetRev() (string, error) {
	ps, err := ds.FetchTimeline(1)
	if err != nil {
		return "", err
	}
	return ps[0].ID, nil
}

//FetchTimeline ...
func (ds *MongoDBDataStore) FetchTimeline(count int) ([]*Post, error) {
	filter := bson.D{}
	return ds.Filter(filter, count)
}

//Filter ...
func (ds *MongoDBDataStore) Filter(filter bson.D, count int) ([]*Post, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 2*timeout*time.Second)
	defer cancel()
	option := options.Find()
	option.SetSort(bson.D{{Key: "ID", Value: -1}})
	option.SetLimit(int64(count))
	cur, err := ds.coll.Find(ctx, filter, option)
	if err != nil {
		return nil, err
	}
	var ps []*Post
	for cur.Next(context.Background()) {
		p := &Post{}
		if err := cur.Decode(p); err != nil {
			return nil, err
		}
		ps = append(ps, p)
	}
	return ps, nil
}
