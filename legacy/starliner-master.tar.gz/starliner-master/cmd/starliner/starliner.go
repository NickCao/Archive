package main

import (
	"flag"
	"io/ioutil"
	"log"
	"os"

	"github.com/BurntSushi/toml"
	"gitlab.com/NickCao/starliner"
)

var confFile = flag.String("c", "./sl.toml", "path to conf file")

type config struct {
	MgoURL   string
	Listen   string
	Provider string
	UserIDs  []string
}

func main() {
	flag.Parse()
	confData, err := ioutil.ReadFile(*confFile)
	conf := &config{}
	if err == nil {
		err = toml.Unmarshal(confData, conf)
		if err != nil {
			log.Fatal(err)
		}
	} else {
		conf = &config{
			MgoURL:   os.Getenv("MGOURL"),
			Listen:   "0.0.0.0:" + os.Getenv("PORT"),
			Provider: os.Getenv("PROVIDER"),
			UserIDs:  []string{os.Getenv("USERID")},
		}
	}
	confi := starliner.Config{URL: conf.MgoURL, Listen: conf.Listen, Provider: conf.Provider, UserIDs: conf.UserIDs}
	sl, err := starliner.NewStarliner(confi)
	if err != nil {
		log.Fatal(err)
	}
	defer sl.Stop()
	err = sl.Start()
	if err != nil {
		log.Fatal(err)
	}
}
