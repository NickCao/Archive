package main

import (
	"flag"
	"fmt"
	"io/ioutil"
	"log"

	"github.com/BurntSushi/toml"
	"gitlab.com/NickCao/starliner/authutil"
)

type config struct {
	Provider string
	Callback string
	ClientID string
}

var confFile = flag.String("c", "./auth.toml", "path to conf file")

func main() {
	flag.Parse()
	confData, err := ioutil.ReadFile(*confFile)
	if err != nil {
		log.Fatal(err)
	}
	conf := &config{}
	err = toml.Unmarshal(confData, conf)
	if err != nil {
		log.Fatal(err)
	}
	stub, err := authutil.NewOIDCStub(conf.Provider, conf.Callback, conf.ClientID)
	if err != nil {
		log.Fatal(err)
	}
	stub.Prepare("timeline", []string{})
	err = stub.StartFlow()
	if err != nil {
		log.Fatal(err)
	}
	fmt.Println("export HEADER=\"Authorization: Bearer " + stub.GetTokenString() + "\";")
}
