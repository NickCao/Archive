package starliner

import (
	"testing"
)

func TestPost(t *testing.T) {
	post, err := NewPost("NickCao", []string{"test", "case"}, "testbody")
	if err != nil {
		t.Fatal(err)
	}
	str, err := post.String()
	if err != nil {
		t.Fatal(err)
	}
	t.Log(str)
	time, err := post.Time()
	if err != nil {
		t.Fatal(err)
	}
	t.Log(time)
}
