package starliner

import (
	"log"
	"strconv"

	"github.com/gin-gonic/gin"
	"github.com/mongodb/mongo-go-driver/bson"
)

func (sl *Starliner) commitEndpoint(c *gin.Context) {
	author, e1 := c.GetPostForm("author")
	tags, e2 := c.GetPostFormArray("tags")
	body, e3 := c.GetPostForm("body")
	if !(e1 && e2 && e3) {
		c.AbortWithStatus(500)
		return
	}
	p, err := NewPost(author, tags, body)
	if err != nil {
		log.Print(err)
		c.AbortWithStatus(500)
		return
	}
	id, err := sl.ds.Commit(p)
	if err != nil {
		log.Print(err)
		c.AbortWithStatus(500)
		return
	}
	c.JSON(200, id)
}

func (sl *Starliner) removeEndpoint(c *gin.Context) {
	err := sl.ds.Remove(c.Param("id"))
	if err != nil {
		log.Print(err)
		c.AbortWithStatus(500)
		return
	}
	c.JSON(200, c.Param("id"))
}

func (sl *Starliner) fetchEndpoint(c *gin.Context) {
	p, err := sl.ds.Fetch(c.Param("id"))
	if err != nil {
		log.Print(err)
		c.AbortWithStatus(500)
		return
	}
	c.JSON(200, p)
}

func (sl *Starliner) getrevEndpoint(c *gin.Context) {
	rev, err := sl.ds.GetRev()
	if err != nil {
		log.Print(err)
		c.AbortWithStatus(500)
		return
	}
	c.JSON(200, rev)
}

func (sl *Starliner) fetchtimelineEndpoint(c *gin.Context) {
	count, err := strconv.Atoi(c.Param("count"))
	if err != nil || count <= 0 {
		count = 5
	}
	ps, err := sl.ds.FetchTimeline(count)
	if err != nil {
		log.Print(err)
		c.AbortWithStatus(500)
		return
	}
	c.JSON(200, ps)
}

func (sl *Starliner) filterEndpoint(c *gin.Context) {
	count, err := strconv.Atoi(c.Param("count"))
	if err != nil || count <= 0 {
		count = 5
	}
	ps, err := sl.ds.Filter(bson.D{{Key: "Tags", Value: c.Param("tag")}}, count)
	if err != nil {
		log.Print(err)
		c.AbortWithStatus(500)
		return
	}
	c.JSON(200, ps)
}
