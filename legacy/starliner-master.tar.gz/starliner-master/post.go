package starliner

import (
	"crypto/rand"
	"encoding/json"

	"github.com/oklog/ulid"
)

//Post ...
type Post struct {
	ID     string   `bson:"ID"`
	Author string   `bson:"Author"`
	Tags   []string `bson:"Tags"`
	Body   string   `bson:"Body"`
}

//NewPost ...
func NewPost(author string, tags []string, body string) (*Post, error) {
	post := &Post{}
	var err error
	var id ulid.ULID
	id, err = ulid.New(ulid.Now(), rand.Reader)
	if err != nil {
		return nil, err
	}

	post.ID = id.String()
	post.Author = author
	post.Tags = tags
	post.Body = body
	return post, nil
}

//String ...
func (p *Post) String() (string, error) {
	raw, err := json.Marshal(p)
	if err != nil {
		return "", err
	}
	return string(raw), nil
}

//Time ...
func (p *Post) Time() (string, error) {
	id, err := ulid.Parse(p.ID)
	if err != nil {
		return "", err
	}
	return ulid.Time(id.Time()).Format("Mon Jan 2 15:04:05 -0700 MST 2006"), nil
}
