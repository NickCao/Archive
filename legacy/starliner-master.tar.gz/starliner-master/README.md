# Starliner
#### A opinionated yet flexible journaling platform
Actually, this repo only contains the backend code,  
for frontend code checkout [StarTrack](https://gitlab.com/NickCao/startrack).  
Currently,there are two cmd in this repo, starliner and sl-oauth.  
starliner is for running the api server,  
while sl-oauth is a command line helper to aid the authencation processcess  