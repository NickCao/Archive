package woff

import (
	"github.com/labstack/echo/v4"
	"github.com/ovh/configstore"
	"github.com/stripe/stripe-go/v71"
	"github.com/stripe/stripe-go/v71/paymentintent"
	"github.com/stripe/stripe-go/v71/paymentmethod"
	"log"
	"net/http"
	"strconv"
)

var returnURL string

func init() {
	configstore.Env("WOFF")

	stripeKey, err := configstore.GetItemValue("STRIPE_KEY")
	if err != nil {
		log.Fatal(err)
	}
	stripe.Key = stripeKey

	returnURL, err = configstore.GetItemValue("RETURN_URL")
	if err != nil {
		log.Fatal(err)
	}
}

func Woff(w http.ResponseWriter, r *http.Request) {
	e := echo.New()

	e.GET("/", func(context echo.Context) error {
		amount := context.QueryParam("amount")

		target, err := mkPayment(amount, returnURL)
		if err != nil {
			log.Printf("failed to create payment for amount: %s, error: %s", amount, err)
			return context.String(http.StatusInternalServerError, "payment creation failed")
		}

		return context.Redirect(http.StatusFound, target)
	})

	e.ServeHTTP(w, r)
}

func mkPayment(amountString string, returnURL string) (string, error) {
	amount, err := strconv.ParseFloat(amountString, 64)
	if err != nil {
		return "", err
	}

	pm, err := paymentmethod.New(&stripe.PaymentMethodParams{Type: stripe.String("alipay")})
	if err != nil {
		return "", err
	}

	pi, err := paymentintent.New(&stripe.PaymentIntentParams{
		Amount:             stripe.Int64(int64(amount * 100)),
		Currency:           stripe.String("cny"),
		PaymentMethod:      stripe.String(pm.ID),
		PaymentMethodTypes: stripe.StringSlice([]string{"alipay"}),
	})
	if err != nil {
		return "", err
	}

	pi, err = paymentintent.Confirm(pi.ID, &stripe.PaymentIntentConfirmParams{
		ReturnURL: stripe.String(returnURL),
	})
	if err != nil {
		return "", err
	}

	return pi.NextAction.AlipayHandleRedirect.URL, nil
}
