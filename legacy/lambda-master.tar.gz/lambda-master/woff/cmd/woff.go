package main

import (
	"context"
	"github.com/GoogleCloudPlatform/functions-framework-go/funcframework"
	"gitlab.com/NickCao/lambda/woff"
	"log"
)

func main() {
	if err := funcframework.RegisterHTTPFunctionContext(context.Background(), "/", woff.Woff); err != nil {
		log.Fatal(err)
	}

	if err := funcframework.Start("8080"); err != nil {
		log.Fatal(err)
	}
}
