package meow

import (
	"github.com/labstack/echo/v4"
	"html/template"
	"io"
)

type renderer struct {
	templates *template.Template
}

func (t *renderer) Render(w io.Writer, name string, data interface{}, _ echo.Context) error {
	return t.templates.ExecuteTemplate(w, name, data)
}

var indexTmpl = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>meow</title>
</head>
<body>
<pre>
MEOW(1)

<b>NAME</b>

    <b>meow</b> - pastebin

<b>USAGE</b>

    $ curl --data-binary "@<i>file</i>" {{.BaseURL}}
    {{.ExampleURL}}

<b>SOURCE</b>

    https://gitlab.com/NickCao/lambda

</pre>
</body>
</html>`
