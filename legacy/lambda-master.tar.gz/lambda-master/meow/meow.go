package meow

import (
	"context"
	"fmt"
	"github.com/labstack/echo/v4"
	"github.com/minio/minio-go/v7"
	"github.com/minio/minio-go/v7/pkg/credentials"
	"github.com/ovh/configstore"
	"github.com/tyler-smith/go-bip39/wordlists"
	"html/template"
	"log"
	"math/rand"
	"net/http"
	"net/url"
	"strings"
	"time"
)

var base *url.URL
var store *minio.Client
var bucket string

func init() {
	configstore.Env("MEOW")

	baseURL, err := configstore.GetItemValue("BASE_URL")
	if err != nil {
		log.Fatal(err)
	}

	base, err = url.Parse(baseURL)
	if err != nil {
		log.Fatal(err)
	}

	endpoint, err := configstore.GetItemValue("S3_ENDPOINT")
	if err != nil {
		log.Fatal(err)
	}

	region, err := configstore.GetItemValue("S3_REGION")
	if err != nil {
		log.Fatal(err)
	}

	bucket, err = configstore.GetItemValue("S3_BUCKET")
	if err != nil {
		log.Fatal(err)
	}

	accessKey, err := configstore.GetItemValue("S3_ACCESS_KEY")
	if err != nil {
		log.Fatal(err)
	}

	secretKey, err := configstore.GetItemValue("S3_SECRET_KEY")
	if err != nil {
		log.Fatal(err)
	}

	store, err = minio.New(endpoint, &minio.Options{
		Creds:  credentials.NewStaticV4(accessKey, secretKey, ""),
		Secure: true,
		Region: region,
	})
	if err != nil {
		log.Fatal(err)
	}
}

func Meow(w http.ResponseWriter, r *http.Request) {
	e := echo.New()
	e.Renderer = &renderer{template.Must(template.New("index").Parse(indexTmpl))}

	e.GET("/", func(c echo.Context) error {
		return c.Render(http.StatusOK, "index", map[string]string{
			"BaseURL":    base.String(),
			"ExampleURL": base.ResolveReference(&url.URL{Path: NewMnemonic(3)}).String(),
		})
	})

	e.POST("/", func(c echo.Context) error {
		info, err := store.PutObject(context.Background(), bucket, NewMnemonic(3),
			c.Request().Body, c.Request().ContentLength, minio.PutObjectOptions{})
		if err != nil {
			log.Println(err)
			return c.String(http.StatusInternalServerError, fmt.Sprintf("failed to create paste: %s", err))
		}

		return c.String(http.StatusOK, base.ResolveReference(&url.URL{Path: info.Key}).String()+"\n")
	})

	e.GET("/:id", func(c echo.Context) error {
		object, err := store.GetObject(context.Background(), bucket, c.Param("id"),
			minio.GetObjectOptions{})
		if err != nil {
			log.Println(err)
			return c.String(http.StatusNotFound, fmt.Sprintf("failed to fetch paste: %s", err))
		}
		defer func() { _ = object.Close() }()

		return c.Stream(http.StatusOK, "application/octet-stream", object)
	})

	e.ServeHTTP(w, r)
}

func NewMnemonic(length int) string {
	rand.Seed(time.Now().UnixNano())
	var words []string
	for i := 0; i < length; i++ {
		words = append(words, wordlists.English[rand.Intn(2048)])
	}
	return strings.Join(words, "-")
}
