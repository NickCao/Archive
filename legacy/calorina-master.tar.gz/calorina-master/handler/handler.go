package handler

import (
	"context"
	"github.com/miekg/dns"
	"gitlab.com/NickCao/calorina/v4/checker"
	"gitlab.com/NickCao/calorina/v4/fetcher"
	"gitlab.com/NickCao/calorina/v4/localcache"
	"gitlab.com/NickCao/calorina/v4/metachecker"
	"go.uber.org/zap"
	"time"
)

type Handler struct {
	topLevelChecker  checker.Checker
	pollutedFetchers []fetcher.Fetcher
	cleanFetchers    []fetcher.Fetcher
	timeout          time.Duration
	logger           *zap.Logger
	localCache       *localcache.LocalCache
}

//noinspection GoUnusedExportedFunction
func DefaultHandler() *Handler {
	logger, err := zap.NewDevelopment()
	if err != nil {
		panic(err)
	}
	return NewHandler(metachecker.DefaultFirstFirmMetaChecker(), []fetcher.Fetcher{fetcher.AliUDPFetcher(), fetcher.DnspodUDPFetcher()},
		[]fetcher.Fetcher{fetcher.CloudflareTLSFetcher(), fetcher.GoogleTLSFetcher()}, time.Millisecond*800, logger)
}

func NewHandler(topLevelChecker checker.Checker, pollutedFetchers []fetcher.Fetcher,
	cleanFetchers []fetcher.Fetcher, timeout time.Duration, logger *zap.Logger) *Handler {
	return &Handler{
		topLevelChecker:  topLevelChecker,
		pollutedFetchers: pollutedFetchers,
		cleanFetchers:    cleanFetchers,
		timeout:          timeout,
		logger:           logger,
		localCache:       localcache.NewLocalCache(),
	}
}

func (h *Handler) ServeDNS(w dns.ResponseWriter, request *dns.Msg) {
	//noinspection GoUnhandledErrorResult
	defer w.Close()
	success := false
	defer func() {
		if !success {
			reply := new(dns.Msg)
			reply.SetRcode(request, dns.RcodeServerFailure)
			_ = w.WriteMsg(reply)
		}
	}()

	//noinspection GoUnhandledErrorResult
	defer h.logger.Sync()
	ctx := context.WithValue(context.Background(), "requestID", request.Id)

	if reply, ok := h.localCache.Fetch(request); ok {
		h.logger.Info("Handler:ServeDNS:Cache:Hit", zap.Uint16("requestID", ctx.Value("requestID").(uint16)),
			zap.String("domain", request.Question[0].Name))
		_ = w.WriteMsg(reply)
		success = true
		return
	}

	cleanFetchResultChan := make(chan *fetcher.FetchResult)
	pollutedFetchResultChan := make(chan *fetcher.FetchResult)
	checkResultChan := make(chan *checker.CheckResult)

	ctx, cancel := context.WithTimeout(ctx, h.timeout)
	defer cancel()

	go h.topLevelChecker.Check(ctx, h.logger, checkResultChan, request.Question[0].Name)
	for _, pf := range h.pollutedFetchers {
		go pf.Fetch(ctx, h.logger, pollutedFetchResultChan, request)
	}
	for _, cf := range h.cleanFetchers {
		go cf.Fetch(ctx, h.logger, cleanFetchResultChan, request)
	}

	var checkResult *checker.CheckResult
	select {
	case checkResult = <-checkResultChan:
		break
	case <-ctx.Done():
		return
	}

	var hitFetchResultChan chan *fetcher.FetchResult
	switch checkResult.DomainStatus {
	case checker.Available:
		hitFetchResultChan = pollutedFetchResultChan
	case checker.Blocked:
		hitFetchResultChan = cleanFetchResultChan
	default:
		return
	}

	var fetchResult *fetcher.FetchResult
frloop:
	for {
		select {
		case fetchResult = <-hitFetchResultChan:
			break frloop
		case <-ctx.Done():
			return
		}
	}

	h.logger.Info("Handler:ServeDNS:Fetch:Hit", zap.Uint16("requestID", ctx.Value("requestID").(uint16)), zap.String("realFetcher", fetchResult.FetcherName),
		zap.String("domain", request.Question[0].Name))

	defer h.localCache.Save(request, fetchResult.Reply.Copy())
	_ = w.WriteMsg(fetchResult.Reply)
	success = true
}
