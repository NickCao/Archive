## Project Calorina - Another DNS relay, with real-time probe based routing

DNS poisoning, long been a problem for Chinese netizens.  
DoH or similar technologies do prevent getting polluted results, the GEO optimized results are also lost.  
So, calorina exists.  