package config

import (
	"github.com/BurntSushi/toml"
	"github.com/miekg/dns"
	"gitlab.com/NickCao/calorina/v4/checker"
	"gitlab.com/NickCao/calorina/v4/fetcher"
	"gitlab.com/NickCao/calorina/v4/handler"
	"gitlab.com/NickCao/calorina/v4/metachecker"
	"go.uber.org/zap"
	"log"
	"os"
	"strings"
	"time"
)

type Config struct {
	ListenAddress    string
	Network          string
	MetaChecker      string
	SubCheckers      []string
	PollutedFetchers []string
	CleanFetchers    []string
	Timeout          string
	LogLevel         string
}

//noinspection GoUnusedExportedFunction
func DefaultConfig() *Config {
	return &Config{
		ListenAddress: "127.0.0.1:5353",
		Network:       "udp",
		MetaChecker:   "FirstFirm",
		SubCheckers: []string{
			"TCPConnect,223.5.5.5:53,600ms",
			"TCPConnect,114.114.114.114:53,600ms",
			"TCPReset,8.8.8.8:53",
			"TCPReset,1.1.1.1:53",
			"UDPHijack,99.84.239.46:53",
			"UDPHijack,97.86.234.44:53",
		},
		PollutedFetchers: []string{
			"UDP,223.5.5.5:53",
			"UDP,119.29.29.29:53",
		},
		CleanFetchers: []string{
			"TLS,8.8.8.8:853,dns.google",
			"TLS,1.1.1.1:853,cloudflare-dns.com",
		},
		Timeout:  "800ms",
		LogLevel: "Debug",
	}
}

func LoadConfig(path string) *Config {
	var conf Config
	_, err := toml.DecodeFile(path, &conf)
	if err != nil {
		log.Fatal(err)
	}
	return &conf
}

func (c *Config) Print() {
	_ = toml.NewEncoder(os.Stdout).Encode(c)
}

func (c *Config) Run() {
	var subCheckers []checker.Checker
	for _, subChecker := range c.SubCheckers {
		params := strings.Split(subChecker, ",")
		switch params[0] {
		case "TCPConnect":
			subCheckers = append(subCheckers, checker.NewTCPConnectChecker(params[1], mustParse(params[2])))
		case "HTTPGet":
			subCheckers = append(subCheckers, checker.NewHTTPGETChecker(params[1], mustParse(params[2])))
		case "TCPReset":
			subCheckers = append(subCheckers, checker.NewTCPResetChecker(params[1]))
		case "UDPHijack":
			subCheckers = append(subCheckers, checker.NewUDPHijackChecker(params[1]))
		}
	}
	var metaChecker checker.Checker
	switch c.MetaChecker {
	case "FirstFirm":
		metaChecker = metachecker.NewFirstFirmMetaChecker(subCheckers...)
	}

	var pollutedFetchers []fetcher.Fetcher
	for _, pollutedFetcher := range c.PollutedFetchers {
		params := strings.Split(pollutedFetcher, ",")
		switch params[0] {
		case "UDP":
			pollutedFetchers = append(pollutedFetchers, fetcher.NewUDPFetcher(params[1]))
		case "TCP":
			pollutedFetchers = append(pollutedFetchers, fetcher.NewTCPFetcher(params[1]))
		case "TLS":
			pollutedFetchers = append(pollutedFetchers, fetcher.NewTLSFetcher(params[1], params[2]))
		}
	}
	var cleanFetchers []fetcher.Fetcher
	for _, cleanFetcher := range c.CleanFetchers {
		params := strings.Split(cleanFetcher, ",")
		switch params[0] {
		case "TLS":
			cleanFetchers = append(cleanFetchers, fetcher.NewTLSFetcher(params[1], params[2]))
		case "TCP":
			cleanFetchers = append(cleanFetchers, fetcher.NewTCPFetcher(params[1]))
		case "UDP":
			cleanFetchers = append(cleanFetchers, fetcher.NewUDPFetcher(params[1]))
		}
	}
	var logger *zap.Logger
	switch c.LogLevel {
	case "Debug":
		logger, _ = zap.NewDevelopment()
	case "Info":
		logger, _ = zap.NewProduction()
	}

	h := handler.NewHandler(metaChecker, pollutedFetchers, cleanFetchers, mustParse(c.Timeout), logger)
	log.Fatal(dns.ListenAndServe(c.ListenAddress, c.Network, h))
}

func mustParse(t string) time.Duration {
	d, err := time.ParseDuration(t)
	if err != nil {
		log.Fatal(err)
	}
	return d
}
