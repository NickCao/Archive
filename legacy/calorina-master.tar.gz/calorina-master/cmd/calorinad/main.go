package main

import (
	"flag"
	"gitlab.com/NickCao/calorina/v4/config"
	"log"
	"net/http"
	_ "net/http/pprof"
)

var c = flag.String("c", "./config.toml", "path to config file")
var p = flag.Bool("p", false, "to enable profiling")

func main() {
	flag.Parse()
	if *p {
		go func() {
			log.Println(http.ListenAndServe("localhost:6060", nil))
		}()
	}
	config.LoadConfig(*c).Run()
}
