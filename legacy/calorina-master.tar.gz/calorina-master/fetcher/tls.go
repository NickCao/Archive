package fetcher

import (
	"context"
	"crypto/tls"
	"github.com/miekg/dns"
	"go.uber.org/zap"
)

type TLSFetcher struct {
	client *dns.Client
	tlsDNS string
}

func CloudflareTLSFetcher() *TLSFetcher {
	return NewTLSFetcher("1.0.0.1:853", "cloudflare-dns.com")
}

func GoogleTLSFetcher() *TLSFetcher {
	return NewTLSFetcher("8.8.4.4:853", "dns.google")
}

func NewTLSFetcher(tlsDNS string, name string) *TLSFetcher {
	client := &dns.Client{
		Net: "tcp-tls",
		TLSConfig: &tls.Config{
			ServerName: name,
		},
	}
	return &TLSFetcher{
		client: client,
		tlsDNS: tlsDNS,
	}
}

func (f *TLSFetcher) Fetch(ctx context.Context, logger *zap.Logger, resultChan chan *FetchResult, request *dns.Msg) {
	var result FetchResult
	result.FetcherName = "TLSFetcher"

	reply, rtt, err := f.client.ExchangeContext(ctx, request, f.tlsDNS)
	if err != nil {
		logger.Debug("TLSFetcher:Fetch:ExchangeContext:Fail", zap.Uint16("requestID", ctx.Value("requestID").(uint16)), zap.Error(err))
	} else {
		logger.Debug("TLSFetcher:Fetch:ExchangeContext:Success", zap.Uint16("requestID", ctx.Value("requestID").(uint16)), zap.Any("AnswerSection", reply.Answer),
			zap.Duration("Rtt", rtt))
	}

	if err != nil {
		return
	} else {
		result.Reply = reply
	}

	select {
	case resultChan <- &result:
		return
	case <-ctx.Done():
		return
	}

}
