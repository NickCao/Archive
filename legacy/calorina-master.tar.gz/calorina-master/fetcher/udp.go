package fetcher

import (
	"context"
	"github.com/miekg/dns"
	"go.uber.org/zap"
)

type UDPFetcher struct {
	client *dns.Client
	udpDNS string
}

func AliUDPFetcher() *UDPFetcher {
	return NewUDPFetcher("223.6.6.6:53")
}

func DnspodUDPFetcher() *UDPFetcher {
	return NewUDPFetcher("119.29.29.29:53")
}

//noinspection GoUnusedExportedFunction
func GoogleUDPFetcher() *UDPFetcher {
	return NewUDPFetcher("8.8.4.4:53")
}

//noinspection GoUnusedExportedFunction
func CloudflareUDPFetcher() *UDPFetcher {
	return NewUDPFetcher("1.0.0.1:53")
}

func NewUDPFetcher(udpDNS string) *UDPFetcher {
	client := &dns.Client{
		Net: "udp",
	}
	return &UDPFetcher{
		client: client,
		udpDNS: udpDNS,
	}
}

func (f *UDPFetcher) Fetch(ctx context.Context, logger *zap.Logger, resultChan chan *FetchResult, request *dns.Msg) {
	var result FetchResult
	result.FetcherName = "UDPFetcher"

	reply, rtt, err := f.client.ExchangeContext(ctx, request, f.udpDNS)
	if err != nil {
		logger.Debug("UDPFetcher:Fetch:ExchangeContext:Fail", zap.Uint16("requestID", ctx.Value("requestID").(uint16)), zap.Error(err))
	} else {
		logger.Debug("UDPFetcher:Fetch:ExchangeContext:Success", zap.Uint16("requestID", ctx.Value("requestID").(uint16)), zap.Any("AnswerSection", reply.Answer),
			zap.Duration("Rtt", rtt))
	}

	if err != nil {
		return
	} else {
		result.Reply = reply
	}

	select {
	case resultChan <- &result:
		return
	case <-ctx.Done():
		return
	}

}
