package fetcher

import (
	"context"
	"github.com/miekg/dns"
	"go.uber.org/zap"
)

type TCPFetcher struct {
	client *dns.Client
	tcpDNS string
}

//noinspection GoUnusedExportedFunction
func GoogleTCPFetcher() *TCPFetcher {
	return NewTCPFetcher("8.8.4.4:53")
}

//noinspection GoUnusedExportedFunction
func CloudflareTCPFetcher() *TCPFetcher {
	return NewTCPFetcher("1.0.0.1:53")
}

func NewTCPFetcher(tcpDNS string) *TCPFetcher {
	client := &dns.Client{
		Net: "tcp",
	}
	return &TCPFetcher{
		client: client,
		tcpDNS: tcpDNS,
	}
}

func (f *TCPFetcher) Fetch(ctx context.Context, logger *zap.Logger, resultChan chan *FetchResult, request *dns.Msg) {
	var result FetchResult
	result.FetcherName = "TCPFetcher"

	reply, rtt, err := f.client.ExchangeContext(ctx, request, f.tcpDNS)
	if err != nil {
		logger.Debug("TCPFetcher:Fetch:ExchangeContext:Fail", zap.Uint16("requestID", ctx.Value("requestID").(uint16)), zap.Error(err))
	} else {
		logger.Debug("TCPFetcher:Fetch:ExchangeContext:Success", zap.Uint16("requestID", ctx.Value("requestID").(uint16)), zap.Any("AnswerSection", reply.Answer),
			zap.Duration("Rtt", rtt))
	}

	if err != nil {
		return
	} else {
		result.Reply = reply
	}

	select {
	case resultChan <- &result:
		return
	case <-ctx.Done():
		return
	}

}
