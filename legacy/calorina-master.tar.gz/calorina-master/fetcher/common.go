package fetcher

import (
	"context"
	"github.com/miekg/dns"
	"go.uber.org/zap"
)

type Fetcher interface {
	Fetch(ctx context.Context, logger *zap.Logger, resultChan chan *FetchResult, request *dns.Msg)
}

type FetchResult struct {
	FetcherName string
	Reply       *dns.Msg
}
