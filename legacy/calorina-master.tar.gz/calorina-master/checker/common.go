package checker

import (
	"context"
	"go.uber.org/zap"
)

type DomainStatus int

//noinspection GoUnusedConst
const (
	Blocked DomainStatus = iota
	LikelyBlocked
	LikelyAvailable
	Available
)

type CheckResult struct {
	CheckerName  string
	DomainStatus DomainStatus
}

//noinspection ALL
type Checker interface {
	Check(ctx context.Context, logger *zap.Logger, resultChan chan *CheckResult, fqdn string)
}
