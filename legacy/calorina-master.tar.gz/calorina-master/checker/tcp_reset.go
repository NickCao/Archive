package checker

import (
	"context"
	"github.com/miekg/dns"
	"go.uber.org/zap"
	"net"
)

type TCPResetChecker struct {
	tcpDNS string
	client *dns.Client
}

func GoogleTCPResetChecker() *TCPResetChecker {
	return NewTCPResetChecker("8.8.8.8:53")
}

func CloudflareTCPResetChecker() *TCPResetChecker {
	return NewTCPResetChecker("1.1.1.1:53")
}

func NewTCPResetChecker(tcpDNS string) *TCPResetChecker {
	client := &dns.Client{
		Net: "tcp",
	}
	return &TCPResetChecker{
		tcpDNS: tcpDNS,
		client: client,
	}
}

func (c *TCPResetChecker) Check(ctx context.Context, logger *zap.Logger, resultChan chan *CheckResult, fqdn string) {
	var result CheckResult
	result.CheckerName = "TCPResetChecker"

	request := new(dns.Msg)
	request.SetQuestion(fqdn, dns.TypeA)
	reply, rtt, err := c.client.ExchangeContext(ctx, request, c.tcpDNS)
	if err != nil {
		logger.Debug("TCPResetChecker:Check:ExchangeContext:Fail", zap.Uint16("requestID", ctx.Value("requestID").(uint16)), zap.Error(err))
	} else {
		logger.Debug("TCPResetChecker:Check:ExchangeContext:Success", zap.Uint16("requestID", ctx.Value("requestID").(uint16)), zap.Any("AnswerSection", reply.Answer), zap.Duration("Rtt", rtt))
	}

	if err != nil {
		switch err.(type) {
		case *net.OpError:
			if err.(*net.OpError).Err.Error() == "read: connection reset by peer" {
				result.DomainStatus = Blocked
			} else {
				return
			}
		default:
			return
		}
	} else {
		result.DomainStatus = LikelyAvailable
	}

	select {
	case resultChan <- &result:
		return
	case <-ctx.Done():
		return
	}
}
