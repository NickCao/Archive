package checker

import (
	"context"
	"github.com/miekg/dns"
	"go.uber.org/zap"
	"net"
)

type UDPHijackChecker struct {
	fakeDNS string
	client  *dns.Client
}

func Example0UDPHijackChecker() *UDPHijackChecker {
	return NewUDPHijackChecker("99.84.239.46:53")
}

//noinspection GoUnusedExportedFunction
func Example1UDPHijackChecker() *UDPHijackChecker {
	return NewUDPHijackChecker("97.86.234.44:53")
}

func NewUDPHijackChecker(fakeDNS string) *UDPHijackChecker {
	client := &dns.Client{
		Net: "udp",
	}
	return &UDPHijackChecker{
		fakeDNS: fakeDNS,
		client:  client,
	}
}

func (c *UDPHijackChecker) Check(ctx context.Context, logger *zap.Logger, resultChan chan *CheckResult, fqdn string) {
	var result CheckResult
	result.CheckerName = "UDPHijackChecker"

	request := new(dns.Msg)
	request.SetQuestion(fqdn, dns.TypeA)
	reply, rtt, err := c.client.ExchangeContext(ctx, request, c.fakeDNS)
	if err != nil {
		logger.Debug("UDPHijackChecker:Check:ExchangeContext:Fail", zap.Uint16("requestID", ctx.Value("requestID").(uint16)), zap.Error(err))
	} else {
		logger.Debug("UDPHijackChecker:Check:ExchangeContext:Success", zap.Uint16("requestID", ctx.Value("requestID").(uint16)), zap.Any("AnswerSection", reply.Answer), zap.Duration("Rtt", rtt))
	}

	if err != nil {
		switch err.(type) {
		case *net.OpError:
			if err.(*net.OpError).Err.Error() == "i/o timeout" {
				result.DomainStatus = LikelyAvailable
			} else {
				return
			}
		default:
			return
		}
	} else {
		result.DomainStatus = Blocked
	}

	select {
	case resultChan <- &result:
		return
	case <-ctx.Done():
		return
	}

}
