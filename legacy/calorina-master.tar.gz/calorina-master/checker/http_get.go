package checker

import (
	"context"
	"go.uber.org/zap"
	"io"
	"io/ioutil"
	"net"
	"net/http"
	"strings"
	"time"
)

type HTTPGETChecker struct {
	client *http.Client
}

func AliHTTPGETChecker() *HTTPGETChecker {
	return NewHTTPGETChecker("223.6.6.6:53", time.Millisecond*600)
}

func NewHTTPGETChecker(udpDNS string, threshold time.Duration) *HTTPGETChecker {
	dialer := &net.Dialer{
		Timeout: threshold,
		Resolver: &net.Resolver{
			PreferGo: true,
			Dial: func(ctx context.Context, _, _ string) (net.Conn, error) {
				d := &net.Dialer{}
				return d.DialContext(ctx, "udp", udpDNS)
			},
		},
	}
	client := &http.Client{
		Timeout: threshold,
		CheckRedirect: func(req *http.Request, via []*http.Request) error {
			return http.ErrUseLastResponse
		},
		Transport: &http.Transport{
			DialContext:       dialer.DialContext,
			DisableKeepAlives: true,
		},
	}
	return &HTTPGETChecker{client: client}
}

func (c *HTTPGETChecker) Check(ctx context.Context, logger *zap.Logger, resultChan chan *CheckResult, fqdn string) {
	var result CheckResult
	result.CheckerName = "HTTPGETChecker"

	endpoint := "https://" + strings.TrimSuffix(fqdn, ".")
	resp, err := c.client.Get(endpoint)
	if err != nil {
		logger.Debug("HTTPGETChecker:Check:Get:Fail", zap.Uint16("requestID", ctx.Value("requestID").(uint16)), zap.Error(err))
	} else {
		defer resp.Body.Close()
		defer io.Copy(ioutil.Discard, resp.Body)
		logger.Debug("HTTPGETChecker:Check:Get:Success", zap.Uint16("requestID", ctx.Value("requestID").(uint16)), zap.String("endpoint", endpoint))
	}

	if err != nil {
		result.DomainStatus = Blocked
	} else {
		result.DomainStatus = Available
	}

	select {
	case resultChan <- &result:
		return
	case <-ctx.Done():
		return
	}
}
