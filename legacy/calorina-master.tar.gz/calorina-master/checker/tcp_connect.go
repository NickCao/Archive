package checker

import (
	"context"
	"go.uber.org/zap"
	"net"
	"strings"
	"time"
)

type TCPConnectChecker struct {
	dialer *net.Dialer
}

func AliTCPConnectChecker() *TCPConnectChecker {
	return NewTCPConnectChecker("223.6.6.6:53", time.Millisecond*600)
}

func NewTCPConnectChecker(udpDNS string, threshold time.Duration) *TCPConnectChecker {
	dialer := &net.Dialer{
		Timeout: threshold,
		Resolver: &net.Resolver{
			PreferGo: true,
			Dial: func(ctx context.Context, _, _ string) (net.Conn, error) {
				d := &net.Dialer{}
				return d.DialContext(ctx, "udp", udpDNS)
			},
		},
	}
	return &TCPConnectChecker{dialer: dialer}
}

func (c *TCPConnectChecker) Check(ctx context.Context, logger *zap.Logger, resultChan chan *CheckResult, fqdn string) {
	var result CheckResult
	result.CheckerName = "TCPConnectChecker"

	endpoint := strings.TrimSuffix(fqdn, ".") + ":443"
	conn, err := c.dialer.DialContext(ctx, "tcp", endpoint)
	if err != nil {
		logger.Debug("TCPConnectChecker:Check:DialContext:Fail", zap.Uint16("requestID", ctx.Value("requestID").(uint16)), zap.Error(err))
	} else {
		//noinspection GoUnhandledErrorResult
		defer conn.Close()
		logger.Debug("TCPConnectChecker:Check:DialContext:Success", zap.Uint16("requestID", ctx.Value("requestID").(uint16)), zap.String("endpoint", endpoint))
	}

	if err != nil {
		switch err.(type) {
		case *net.OpError:
			if err.(*net.OpError).Err.Error() == "i/o timeout" {
				result.DomainStatus = Blocked
			} else {
				return
			}
		default:
			return
		}
	} else {
		result.DomainStatus = Available
	}

	select {
	case resultChan <- &result:
		return
	case <-ctx.Done():
		return
	}
}
