package localcache

import (
	"github.com/miekg/dns"
	"github.com/patrickmn/go-cache"
	"time"
)

type LocalCache struct {
	c *cache.Cache
}

func NewLocalCache() *LocalCache{
	return &LocalCache{c:cache.New(time.Minute,time.Second*30)}
}

func (l *LocalCache) Save(req *dns.Msg, reply *dns.Msg){
	var minTTL uint32
	for _, ans := range reply.Answer{
		if  minTTL == 0 || ans.Header().Ttl < minTTL{
			minTTL = ans.Header().Ttl
		}
	}
	l.c.Set(req.Question[0].String(),reply,time.Duration(minTTL)*time.Second)
}

func (l *LocalCache) Fetch(req *dns.Msg) (*dns.Msg,bool){
	m, ok := l.c.Get(req.Question[0].String())
	if !ok{
		return nil, false
	}
	reply := m.(*dns.Msg).Copy()
	reply.SetReply(req)
	return reply,true
}