package metachecker

import (
	"context"
	"gitlab.com/NickCao/calorina/v4/checker"
	"go.uber.org/zap"
)

type FirstFirmMetaChecker struct {
	checkers []checker.Checker
}

func DefaultFirstFirmMetaChecker() *FirstFirmMetaChecker {
	return NewFirstFirmMetaChecker(checker.AliTCPConnectChecker(), checker.GoogleTCPResetChecker(),
		checker.CloudflareTCPResetChecker(), checker.Example0UDPHijackChecker(), checker.AliHTTPGETChecker())
}

func NewFirstFirmMetaChecker(checkers ...checker.Checker) *FirstFirmMetaChecker {
	return &FirstFirmMetaChecker{checkers: checkers}
}

func (c *FirstFirmMetaChecker) Check(ctx context.Context, logger *zap.Logger, resultChan chan *checker.CheckResult, fqdn string) {
	tmpResultChan := make(chan *checker.CheckResult, len(c.checkers))
	var result checker.CheckResult
	result.CheckerName = "FirstFirmMetaChecker"
	for _, realChecker := range c.checkers {
		go realChecker.Check(ctx, logger, tmpResultChan, fqdn)
	}

outerloop:
	for {
		select {
		case tmpResult := <-tmpResultChan:
			if tmpResult.DomainStatus == checker.Blocked || tmpResult.DomainStatus == checker.Available {
				result.DomainStatus = tmpResult.DomainStatus
				logger.Debug("FirstFirmMetaChecker:Check:Hit", zap.Uint16("requestID", ctx.Value("requestID").(uint16)), zap.String("RealChecker", tmpResult.CheckerName))
				break outerloop
			}
		case <-ctx.Done():
			return
		}
	}

	select {
	case resultChan <- &result:
		return
	case <-ctx.Done():
		return
	}
}
