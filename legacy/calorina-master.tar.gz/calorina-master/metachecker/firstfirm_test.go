package metachecker

import (
	"context"
	"gitlab.com/NickCao/calorina/v4/checker"
	"go.uber.org/zap"
	"testing"
)

func TestFirstFirmMetaChecker(t *testing.T) {
	c := DefaultFirstFirmMetaChecker()
	resultChan := make(chan *checker.CheckResult)
	logger, err := zap.NewDevelopment()
	if err != nil {
		t.Error(err)
	}

	go c.Check(context.WithValue(context.Background(), "requestID", uint16(0)), logger, resultChan, "www.baidu.com.")
	result := <-resultChan
	if result.DomainStatus != checker.Available {
		t.Error()
	}

	go c.Check(context.WithValue(context.Background(), "requestID", uint16(0)), logger, resultChan, "www.google.com.")
	result = <-resultChan
	if result.DomainStatus != checker.Blocked {
		t.Error()
	}
}
