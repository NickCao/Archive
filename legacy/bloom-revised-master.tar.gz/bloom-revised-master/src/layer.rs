use bloom::BloomFilter;
use bloom::ASMS;
use std::collections::hash_map::RandomState;
use std::hash::Hash;

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn test_bloom_layer() {
        let mut l = Layer::with_rate(0.00000001, 100000000);
        l.mark_positive(&"1");
        l.mark_positive(&"3");
        assert_eq!(l.check(&"1"), State::Positive);
        assert_eq!(l.check(&"3"), State::Positive);
        assert_eq!(l.check(&"2"), State::Negative);
        l.mark_revised(&"3");
        assert_eq!(l.check(&"3"), State::Revised);
    }
}

#[derive(PartialEq, Debug)]
pub enum State {
    Positive,
    Negative,
    Revised,
}

pub struct Layer {
    primary: BloomFilter<RandomState, RandomState>,
    revision: BloomFilter<RandomState, RandomState>,
}

impl Layer {
    pub fn with_size(num_bits: usize, num_hashes: u32) -> Layer {
        Layer {
            primary: BloomFilter::with_size(num_bits, num_hashes),
            revision: BloomFilter::with_size(num_bits, num_hashes),
        }
    }
    pub fn with_rate(rate: f32, expected_num_items: u32) -> Layer {
        Layer {
            primary: BloomFilter::with_rate(rate, expected_num_items),
            revision: BloomFilter::with_rate(rate, expected_num_items),
        }
    }
    pub fn check<T: Hash>(&self, item: &T) -> State {
        if self.revision.contains(item) {
            State::Revised
        } else if self.primary.contains(item) {
            State::Positive
        } else {
            State::Negative
        }
    }
    pub fn mark_positive<T: Hash>(&mut self, item: &T) {
        self.primary.insert(item);
    }
    pub fn mark_revised<T: Hash>(&mut self, item: &T) {
        self.revision.insert(item);
    }
}
