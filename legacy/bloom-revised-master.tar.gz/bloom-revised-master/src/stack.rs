use crate::layer::Layer;
use crate::layer::State;
use std::hash::Hash;

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn test_bloom_stack() {
        let mut s = Stack::new(Variant::WithRate(0.00000001, 100000000));
        s.mark_positive(&"1");
        s.mark_positive(&"3");
        s.mark_negative(&"3");
        s.mark_positive(&"3");
        s.mark_negative(&"3");
        s.mark_positive(&"3");
        s.mark_negative(&"3");
        s.mark_positive(&"4");
        s.mark_negative(&"4");
        s.mark_positive(&"4");
        assert_eq!(s.scheck(&"1"), State::Positive);
        assert_eq!(s.scheck(&"4"), State::Positive);
        assert_eq!(s.scheck(&"3"), State::Negative);
        assert_eq!(s.scheck(&"2"), State::Negative);
        dbg!(s.layers.len());
    }
}

pub enum Variant {
    WithSize(usize, u32),
    WithRate(f32, u32),
}

pub struct Stack {
    layers: Vec<Layer>,
    var: Variant,
}

impl Stack {
    pub fn new(var: Variant) -> Stack {
        let l0 = match var {
            Variant::WithRate(j, k) => Layer::with_rate(j, k),
            Variant::WithSize(p, q) => Layer::with_size(p, q),
        };
        let mut layers = Vec::new();
        layers.push(l0);
        Stack { layers, var }
    }

    pub fn check<T: Hash>(&self, item: &T) -> (State, usize) {
        for (i, l) in self.layers.iter().enumerate() {
            match l.check(item) {
                State::Revised => continue,
                State::Negative => return (State::Negative, i),
                State::Positive => return (State::Positive, i),
            }
        }
        (State::Negative, 0)
    }

    pub fn scheck<T: Hash>(&self, item: &T) -> State {
        self.check(item).0
    }

    fn new_layer(&mut self) {
        let l1 = match self.var {
            Variant::WithRate(j, k) => Layer::with_rate(j, k),
            Variant::WithSize(p, q) => Layer::with_size(p, q),
        };
        self.layers.push(l1);
    }

    pub fn mark_positive<T: Hash>(&mut self, item: &T) {
        match self.check(item) {
            (State::Positive, _) => return,
            (State::Revised, _) => return,
            (State::Negative, i) => {
                self.layers[i].mark_positive(item);
                return;
            }
        }
    }

    pub fn mark_negative<T: Hash>(&mut self, item: &T) {
        match self.check(item) {
            (State::Negative, _) => return,
            (State::Positive, i) => {
                self.layers[i].mark_revised(item);
                if i == self.layers.len() - 1 {
                    self.new_layer();
                }
                return;
            }
            (State::Revised, _) => return,
        }
    }
}
