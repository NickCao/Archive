apt update
apt install frr babeld mtr iperf3 bridge-utils -y
ip link add dev vx100 type vxlan vni 100
ip link add dev vx101 type vxlan vni 101 nolearning
brctl addbr stubbr
brctl addif stubbr vx101
ip link set up dev vx100
ip link set up dev vx101
bridge fdb add 00:00:00:00:00:00 dst 35.161.238.236 dev vx100
ip addr add 10.47.<ask for allocation>/16 dev vx100
# copy and edit the frr config
# enable bgpd in daemons file
# restart frr daemon
