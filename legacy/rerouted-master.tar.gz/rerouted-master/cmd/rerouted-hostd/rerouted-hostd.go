package main

import (
	"log"
	"net"

	"github.com/songgao/water"
	"gitlab.com/NickCao/rerouted"
)

func main() {
	hosttun, err := water.New(water.Config{
		DeviceType: water.TUN,
		PlatformSpecificParams: water.PlatformSpecificParams{
			Name:       "rtd-tun-host",
			Persist:    true,
			MultiQueue: true,
		},
	})
	if err != nil {
		log.Fatal(err)
	}

	laddr, _ := net.ResolveUDPAddr("udp", "192.168.11.1:8765")
	raddr, _ := net.ResolveUDPAddr("udp", "192.168.11.2:8765")
	conn, err := net.DialUDP("udp", laddr, raddr)
	if err != nil {
		log.Fatal(err)
	}
	go rerouted.TUN2UDP(hosttun, conn, 1600, rerouted.StubFilter)
	go rerouted.UDP2TUN(conn, hosttun, 1600, printFilter)
	for {
	}
}

func printFilter(b []byte) bool {
	log.Print(string(b))
	return false
}
