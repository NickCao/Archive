package main

import (
	"log"
	"os"
	"os/exec"
	"os/signal"
	"syscall"
)

func main() {
	c := make(chan os.Signal)
	signal.Notify(c, os.Interrupt, syscall.SIGTERM)
	go func() {
		<-c
		cleanup()
		os.Exit(1)
	}()
	prepare()
	hostd := exec.Command("rerouted-hostd")
	hostd.Stdout = os.Stdout
	hostd.Stderr = os.Stderr
	hostd.Start()
	nsd := exec.Command("ip", "netns", "exec", "rtd-ns", "rerouted-nsd")
	nsd.Stdout = os.Stdout
	nsd.Stderr = os.Stderr
	nsd.Start()
	for {
	}
}

const realif = "wlp7s0"

func prepare() {
	var err error
	err = exec.Command("ip", "netns", "add", "rtd-ns").Run()
	if err != nil {
		log.Print(err)
		return
	}
	err = exec.Command("ip", "link", "add", "rtd-veth-host", "type", "veth", "peer", "name", "rtd-veth-ns").Run()
	if err != nil {
		log.Print(err)
		return
	}
	err = exec.Command("ip", "link", "set", "rtd-veth-ns", "netns", "rtd-ns").Run()
	if err != nil {
		log.Print(err)
		return
	}
	err = exec.Command("ip", "tuntap", "add", "mode", "tun", "multi_queue", "name", "rtd-tun-host").Run()
	if err != nil {
		log.Print(err)
		return
	}
	err = exec.Command("ip", "netns", "exec", "rtd-ns", "ip", "tuntap", "add", "mode", "tun", "multi_queue", "name", "rtd-tun-ns").Run()
	if err != nil {
		log.Print(err)
		return
	}
	err = exec.Command("ip", "addr", "add", "192.168.11.1/24", "dev", "rtd-veth-host").Run()
	if err != nil {
		log.Print(err)
		return
	}
	err = exec.Command("ip", "addr", "add", "192.168.12.1/24", "dev", "rtd-tun-host").Run()
	if err != nil {
		log.Print(err)
		return
	}
	err = exec.Command("ip", "link", "set", "rtd-veth-host", "up").Run()
	if err != nil {
		log.Print(err)
		return
	}
	err = exec.Command("ip", "link", "set", "rtd-tun-host", "up").Run()
	if err != nil {
		log.Print(err)
		return
	}
	err = exec.Command("sysctl", "-w", "net.ipv4.ip_forward=1").Run()
	if err != nil {
		log.Print(err)
		return
	}
	err = exec.Command("iptables", "-A", "FORWARD", "-i", "rtd-veth-host", "-j", "ACCEPT").Run()
	if err != nil {
		log.Print(err)
		return
	}
	err = exec.Command("iptables", "-A", "FORWARD", "-i", "rtd-tun-host", "-j", "ACCEPT").Run()
	if err != nil {
		log.Print(err)
		return
	}
	err = exec.Command("iptables", "-t", "nat", "-A", "POSTROUTING", "-o", realif, "-j", "MASQUERADE").Run()
	if err != nil {
		log.Print(err)
		return
	}
	err = exec.Command("ip", "netns", "exec", "rtd-ns", "ip", "addr", "add", "192.168.11.2/24", "dev", "rtd-veth-ns").Run()
	if err != nil {
		log.Print(err)
		return
	}
	err = exec.Command("ip", "netns", "exec", "rtd-ns", "ip", "addr", "add", "192.168.12.2/24", "dev", "rtd-tun-ns").Run()
	if err != nil {
		log.Print(err)
		return
	}
	err = exec.Command("ip", "netns", "exec", "rtd-ns", "ip", "link", "set", "rtd-veth-ns", "up").Run()
	if err != nil {
		log.Print(err)
		return
	}
	err = exec.Command("ip", "netns", "exec", "rtd-ns", "ip", "link", "set", "rtd-tun-ns", "up").Run()
	if err != nil {
		log.Print(err)
		return
	}
	err = exec.Command("ip", "netns", "exec", "rtd-ns", "ip", "route", "add", "default", "via", "192.168.11.1").Run()
	if err != nil {
		log.Print(err)
		return
	}
	err = exec.Command("ip", "netns", "exec", "rtd-ns", "ip", "route", "add", "1.1.1.1", "via", "192.168.12.1").Run()
	if err != nil {
		log.Print(err)
		return
	}
}

func cleanup() {
	var err error
	log.Print("cleaningup")
	err = exec.Command("ip", "netns", "del", "rtd-ns").Run()
	if err != nil {
		log.Print(err)

	}
	err = exec.Command("ip", "link", "del", "rtd-tun-host").Run()
	if err != nil {
		log.Print(err)

	}
	err = exec.Command("iptables", "-t", "nat", "-D", "POSTROUTING", "-o", realif, "-j", "MASQUERADE").Run()
	if err != nil {
		log.Print(err)
	}
}
