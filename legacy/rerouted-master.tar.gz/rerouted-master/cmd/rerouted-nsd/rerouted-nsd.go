package main

import (
	"log"
	"net"

	"github.com/songgao/water"
	"gitlab.com/NickCao/rerouted"
)

func main() {
	nstun, err := water.New(water.Config{
		DeviceType: water.TUN,
		PlatformSpecificParams: water.PlatformSpecificParams{
			Name:       "rtd-tun-ns",
			Persist:    true,
			MultiQueue: true,
		},
	})
	if err != nil {
		log.Fatal(err)
	}

	laddr, _ := net.ResolveUDPAddr("udp", "192.168.11.2:8765")
	raddr, _ := net.ResolveUDPAddr("udp", "192.168.11.1:8765")
	conn, err := net.DialUDP("udp", laddr, raddr)
	if err != nil {
		log.Fatal(err)
	}
	go rerouted.TUN2UDP(nstun, conn, 1600, rerouted.StubFilter)
	go rerouted.UDP2TUN(conn, nstun, 1600, rerouted.StubFilter)
	for {
	}
}
