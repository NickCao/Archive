package rerouted

import (
	"log"
	"net"

	"github.com/songgao/water"
)

type Filter func(b []byte) bool

func StubFilter(b []byte) bool {
	return false
}

func TUN2UDP(tun *water.Interface, conn *net.UDPConn, bufsize int, filter Filter) {
	packet := make([]byte, bufsize)
	for {
		n, err := tun.Read(packet)
		if err != nil {
			log.Println("TUN2UDP:tun.Read:" + err.Error())
			continue
		}
		//header, err := ipv4.ParseHeader(packet[:n])
		//if err != nil {
		//	log.Println("TUN2UDP:ipv4.ParseHeader:" + err.Error())
		//continue
		//}
		//if (header.Version != 4) || (header.Protocol != 6) {
		//	continue
		//}
		//log.Println("TUN2UDP:Header:" + header.String())
		if filter(packet[:n]) {
			log.Println("TUN2UDP:filtered")
			continue
		}
		_, err = conn.Write(packet[:n])
		if err != nil {
			log.Println("TUN2UDP:conn.Write:" + err.Error())
			continue
		}
	}
}

func UDP2TUN(conn *net.UDPConn, tun *water.Interface, bufsize int, filter Filter) {
	packet := make([]byte, bufsize)
	for {
		n, err := conn.Read(packet)
		if err != nil {
			log.Println("UDP2TUN:conn.Read:" + err.Error())
			continue
		}
		//header, err := ipv4.ParseHeader(packet[:n])
		//if err != nil {
		//	log.Println("UDP2TUN:ipv4.ParseHeader:" + err.Error())
		//	continue
		//}
		//if (header.Version != 4) || (header.Protocol != 6) {
		//	continue
		//}
		//log.Println("UDP2TUN:Header:" + header.String())
		if filter(packet[:n]) {
			log.Println("UDP2TUN:filtered")
			continue
		}
		_, err = tun.Write(packet[:n])
		if err != nil {
			log.Println("UDP2TUN:tun.Write:" + err.Error())
			continue
		}
	}
}
