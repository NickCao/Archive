import * as mdc from 'material-components-web';
mdc.autoInit();
import Vue from '../node_modules/vue/dist/vue.min.js';
import axios from 'axios';
import VueAxios from 'vue-axios'
Vue.use(VueAxios, axios)

var app = new Vue({
    el: '#app',
    data: {
        posts: [{ "ID": "01D2CC3FZZCKEMZZSCG6GK2EA6", "Author": "NickCao", "Tags": ["Load", "ing"], "Body": "加载中....." }]

    },
    mounted() {
        this.axios.get("https://starliner-nickcao.herokuapp.com/timeline/9").then((response) => {
            this.posts = response.data
        })
    }
})
