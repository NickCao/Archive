#!/bin/bash
npm run build;
cp index.html static/index.html;
rm static/style-stub-bundle.js;
