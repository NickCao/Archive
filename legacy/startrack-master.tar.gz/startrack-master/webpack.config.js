const path = require('path');
const glob = require('glob');

/* module.exports = [{
  entry: './index.scss',
  output: {
    // This is necessary for webpack to compile
    // But we never use style-bundle.js
    filename: 'bundle-css-stub.js',
  },
  module: {
    rules: [
      {
        test: /\.scss$/,
        use: [
          {
            loader: 'file-loader',
            options: {
              name: 'bundle.css',
            },
          },
          { loader: 'extract-loader' },
          { loader: 'css-loader' },
          {
            loader: 'sass-loader',
            options: {
              includePaths: ['node_modules', 'node_modules/@material/*']
                .map((d) => path.join(__dirname, d))
                .map((g) => glob.sync(g))
                .reduce((a, c) => a.concat(c), [])
            }
          },
        ]
      }
    ]
  },
},
]; */



module.exports = [{
  "mode": "production",
  "entry": "./src/index.js",
  "output": {
    "path": __dirname + '/static',
    "filename": "bundle.js"
  }
},
{
  mode: "production",
  entry: './src/index.scss',
  output: {
    "path": __dirname + '/static',
    // This is necessary for webpack to compile
    filename: 'style-stub-bundle.js',
  },
  module: {
    rules: [
      {
        test: /\.scss$/,
        use: [
          {
            loader: 'file-loader',
            options: {
              name: 'bundle.css',
            },
          },
          { loader: 'extract-loader' },
          { loader: 'css-loader' },
          {
            loader: 'sass-loader',
            options: {
              includePaths: ['node_modules', 'node_modules/@material/*']
                .map((d) => path.join(__dirname, d))
                .map((g) => glob.sync(g))
                .reduce((a, c) => a.concat(c), [])
            }
          },
        ]
      }
    ]
  },
}];