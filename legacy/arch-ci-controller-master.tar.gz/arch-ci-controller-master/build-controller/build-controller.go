package build_controller

import (
	"context"
	"encoding/json"
	"github.com/nats-io/nats.go"
	"gitlab.com/NickCao/arch-ci-controller/common"
	"gitlab.com/NickCao/arch-ci-controller/message"
	"gitlab.com/NickCao/arch-ci-controller/runner"
	"log"
)

const subject string = "archci.build.request"
const queue string = "archci.queue.build.controller"
const image string = "registry.gitlab.com/nickcao/arch-ci-image/build:latest"

type BuildController struct {
	runner  runner.Runner
	nServer string
	nKey    string
}

func NewBuildController(runnerClass runner.RunnerClass, nServer string, nKey string) (*BuildController, error) {
	runner, err := runner.NewRunner(runnerClass)
	if err != nil {
		return nil, err
	}
	return &BuildController{
		runner:  runner,
		nServer: nServer,
		nKey:    nKey,
	}, nil
}

func (c *BuildController) MsgHandler(msg *nats.Msg) {
	buildRequest := &message.BuildRequest{}
	err := json.Unmarshal(msg.Data, buildRequest)
	if err != nil {
		log.Printf("Failed to decode message: %v", err)
		return
	}
	buildReply := &message.BuildReply{}
	buildReply.RunnerClass, buildReply.JobID, buildReply.InitLog,
		err = c.runner.Run(image, append(buildRequest.Environment,
		"ARCHCI_SRC="+buildRequest.Upstream,
		"PACKAGER="+buildRequest.Packager,
		"ARCHCI_PREPARE="+buildRequest.Prepare),
		[]string{"ARCHCI_S3URL"}, nil)
	if err != nil {
		log.Printf("Failed to invoke runner: %v", err)
	}
	reply, err := json.Marshal(buildReply)
	if err != nil {
		log.Printf("Failed to encode reply: %v", err)
		return
	}
	err = msg.Respond(reply)
	if err != nil {
		log.Printf("Failed to send reply: %v", err)
		return
	}
	return
}

func (c *BuildController) ControlLoop(ctx context.Context) error {
	nk, err := common.NKeyOptionFromString(c.nKey)
	if err != nil {
		return err
	}
	conn, err := nats.Connect(c.nServer, nk)
	if err != nil {
		return err
	}
	defer conn.Close()
	sub, err := conn.QueueSubscribe(subject, queue, c.MsgHandler)
	if err != nil {
		return err
	}
	defer sub.Unsubscribe()
	<-ctx.Done()
	return nil
}
