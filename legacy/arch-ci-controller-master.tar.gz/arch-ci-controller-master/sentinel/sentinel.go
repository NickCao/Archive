package sentinel

import (
	"context"
	"encoding/json"
	"github.com/nats-io/nats.go"
	"gitlab.com/NickCao/arch-ci-controller/common"
	"gitlab.com/NickCao/arch-ci-controller/message"
)

const subject string = "archci.build.request"

type Sentinel struct {
	nServer string
	nKey    string
}

func NewSentinel(nServer string, nKey string) *Sentinel {
	return &Sentinel{nServer: nServer, nKey: nKey}
}

func (s *Sentinel) Submit(ctx context.Context, request *message.BuildRequest) (*message.BuildReply, error) {
	nk, err := common.NKeyOptionFromString(s.nKey)
	if err != nil {
		return nil, err
	}
	conn, err := nats.Connect(s.nServer, nk)
	if err != nil {
		return nil, err
	}
	defer conn.Close()

	data, err := json.Marshal(request)
	if err != nil {
		return nil, err
	}
	reply, err := conn.RequestWithContext(ctx, subject, data)
	if err != nil {
		return nil, err
	}
	buildReply := &message.BuildReply{}
	err = json.Unmarshal(reply.Data, buildReply)
	if err != nil {
		return nil, err
	}
	return buildReply, nil
}
