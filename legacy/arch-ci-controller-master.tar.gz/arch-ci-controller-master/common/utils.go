package common

import (
	"fmt"
	"github.com/nats-io/jwt"
	"github.com/nats-io/nats.go"
	"github.com/nats-io/nkeys"
)

func NKeyOptionFromString(nkey string) (nats.Option, error) {
	kp, err := jwt.ParseDecoratedNKey([]byte(nkey))
	if err != nil {
		return nil, err
	}
	pub, err := kp.PublicKey()
	if err != nil {
		return nil, err
	}
	if !nkeys.IsValidPublicUserKey(pub) {
		return nil, fmt.Errorf("Not a valid nkey user seed")
	}
	sigCB := func(nonce []byte) ([]byte, error) {
		sig, _ := kp.Sign(nonce)
		return sig, nil
	}
	return nats.Nkey(string(pub), sigCB), nil
}

func GetCurrentVersion(pkgname string) string{
	return "1-1"
}
