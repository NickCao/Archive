package common

import (
	"testing"
)

func TestNKeyOptionFromString(t *testing.T) {
	_,err := NKeyOptionFromString("SUAH2RPQ37A4TLFSDRE26CJGFLAU5AZ2D54HF7OTUWJURLNMQZ3FJFNW34")
	if err != nil{
		t.Fatal(err)
	}
}