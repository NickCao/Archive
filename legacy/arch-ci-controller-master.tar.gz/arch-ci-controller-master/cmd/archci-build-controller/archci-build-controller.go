package main

import (
	"context"
	"flag"
	build_controller "gitlab.com/NickCao/arch-ci-controller/build-controller"
	"gitlab.com/NickCao/arch-ci-controller/runner"
	"log"
)

var nSever = flag.String("s", "127.0.0.1:4222", "url of nats server")
var nKey = flag.String("k", "", "NKey")
var runnerClass = flag.String("r", "stub", "class of runner to schedule on")

func main(){
	flag.Parse()
	c,err :=build_controller.NewBuildController(runner.RunnerClass(*runnerClass),*nSever,*nKey)
	if err != nil{
		log.Fatal(err)
	}
	err = c.ControlLoop(context.Background())
	if err != nil{
		log.Fatal(err)
	}
}