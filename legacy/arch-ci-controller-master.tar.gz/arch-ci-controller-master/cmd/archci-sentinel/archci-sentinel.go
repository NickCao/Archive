package main

import (
	"context"
	"flag"
	"gitlab.com/NickCao/arch-ci-controller/message"
	"gitlab.com/NickCao/arch-ci-controller/sentinel"
	"log"
)

var nSever = flag.String("s", "127.0.0.1:4222", "url of nats server")
var nKey = flag.String("k", "", "NKey")
var upstream = flag.String("u", "", "vcs url of the package to build")
var packager = flag.String("p", "Arch CI <archci@nichi.co>", "name of the packager")
var prepare = flag.String("pre", "", "script for preparation")

func main() {
	flag.Parse()
	if len(*upstream) == 0 {
		log.Fatal("upstream not set")
	}
	s := sentinel.NewSentinel(*nSever, *nKey)
	var request message.BuildRequest
	request.Upstream = *upstream
	request.Prepare = *prepare
	request.Packager = *packager
	reply, err := s.Submit(context.Background(), &request)
	if err != nil {
		log.Fatal(err)
	}
	log.Printf("started build of %v on %v with JobID %v, Initlog: %v", *upstream, reply.RunnerClass, reply.JobID, reply.InitLog)
}
