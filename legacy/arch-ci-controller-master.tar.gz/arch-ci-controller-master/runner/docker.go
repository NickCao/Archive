package runner

import (
	"context"
	"fmt"
	"github.com/docker/docker/api/types"
	"github.com/docker/docker/api/types/container"
	"github.com/docker/docker/client"
	"log"
	"os"
)

type DockerRunner struct {
	client *client.Client
}

func NewDockerRunnerFromEnv() (*DockerRunner, error) {
	runner := &DockerRunner{}
	var err error
	runner.client, err = client.NewEnvClient()
	if err != nil {
		return nil, err
	}
	return runner, nil
}

func (r *DockerRunner) Run(image string, env []string, secrets []string, entry []string) (RunnerClass, JobID, InitLog, error) {
	for index, key := range secrets {
		secrets[index] = key + "=" + os.Getenv(key)
	}
	containerConfig := &container.Config{
		Env:        append(env, secrets...),
		Image:      image,
		Entrypoint: entry,
	}
	hostConfig := &container.HostConfig{
		RestartPolicy: container.RestartPolicy{
			Name:              "no",
			MaximumRetryCount: 0,
		},
		//AutoRemove:      true,
	}
	var cont container.ContainerCreateCreatedBody
	var err error
	cont, err = r.client.ContainerCreate(context.Background(), containerConfig, hostConfig, nil, "")
	if err != nil {
		log.Printf("Failed container creation: %v", err)
		return Docker, "", InitLog(err.Error()), err
	}
	startOptions := types.ContainerStartOptions{}
	err = r.client.ContainerStart(context.Background(), cont.ID, startOptions)
	if err != nil {
		log.Printf("Failed container start: %v", err)
		return Docker, JobID(cont.ID), InitLog(err.Error()), err
	}
	return Docker,JobID(cont.ID),InitLog(fmt.Sprint(cont.Warnings)),nil
}
