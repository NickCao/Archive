package runner

import "fmt"

type RunnerClass string
type JobID string
type InitLog string

const (
	Stub       RunnerClass = "stub"
	Docker                 = "docker"
	Kubernetes             = "kubernetes"
)

type Runner interface {
	Run(image string, environment []string, secrets []string, entrypoint []string) (RunnerClass, JobID, InitLog, error)
}

func NewRunner(class RunnerClass) (Runner,error){
	switch class{
	case Stub:
		return NewStubRunner(),nil
	case Docker:
		return NewDockerRunnerFromEnv()
	default:
		return nil, fmt.Errorf("Runner not implemented: %v", class)
	}
}

type StubRunner struct{}

func NewStubRunner() *StubRunner{
	return &StubRunner{}
}

func (r *StubRunner) Run(image string, environment []string, secrets []string, entrypoint []string) (RunnerClass, JobID, InitLog, error) {
	id, err := GenerateJobID()
	if err != nil {
		return Stub, "", "", err
	}
	return Stub, id, InitLog(fmt.Sprintf("Running image %v with environment %v", image, environment)), nil
}
