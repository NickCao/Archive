package message

import "gitlab.com/NickCao/arch-ci-controller/runner"

type BuildRequest struct{
	Upstream string
	Packager string
	Prepare string
	Environment []string
}

type BuildReply struct {
	RunnerClass runner.RunnerClass
	JobID runner.JobID
	InitLog runner.InitLog
}
