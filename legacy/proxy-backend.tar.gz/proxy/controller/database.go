package main

import (
	"errors"
	"github.com/jinzhu/gorm"
	_ "github.com/jinzhu/gorm/dialects/sqlite"
)

type User struct {
	Username string `json:"username" gorm:"primary_key;not null"`
	Password string `json:"password" gorm:"not null"`
	Upstream string `json:"upstream"`
	Traffic  int64  `json:"traffic"`
}

type Database struct {
	DB *gorm.DB
}

func NewDatabase(path string) (*Database, error) {
	db, err := gorm.Open("sqlite3", path)
	if err != nil {
		return nil, err
	}
	err = db.AutoMigrate(&User{}).Error
	if err != nil {
		return nil, err
	}
	return &Database{DB: db}, nil
}

func (d *Database) Close() error {
	return d.DB.Close()
}

func (d *Database) CreateUser(user *User) error {
	return d.DB.Create(user).Error
}

func (d *Database) DeleteUser(user *User) error {
	if user.Username == "" {
		return errors.New("must specify a username to delete")
	}
	return d.DB.Delete(user).Error
}

func (d *Database) GetUser(user *User) error {
	if user.Username == "" {
		return errors.New("must specify a username to get")
	}
	return d.DB.Model(user).First(user).Error
}

func (d *Database) UpdateUser(user *User) error {
	if user.Username == "" {
		return errors.New("must specify a username to update")
	}
	return d.DB.Model(user).Updates(user).Error
}

func (d *Database) ChangeTraffic(user *User, amount int64) error {
	if user.Username == "" {
		return errors.New("must specify a username to update traffic")
	}
	return d.DB.Transaction(func(tx *gorm.DB) error {
		if err := tx.Model(user).First(user).Error; err != nil {
			return err
		}
		return tx.Model(&user).Update("traffic", user.Traffic+amount).Error
	})
}
