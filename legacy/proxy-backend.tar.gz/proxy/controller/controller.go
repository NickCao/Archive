package main

import (
	"crypto/subtle"
	"flag"
	"github.com/labstack/echo"
	"github.com/labstack/echo/middleware"
	"log"
	"net/http"
	"strconv"
)

var configFile = flag.String("c", "config.hcl", "path to config file")

func main() {
	flag.Parse()
	config, err := LoadConfig(*configFile)
	if err != nil {
		log.Fatal(err)
	}

	db, err := NewDatabase(config.Database)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	e := echo.New()
	e.Use(middleware.Logger())
	e.Use(middleware.BasicAuth(func(username, password string, c echo.Context) (bool, error) {
		if subtle.ConstantTimeCompare([]byte(username), []byte(config.Username)) == 1 &&
			subtle.ConstantTimeCompare([]byte(password), []byte(config.Password)) == 1 {
			return true, nil
		}
		return false, nil
	}))

	e.POST("/user", func(context echo.Context) error {
		var user User
		err := context.Bind(&user)
		if err != nil {
			context.Logger().Error(err)
			return context.String(http.StatusBadRequest, err.Error())
		}

		err = db.CreateUser(&user)
		if err != nil {
			context.Logger().Error(err)
			return context.String(http.StatusInternalServerError, err.Error())
		}

		return context.JSON(http.StatusOK, user)
	})

	e.PUT("/user/:username", func(context echo.Context) error {
		var user User
		err := context.Bind(&user)
		if err != nil {
			context.Logger().Error(err)
			return context.String(http.StatusBadRequest, err.Error())
		}
		user.Username = context.Param("username")
		err = db.UpdateUser(&user)
		if err != nil {
			context.Logger().Error(err)
			return context.String(http.StatusInternalServerError, err.Error())
		}
		return context.JSON(http.StatusOK, user)
	})

	e.GET("/user/:username", func(context echo.Context) error {
		user := User{
			Username: context.Param("username"),
		}
		err := db.GetUser(&user)
		if err != nil {
			context.Logger().Error(err)
			return context.String(http.StatusInternalServerError, err.Error())
		}
		return context.JSON(http.StatusOK, user)
	})

	e.DELETE("/user/:username", func(context echo.Context) error {
		user := User{
			Username: context.Param("username"),
		}
		err := db.GetUser(&user)
		if err != nil {
			context.Logger().Error(err)
			return context.String(http.StatusInternalServerError, err.Error())
		}
		err = db.DeleteUser(&user)
		if err != nil {
			context.Logger().Error(err)
			return context.String(http.StatusInternalServerError, err.Error())
		}
		return context.JSON(http.StatusOK, user)
	})

	e.GET("/traffic/:username", func(context echo.Context) error {
		amount, err := strconv.Atoi(context.QueryParam("amount"))
		if err != nil {
			context.Logger().Error(err)
			return context.String(http.StatusBadRequest, err.Error())
		}
		user := User{
			Username: context.Param("username"),
		}
		err = db.ChangeTraffic(&user, int64(amount))
		if err != nil {
			context.Logger().Error(err)
			return context.JSON(http.StatusInternalServerError, err.Error())
		}
		return context.JSON(http.StatusOK, user)
	})

	e.Logger.Fatal(e.Start(config.Address))
}
