package main

import (
	"github.com/hashicorp/hcl/v2/hclsimple"
)

type Config struct {
	Address  string `hcl:"address,optional"`
	Username string `hcl:"username,attr"`
	Password string `hcl:"password,attr"`
	Database string `hcl:"database,optional"`
}

func LoadConfig(path string) (*Config, error) {
	var config = Config{
		Address:  ":8081",
		Database: "controller.db",
	}
	err := hclsimple.DecodeFile(path, nil, &config)
	if err != nil {
		return nil, err
	}
	return &config, nil
}
