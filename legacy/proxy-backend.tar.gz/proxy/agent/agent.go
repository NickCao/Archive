package main

import (
	"bufio"
	"crypto/tls"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"net/url"
	"sync"
)

type User struct {
	Username string `json:"username"`
	Password string `json:"password"`
	Upstream string `json:"upstream"`
	Traffic  int64  `json:"traffic"`
}

var configFile = flag.String("c", "config.hcl", "agent configuration file")

func main() {
	log.Println("agent started")
	flag.Parse()
	config, err := LoadConfig(*configFile)
	if err != nil {
		log.Fatal(err)
	}
	log.Println("config loaded")
	log.Fatal(http.ListenAndServe(config.Address, &handler{config: config}))
}

type handler struct {
	config *Config
}

func (h *handler) ServeHTTP(writer http.ResponseWriter, request *http.Request) {
	if request.Method != "CONNECT" {
		http.Error(writer, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	request.Header.Set("Authorization", request.Header.Get("Proxy-Authorization"))
	username, password, ok := request.BasicAuth()
	if !ok {
		http.Error(writer, "Proxy auth required", http.StatusProxyAuthRequired)
		return
	}
	log.Printf("connect: %s %s", username, password)

	resp, err := http.Get(fmt.Sprintf("%s/user/%s", h.config.Controller, username))
	if err != nil {
		log.Printf("connect: %s %s: controller error: %s", username, password, err)
		http.Error(writer, "Forbidden", http.StatusForbidden)
		return
	}

	var user User
	err = json.NewDecoder(resp.Body).Decode(&user)
	if err != nil {
		log.Printf("connect: %s %s: controller error: %s", username, password, err)
		http.Error(writer, "Forbidden", http.StatusForbidden)
		return
	}

	if user.Password != password || user.Traffic < 0 {
		log.Printf("connect: %s %s: no traffic or wrong password", username, password)
		http.Error(writer, "Forbidden", http.StatusForbidden)
		return
	}
	log.Printf("connect: %s %s: success", username, password)

	remote, err := DialWithProxy(request.Host, user.Upstream)
	if err != nil {
		log.Printf("connect: %s: upstream failed: %s", username, err)
		http.Error(writer, "Gateway timeout", http.StatusGatewayTimeout)
		return
	}
	writer.WriteHeader(http.StatusOK)

	hijacker, ok := writer.(http.Hijacker)
	if !ok {
		http.Error(writer, "Internal error", http.StatusInternalServerError)
		return
	}

	local, _, err := hijacker.Hijack()
	if err != nil {
		log.Println(err)
		http.Error(writer, "Internal error", http.StatusInternalServerError)
		return
	}
	log.Printf("connect: %s: upstream succeed", username)

	var in, out int64
	var wg sync.WaitGroup
	wg.Add(2)
	go func() {
		defer wg.Done()
		in, _ = transfer(local, remote)
	}()
	go func() {
		defer wg.Done()
		out, _ = transfer(remote, local)
	}()
	wg.Wait()

	_, err = http.Get(fmt.Sprintf("%s/traffic/%s?amount=%d", h.config.Controller, username, -1*(in+out)))
	if err != nil {
		log.Printf("connect: %s: traffic report failed: %s", username, err)
		return
	}
	log.Printf("connect: %s: traffic report succeed", username)
}

func transfer(dst io.WriteCloser, src io.Reader) (int64, error) {
	defer dst.Close()
	return io.Copy(dst, src)
}

func DialWithProxy(host, proxy string) (net.Conn, error) {
	upstream, err := url.Parse(proxy)
	if err != nil {
		return nil, err
	}

	var conn net.Conn
	switch upstream.Scheme {
	case "http":
		conn, err = net.Dial("tcp", upstream.Host)
	case "https":
		conn, err = tls.Dial("tcp", upstream.Host, nil)
	default:
		return nil, errors.New("unsupported proxy scheme")
	}
	if err != nil {
		return nil, err
	}

	request, err := http.NewRequest("CONNECT", "//"+host, nil)
	if err != nil {
		return nil, err
	}

	if upstream.User != nil {
		username := upstream.User.Username()
		password, _ := upstream.User.Password()
		request.SetBasicAuth(username, password)
		request.Header.Set("Proxy-Authorization", request.Header.Get("Authorization"))
		request.Header.Del("Authorization")
	}

	err = request.Write(conn)
	if err != nil {
		return nil, err
	}

	response, err := http.ReadResponse(bufio.NewReader(conn), request)
	if err != nil || response.StatusCode != http.StatusOK {
		return nil, errors.New("connect to upstream failed")
	}

	return conn, nil
}
