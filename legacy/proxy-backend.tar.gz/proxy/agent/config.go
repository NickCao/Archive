package main

import (
	"github.com/hashicorp/hcl/v2/hclsimple"
)

type Config struct {
	Address    string `hcl:"address,optional"`
	Controller string `hcl:"controller,optional"`
}

func LoadConfig(path string) (*Config, error) {
	var config = Config{
		Address:    ":8080",
		Controller: "127.0.0.1:8081",
	}
	err := hclsimple.DecodeFile(path, nil, &config)
	if err != nil {
		return nil, err
	}
	return &config, nil
}
