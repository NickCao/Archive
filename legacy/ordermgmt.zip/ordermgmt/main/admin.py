from django.contrib import admin

# Register your models here.

from .models import *
admin.site.register(项目)
admin.site.register(到款明细)
admin.site.register(开票明细)
admin.site.register(发货明细)
