from django.shortcuts import render, get_object_or_404, HttpResponseRedirect
from django.views.generic import TemplateView
from django_filters.views import FilterView
from django_filters import FilterSet
from django_tables2.views import SingleTableMixin
from .models import *
from .tables import *
from .forms import *
from django.contrib.auth.decorators import login_required
# Create your views here.


class 项目Filter(FilterSet):
    class Meta:
        model = 项目
        fields = {
            "项目编号": ["exact"],
            "项目名称": ["exact"],
            "用户单位": ["exact"],
            "合同签订日期": ["lt", "gt"],
        }


class 到款明细Filter(FilterSet):
    class Meta:
        model = 到款明细
        fields = {
            "工作令": ["exact"],
            "凭证号": ["exact"],
            "客户公司名称": ["exact"],
            "到款日期": ["lt", "gt"],
        }

class 开票明细Filter(FilterSet):
    class Meta:
        model = 开票明细
        fields = {
            "工作令": ["exact"],
            "发票号码": ["exact"],
            "公司名称": ["exact"],
            "开票日期": ["lt", "gt"],
        }

class 发货明细Filter(FilterSet):
    class Meta:
        model = 发货明细
        fields = {
            "工作令": ["exact"],
            "送货单号码": ["exact"],
            "客户名称": ["exact"],
            "开单日期": ["lt", "gt"],
        }

class 目录View(TemplateView):
    template_name = "main/目录.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["最新项目"] = 项目.objects.all()[:3]
        context["最新到款"] = 到款明细.objects.all()[:3]
        context["最新开票"] = 开票明细.objects.all()[:3]
        context["最新发货"] = 发货明细.objects.all()[:3]
        return context


class 项目实施表View(TemplateView):
    template_name = "main/项目实施表.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        f = 项目Filter(self.request.GET, queryset=项目.objects.all())
        context["filter"] = f
        return context


class 项目实施表详情View(TemplateView):
    template_name = "main/详情.html"

    def get_context_data(self, *args, **kwargs):
        context = super().get_context_data(*args, **kwargs)
        context["详情"] = get_object_or_404(项目, pk=kwargs["id"])
        return context

def 项目实施表新建View(request):
    if request.method == 'POST':
        form = 项目Form(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/项目实施表/'+form.cleaned_data.get("项目编号"))
    else:
        form = 项目Form()

    return render(request, 'main/新建.html', {'form': form, "post_url": "/项目实施表/新建/"})

class 到款明细View(TemplateView):
    template_name = "main/到款明细.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        f = 到款明细Filter(self.request.GET, queryset=到款明细.objects.all())
        context["filter"] = f
        return context

def 到款明细新建View(request):
    if request.method == 'POST':
        form = 到款明细Form(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/到款明细/'+form.cleaned_data.get("凭证号"))
    else:
        form = 到款明细Form()

    return render(request, 'main/新建.html', {'form': form, "post_url": "/到款明细/新建/"})

class 到款明细详情View(TemplateView):
    template_name = "main/详情.html"

    def get_context_data(self, *args, **kwargs):
        context = super().get_context_data(*args, **kwargs)
        context["详情"] = get_object_or_404(到款明细, pk=kwargs["id"])
        return context


class 开票明细View(TemplateView):
    template_name = "main/开票明细.html"
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        f = 开票明细Filter(self.request.GET, queryset=开票明细.objects.all())
        context["filter"] = f
        return context

def 开票明细新建View(request):
    if request.method == 'POST':
        form = 开票明细Form(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/开票明细/'+form.cleaned_data.get("发票号码"))
    else:
        form = 开票明细Form()

    return render(request, 'main/新建.html', {'form': form, "post_url": "/开票明细/新建/"})

class 开票明细详情View(TemplateView):
    template_name = "main/详情.html"

    def get_context_data(self, *args, **kwargs):
        context = super().get_context_data(*args, **kwargs)
        context["详情"] = get_object_or_404(开票明细, pk=kwargs["id"])
        return context


class 发货明细View(TemplateView):
    template_name = "main/发货明细.html"
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        f = 发货明细Filter(self.request.GET, queryset=发货明细.objects.all())
        context["filter"] = f
        return context

def 发货明细新建View(request):
    if request.method == 'POST':
        form = 发货明细Form(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/发货明细/'+form.cleaned_data.get("送货单号码"))
    else:
        form = 发货明细Form()

    return render(request, 'main/新建.html', {'form': form, "post_url": "/发货明细/新建/"})

class 发货明细详情View(TemplateView):
    template_name = "main/详情.html"

    def get_context_data(self, *args, **kwargs):
        context = super().get_context_data(*args, **kwargs)
        context["详情"] = get_object_or_404(发货明细, pk=kwargs["id"])
        return context
