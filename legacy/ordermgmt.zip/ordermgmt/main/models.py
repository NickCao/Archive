from django.db import models

# Create your models here.

class 项目(models.Model):
    项目编号 = models.CharField(max_length=100, primary_key=True)
    项目名称 = models.CharField(max_length=200)
    用户单位 = models.CharField(max_length=200)
    订单号 = models.CharField(max_length=100)
    合同号 = models.CharField(max_length=100)
    合同签订日期 = models.DateField()
    交货日期 = models.DateField()
    合同金额含税 = models.FloatField()
    合同金额不含税 = models.FloatField()
    开票金额 = models.FloatField()
    收款金额 = models.FloatField()
    对方公司采购 = models.CharField(max_length=20)
    项目开工日期 = models.DateField()
    客户联络人 = models.CharField(max_length=20)
    终验收日期 = models.DateField()
    送货地点 = models.CharField(max_length=200)
    送货单开具日期 = models.DateField()
    付款方式 = models.CharField(max_length=200)
    备注 = models.CharField(max_length=2000)
    def get_fields(self):
        return [(field.name, field.value_to_string(self)) for field in 项目._meta.fields]

class 到款明细(models.Model):
    工作令 = models.ForeignKey(项目, on_delete=models.CASCADE)
    到款日期 = models.DateField()
    凭证号 = models.CharField(primary_key=True,max_length=100)
    客户公司名称 = models.CharField(max_length=200)
    收入金额 = models.FloatField()
    收款比例 = models.FloatField()
    备注 = models.CharField(max_length=2000)
    def get_fields(self):
        return [(field.name, field.value_to_string(self)) for field in 到款明细._meta.fields]

class 开票明细(models.Model):
    工作令 = models.ForeignKey(项目, on_delete=models.CASCADE)
    开票日期 = models.DateField()
    发票号码 = models.CharField(max_length=100,primary_key=True)
    公司名称 = models.CharField(max_length=200)
    合同号 = models.CharField(max_length=100)
    收货单号 = models.CharField(max_length=100)
    开票内容 = models.CharField(max_length=300)
    不含税金额 = models.FloatField()
    销项税额 = models.FloatField()
    含税金额 = models.FloatField()
    快递单号 = models.CharField(max_length=100)
    开票次数 = models.IntegerField()
    开票百分比 = models.FloatField()
    申请人 = models.CharField(max_length=100)
    采购 = models.CharField(max_length=100)
    def get_fields(self):
        return [(field.name, field.value_to_string(self)) for field in 开票明细._meta.fields]

class 发货明细(models.Model):
    工作令 = models.ForeignKey(项目, on_delete=models.CASCADE)
    开单日期 = models.DateField()
    送货单号码 = models.CharField(max_length=100,primary_key=True)
    客户名称 = models.CharField(max_length=200)
    产品名称 = models.CharField(max_length=200)
    送货日期 = models.DateField()
    送货人 = models.CharField(max_length=100)
    客户签收日期 = models.DateField()
    凭证后送货日期 = models.DateField()
    申请人 = models.CharField(max_length=100)
    def get_fields(self):
        return [(field.name, field.value_to_string(self)) for field in 发货明细._meta.fields]
    