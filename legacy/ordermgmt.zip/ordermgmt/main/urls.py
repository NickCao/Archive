from django.urls import path

from . import views

urlpatterns = [
    path('', views.目录View.as_view(), name='目录'),
    path('项目实施表/', views.项目实施表View.as_view(), name='项目实施表'),
    path('项目实施表/新建/', views.项目实施表新建View, name='项目实施表新建'),
    path('项目实施表/<str:id>', views.项目实施表详情View.as_view(), name='项目实施表详情'),
    path('到款明细/', views.到款明细View.as_view(), name='到款明细'),
    path('到款明细/新建/', views.到款明细新建View, name='到款明细新建'),
    path('到款明细/<str:id>', views.到款明细详情View.as_view(), name='到款明细详情'),
    path('开票明细/', views.开票明细View.as_view(), name='开票明细'),
    path('开票明细/新建/', views.开票明细新建View, name='开票明细新建'),
    path('开票明细/<str:id>', views.开票明细详情View.as_view(), name='开票明细详情'),
    path('发货明细/', views.发货明细View.as_view(), name='发货明细'),
    path('发货明细/新建/', views.发货明细新建View, name='发货明细新建'),
    path('发货明细/<str:id>', views.发货明细详情View.as_view(), name='发货明细详情'),
]