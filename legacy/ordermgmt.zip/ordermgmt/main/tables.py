import django_tables2 as tables

from .models import *

class 项目Table(tables.Table):
    class Meta:
        attrs = {"class": "table table-bordered table-responsive"}
        model = 项目

class 最新项目Table(tables.Table):
    class Meta:
        attrs = {"class": "table table-bordered table-responsive"}
        model = 项目
        fields = ("项目编号", "项目名称", "用户单位")

class 最新到款Table(tables.Table):
    class Meta:
        attrs = {"class": "table table-bordered table-responsive"}
        model = 到款明细
        fields = ("工作令", "到款日期", "客户公司名称")

class 最新开票Table(tables.Table):
    class Meta:
        attrs = {"class": "table table-bordered table-responsive"}
        model = 开票明细
        fields = ("工作令", "开票日期", "公司名称")

class 最新发货Table(tables.Table):
    class Meta:
        attrs = {"class": "table table-bordered table-responsive"}
        model = 发货明细
        fields = ("工作令", "产品名称", "客户名称")
        