from django import forms
from .models import *

class 项目Form(forms.ModelForm):
    class Meta:
        model = 项目
        exclude = []

class 到款明细Form(forms.ModelForm):
    class Meta:
        model = 到款明细
        exclude = []

class 开票明细Form(forms.ModelForm):
    class Meta:
        model = 开票明细
        exclude = []

class 发货明细Form(forms.ModelForm):
    class Meta:
        model = 发货明细
        exclude = []

