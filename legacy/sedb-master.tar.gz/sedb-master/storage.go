package sedb

import (
	"encoding/gob"
	"log"
	"os"
)

func (db *SEDB) loadData() {
	f, err := os.OpenFile(db.path, os.O_RDONLY|os.O_CREATE, 0644)
	if err != nil {
		log.Fatal(err)
	}
	defer f.Close()
	dec := gob.NewDecoder(f)
    d := make(map[string]interface{})
    db.data = &d
	dec.Decode(db.data)
}

func (db *SEDB) dumpData() {
	f, err := os.OpenFile(db.path, os.O_RDWR|os.O_CREATE|os.O_TRUNC, 0644)
	if err != nil {
		log.Fatal(err)
	}
	defer f.Close()
	enc := gob.NewEncoder(f)
	enc.Encode(db.data)
}
