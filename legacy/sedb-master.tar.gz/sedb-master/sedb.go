package sedb

type SEDB struct {
	data           *map[string]interface{}
	path           string
	setc           chan tup
	getc           chan tup
}

func NewSEDB(path string) *SEDB {
	db := new(SEDB)
	db.path = path
	db.setc = make(chan tup, 2)
	db.getc = make(chan tup, 2)
	db.loadData()
	go db.daemonStart()
	return db
}

func (db *SEDB) Get(key string) interface{} {
	res := make(chan interface{})
	db.getc <- tup{key, res}
	return <-res
}

func (db *SEDB) Set(key string, value interface{}) {
	db.setc <- tup{key, value}
}

func (db *SEDB) Flush(){
	db.dumpData()
}
