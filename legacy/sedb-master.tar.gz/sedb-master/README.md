# sedb (A Simple Embedded Database for golang (thread-safe featured))
(started as a weekend project and not intented for production use)

Example Usage:
```golang
package main

import (
    "fmt"
    "github.com/NickCao/sedb"
)

func main(){
    //Initialize the database
    db = sedb.NewSEDB("./test.db")
    //Set k-v pair
    //Note: the value can be anything (interface{})
    //      while the key is limited to string
    db.Set("a",123)
    //Get and Set are both thread-safe thus using the same db in multiple 
    //goroutines is possible and reliable
    fmt.Println(db.Get("a"))
    //All transactions are stored in memory
    //and they will NEVER be written to disk unless using db.Flush()
    db.Flush()
}
```
