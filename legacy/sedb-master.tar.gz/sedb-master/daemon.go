package sedb

type tup struct {
	k string
	v interface{}
}

func (db *SEDB) daemonStart() {
	d := *db.data
	for true {
		select {
		case t := <-db.setc:
			d[t.k] = t.v
		case t := <-db.getc:
			t.v.(chan interface{}) <- d[t.k]
		}
	}
}
