## docker-privatebin

### privatebin, in docker, with less moving parts

This image is intended to be used with the --read-only flag, with tmpfs mounted on /tmp, and an additional data volume on /srv/data.