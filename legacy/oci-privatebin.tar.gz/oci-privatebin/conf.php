;<?php http_response_code(403); /*
[main]
name = "PrivateBin"
discussion = false
opendiscussion = false
password = false
fileupload = false
burnafterreadingselected = false
defaultformatter = "plaintext"
; syntaxhighlightingtheme = "sons-of-obsidian"
sizelimit = 1048576
template = "bootstrap"
notice = "Zero logging"
languageselection = false
; languagedefault = "en"
qrcode = true
icon = "none"
cspheader = "default-src 'none'; manifest-src 'self'; connect-src * blob:; script-src 'self' 'unsafe-eval'; style-src 'self'; font-src 'self'; img-src 'self' data: blob:; media-src blob:; object-src blob:; sandbox allow-same-origin allow-scripts allow-forms allow-modals"
zerobincompatibility = false
httpwarning = true
compression = "zlib"

[expire]
default = "never"

[expire_options]
never = 0

[formatter_options]
plaintext = "Plain Text"
syntaxhighlighting = "Source Code"
markdown = "Markdown"

[traffic]
limit = 0
dir = PATH "data"

[purge]
limit = 0
batchsize = 0
dir = PATH "data"

[model]
class = Filesystem

[model_options]
dir = PATH "data"
