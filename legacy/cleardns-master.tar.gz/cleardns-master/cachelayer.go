package main

import (
	"github.com/miekg/dns"
	"time"
	"log"
)

type CacheLayer struct{
	safedns string
	realdns string
	timeout time.Duration
}

func (c *CacheLayer) Fetch(msg *dns.Msg, src string) *dns.Msg{
	switch src{
	case "safe":
		ans,_,err := (&dns.Client{Timeout:c.timeout}).Exchange(msg,c.safedns)
		if err != nil{
			log.Print("Fetch safe failed: "+msg.Question[0].Name)
			return CreateSERVFAIL(msg)
		}
		return ans
	case "real":
		ans,_,err := (&dns.Client{Timeout:c.timeout}).Exchange(msg,c.realdns)
		if err != nil{
			log.Print("Fetch real failed: "+msg.Question[0].Name)
			return CreateSERVFAIL(msg)
		}
		return ans
	default:
		log.Print("Fetch type invalid: "+msg.Question[0].Name)
		return CreateSERVFAIL(msg)
	}
}