package main

import (
	"testing"
)

func TestBFLayer(t *testing.T) {
	l, err := NewBFLayer(1000000, 0.00001)
	if err != nil {
		t.Error(err)
	}
	err = l.Mark("123", 1)
	if err != nil {
		t.Error(err)
	}
	err = l.Mark("456", 2)
	if err != nil {
		t.Error(err)
	}
	err = l.Mark("789", 1)
	if err != nil {
		t.Error(err)
	}
	err = l.Mark("789", 2)
	if err != nil {
		t.Error(err)
	}
	t.Log(l.Test("123"))
	t.Log(l.Test("456"))
	t.Log(l.Test("789"))
	t.Log(l.Test("012"))
}
