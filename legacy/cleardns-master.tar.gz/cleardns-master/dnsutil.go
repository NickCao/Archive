package main

import (
	"github.com/miekg/dns"
	"time"
)

func CheckPollution(msg *dns.Msg, fakedns string, timeout time.Duration) (string,bool){
	var err error
	var domain string
	_,_,err = (&dns.Client{Timeout:timeout}).Exchange(msg,fakedns)
	domain = msg.Question[0].Name
	if err != nil{
		return domain,false
	}
	return domain,true
}

func CreateSERVFAIL(msg *dns.Msg) *dns.Msg{
	reply := &dns.Msg{}
	reply.SetRcode(msg,dns.RcodeServerFailure)
	return reply
}