package main

import (
	"flag"
	"github.com/miekg/dns"
	"log"
	"time"
)

var laddrF = flag.String("l","127.0.0.1:53","the local address to listen on")
var fakednsF = flag.String("f","99.84.239.46:53","a fake dns address (it MUST NOT be a real dns)")
var realdnsF = flag.String("r","119.29.29.29:53","the real dns (like the one provided by your isp)")
var safednsF = flag.String("s","127.0.0.1:5300","a unpolluted dns (dnscrypt-proxy is a good choice)")
var faketimeoutF = flag.Int("p",300,"the timeout used to determine whether a domain is polluted") //time.Millisecond
var timeoutF = flag.Int("t",1000,"the timeout used to queue other dns")

func main() {
	flag.Parse()
	faketimeout := time.Duration(*faketimeoutF) * time.Millisecond
	timeout := time.Duration(*timeoutF) * time.Millisecond
	var err error
	if err != nil {
		log.Fatal(err)
	}
	ch ,err := NewCleardnsHandler(*fakednsF,*realdnsF,*safednsF,timeout,faketimeout)
	if err != nil {
		log.Fatal(err)
	}
	err = dns.ListenAndServe(*laddrF, "udp", ch)
	if err != nil {
		log.Fatal(err)
	}
	return
}