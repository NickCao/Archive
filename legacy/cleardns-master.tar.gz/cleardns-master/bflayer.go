package main

import (
	"errors"
	"github.com/steakknife/bloomfilter"
	"hash"
	"hash/fnv"
)

type BFLayer struct {
	whitelist *bloomfilter.Filter
	blacklist *bloomfilter.Filter
}

func SimpleHash(item string) (hash.Hash64, error) {
	var hash hash.Hash64
	var err error
	hash = fnv.New64()
	_, err = hash.Write([]byte(item))
	if err != nil {
		return nil, err
	}
	return hash, nil
}

//0 for unknown
//1 for white
//2 for black

func NewBFLayer(maxN uint64, p float64) (*BFLayer, error) {
	var l *BFLayer
	l = &BFLayer{}
	var err error
	l.whitelist, err = bloomfilter.NewOptimal(maxN, p)
	if err != nil {
		return nil, err
	}
	l.blacklist, err = bloomfilter.NewOptimal(maxN, p)
	if err != nil {
		return nil, err
	}
	return l, nil
}

func (l *BFLayer) Mark(item string, status int) error {
	var hash hash.Hash64
	var err error
	hash, err = SimpleHash(item)
	if err != nil {
		return err
	}
	if status == 1 {
		l.whitelist.Add(hash)
		return nil
	} else if status == 2 {
		l.blacklist.Add(hash)
		return nil
	} else {
		return errors.New("mark: Invalid status")
	}
}

func (l *BFLayer) Test(item string) (int, error) {
	var hash hash.Hash64
	var err error
	hash, err = SimpleHash(item)
	if err != nil {
		return 0, err
	}
	w := l.whitelist.Contains(hash)
	b := l.blacklist.Contains(hash)
	if b{
		return 2, nil
	}
	if w{
		return 1,nil
	}
	return 0,nil
}
