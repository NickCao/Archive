package main

import (
	"github.com/miekg/dns"
	"log"
	"time"
)

type CleardnsHandler struct {
	bl          *BFLayer
	cl          *CacheLayer
	fakedns     string
	faketimeout time.Duration
}

func NewCleardnsHandler(fakedns string, realdns string, safedns string,
	timeout time.Duration, faketimeout time.Duration) (*CleardnsHandler, error) {
	ch := &CleardnsHandler{}
	ch.fakedns = fakedns
	ch.faketimeout = faketimeout
	ch.cl = &CacheLayer{safedns: safedns, realdns: realdns, timeout: timeout}
	var err error
	ch.bl, err = NewBFLayer(10000, 0.0001)
	if err != nil {
		return nil, err
	}
	return ch, nil
}

func (m *CleardnsHandler) ServeDNS(w dns.ResponseWriter, r *dns.Msg) {
	var domain string
	var err error
	var res int
	domain = r.Question[0].Name
	res, err = m.bl.Test(domain)
	if err != nil {
		log.Print("Test failed: " + r.Question[0].Name)
		w.WriteMsg(CreateSERVFAIL(r))
		return
	}
	switch res {
	case 0:
		domain, p := CheckPollution(r, m.fakedns, m.faketimeout)
		if p {
			log.Print("Mark polluted: " + domain)
			m.bl.Mark(domain, 2)
		} else {
			log.Print("Mark safe: " + domain)
			m.bl.Mark(domain, 1)
		}
		m.ServeDNS(w,r)
	case 1:
		w.WriteMsg(m.cl.Fetch(r, "real"))
		domain, p := CheckPollution(r, m.fakedns, m.faketimeout)
		if p {
			log.Print("Mark polluted: " + domain)
			m.bl.Mark(domain, 2)
		}
	case 2:
		w.WriteMsg(m.cl.Fetch(r, "safe"))
	}
}
