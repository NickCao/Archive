#!/bin/bash
cd /opt
if [ "$PORT" = "" ]
then
export PORT=80
fi
sed "s/thefuckingport/$PORT/g" < nginx.conf.temp > /etc/nginx/nginx.conf
nginx &
./backend/redis-server &
gunicorn -w 3 --bind 0.0.0.0:1963 backend.api:app &
python3 ./backend/processor.py 2 &
wait
