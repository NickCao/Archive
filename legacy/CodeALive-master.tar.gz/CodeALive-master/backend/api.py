import sys, os, redis
from flask import Flask
from flask_restful import reqparse, abort, Api, Resource

def en(s):
    return str.encode(s)

def de(b):
    return bytes.decode(b)

def nabort(commit_id):
    r = redis.StrictRedis(host='localhost', port=6379, db=0)
    if int(commit_id) > int(r.get("present_commit_id")):
        abort(404, message="commit "+str(commit_id)+" doesn't exist")


class Commit(Resource):
    def get(self, commit_id):
        nabort(commit_id)
        r = redis.StrictRedis(host='localhost', port=6379, db=0)
        return {"id":int(commit_id),"code":de(r.hget("code",commit_id)),"res":de(r.hget("res",commit_id))}

class CommitList(Resource):
    def get(self):
        ret = []
        r = redis.StrictRedis(host='localhost', port=6379, db=0)
        for commit_id in range(1,int(de(r.get("present_commit_id")))+1):
            ret.append({"id":int(commit_id),"code":de(r.hget("code", commit_id)),"res":de(r.hget("res",commit_id))})
        return ret
    def post(self):
        args = parser.parse_args()
        r = redis.StrictRedis(host='localhost', port=6379, db=0)
        commit_id = r.incr("present_commit_id")
        r.hset("code", commit_id, args['code'])
        r.rpush("queue", commit_id)
        return {"id":commit_id, "code":args['code']}, 201

app = Flask(__name__)
api = Api(app)
api.add_resource(CommitList, '/api/v1/commits')
api.add_resource(Commit, '/api/v1/<commit_id>')
parser = reqparse.RequestParser()
parser.add_argument('code')

if __name__ == '__main__':
    app.run(debug=True)
