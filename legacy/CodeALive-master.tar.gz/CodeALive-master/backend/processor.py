import redis, os, subprocess
def process():
    r = redis.StrictRedis(host='localhost', port=6379, db=0)
    k = 0
    while not k:
        k = r.blpop("queue",100)
    commit_id = bytes.decode(k[1])
    code = bytes.decode(r.hget("code",commit_id))
    try:
        res = bytes.decode(subprocess.check_output(["python3", "-c", str(code)]))
    except:
        res = "Error"
    r.hset("res",commit_id,res)
    return {"id":int(commit_id),"code":bytes.decode(r.hget("code",commit_id)),"res":bytes.decode(r.hget("res",commit_id))}

if __name__ == '__main__':
#    import threading, sys
#    threads = 1
#    if len(sys.argv) >= 2:
#        try:
#            threads = int(sys.argv[1])
#        except Exception:
#            pass
#    for i in range(0,threads):
#        threading.Thread(target = process, daemon=True).start()
    while True:
        process()
