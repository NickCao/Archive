package wave

import (
	"crypto/tls"
	"io"
	"log"
	"net"
)

//RemoteInstance ...
type RemoteInstance struct {
	ConfPath      string
	RemoteConf    *RemoteConfig
	RemoteTLSConf *tls.Config
	TUN           *Tun
}

//NewRemoteInstance ...
func NewRemoteInstance(path string) (*RemoteInstance, error) {
	inst := &RemoteInstance{}
	inst.ConfPath = path
	var err error
	inst.RemoteConf, err = LoadRemoteConfig(inst.ConfPath)
	if err != nil {
		return nil, err
	}
	tun := NewTun("remote", "", "")
	err = tun.Enable()
	if err != nil {
		return nil, err
	}
	inst.TUN = tun
	inst.RemoteTLSConf, err = GetRemoteTLSConfig(inst.RemoteConf)
	if err != nil {
		return nil, err
	}
	return inst, nil
}

//Destroy ...
func (inst *RemoteInstance) Destroy() {
	inst.TUN.Disable()
}

//Run ...
func (inst *RemoteInstance) Run() {
	ln, err := tls.Listen("tcp", inst.RemoteConf.ListenAddr, inst.RemoteTLSConf)
	if err != nil {
		log.Fatal(err)
	}
	for {
		conn, err := ln.Accept()
		if err != nil {
			log.Print(err)
			continue
		}
		go inst.handleConn(conn)
	}
}

func (inst *RemoteInstance) handleConn(conn net.Conn) {
	itf, err := inst.TUN.GetInterface()
	if err != nil {
		log.Print(err)
		return
	}
	go io.Copy(itf, conn)
	go io.Copy(conn, itf)
}
