package wave

import (
	"io/ioutil"

	yaml "gopkg.in/yaml.v2"
)

//LocalConfig ...
type LocalConfig struct {
	RemoteAddr string
	DefaultGW  string
	Threads    int
	LocalCert  string
	LocalKey   string
	RemoteCert string
}

//RemoteConfig ...
type RemoteConfig struct {
	ListenAddr string
	RemoteCert string
	RemoteKey  string
	LocalCert  string
}

//LoadLocalConfig ...
func LoadLocalConfig(path string) (*LocalConfig, error) {
	confFile, err := ioutil.ReadFile(path)
	if err != nil {
		return nil, err
	}
	config := LocalConfig{}
	err = yaml.UnmarshalStrict(confFile, &config)
	if err != nil {
		return nil, err
	}
	return &config, nil
}

//LoadRemoteConfig ...
func LoadRemoteConfig(path string) (*RemoteConfig, error) {
	confFile, err := ioutil.ReadFile(path)
	if err != nil {
		return nil, err
	}
	config := RemoteConfig{}
	err = yaml.UnmarshalStrict(confFile, &config)
	if err != nil {
		return nil, err
	}
	return &config, nil
}
