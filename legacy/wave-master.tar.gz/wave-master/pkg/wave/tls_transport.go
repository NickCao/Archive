package wave

import (
	"crypto/tls"
	"crypto/x509"
	"errors"
)

//GetLocalTLSConfig ...
func GetLocalTLSConfig(conf *LocalConfig) (*tls.Config, error) {
	localKeyPair, err := tls.X509KeyPair([]byte(conf.LocalCert), []byte(conf.LocalKey))
	if err != nil {
		return nil, err
	}
	certPool := x509.NewCertPool()
	ok := certPool.AppendCertsFromPEM([]byte(conf.RemoteCert))
	if ok != true {
		return nil, errors.New("Error in prasing the remotecert")
	}
	tlsConfig := &tls.Config{
		Certificates:       []tls.Certificate{localKeyPair},
		RootCAs:            certPool,
		InsecureSkipVerify: true,
		//MinVersion:   tls.VersionTLS13,
		//MaxVersion:   tls.VersionTLS13,
	}
	return tlsConfig, nil
}

//GetRemoteTLSConfig ...
func GetRemoteTLSConfig(conf *RemoteConfig) (*tls.Config, error) {
	remoteKeyPair, err := tls.X509KeyPair([]byte(conf.RemoteCert), []byte(conf.RemoteKey))
	if err != nil {
		return nil, err
	}
	certPool := x509.NewCertPool()
	ok := certPool.AppendCertsFromPEM([]byte(conf.LocalCert))
	if ok != true {
		return nil, errors.New("Error in prasing the localcert")
	}
	tlsConfig := &tls.Config{
		Certificates: []tls.Certificate{remoteKeyPair},
		ClientAuth:   tls.RequireAndVerifyClientCert,
		ClientCAs:    certPool,
		//MinVersion:      tls.VersionTLS13,
		//MaxVersion:      tls.VersionTLS13,
		//Max0RTTDataSize: 16384,
		//Accept0RTTData:  true,
	}
	return tlsConfig, nil
}
