package wave

import (
	"errors"
	"os/exec"

	"github.com/songgao/water"
)

//Tun ...
type Tun struct {
	endpoint  string
	defaultgw string
	remoteip  string
	config    water.Config
}

//NewTun ...
func NewTun(endpoint, defaultgw, remoteip string) *Tun {
	config := water.Config{
		DeviceType: water.TUN,
		PlatformSpecificParams: water.PlatformSpecificParams{
			Name:       "wave",
			MultiQueue: true,
		},
	}
	return &Tun{endpoint, defaultgw, remoteip, config}
}

//Enable ...
func (t *Tun) Enable() error {
	_, err := water.New(t.config)
	if err != nil {
		return err
	}
	switch t.endpoint {
	case "local":
		var cmds []*exec.Cmd
		cmds = append(cmds, exec.Command("ip", "addr", "add", "dev", "wave", "192.168.10.2/24"))
		cmds = append(cmds, exec.Command("ip", "addr", "add", "dev", "wave", "fde9:85f8:a73c:35e5:1234:5678:9101:2/64"))
		cmds = append(cmds, exec.Command("ip", "link", "set", "wave", "up"))
		cmds = append(cmds, exec.Command("ip", "route", "add", "0.0.0.0/0", "via", "192.168.10.1"))
		cmds = append(cmds, exec.Command("ip", "route", "add", "::/0", "via", "fde9:85f8:a73c:35e5:1234:5678:9101:1"))
		cmds = append(cmds, exec.Command("ip", "route", "add", t.remoteip, "via", t.defaultgw))
		for _, cmd := range cmds {
			output, err := cmd.CombinedOutput()
			if err != nil {
				return errors.New(string(output))
			}
		}
		return nil
	case "remote":
		var cmds []*exec.Cmd
		cmds = append(cmds, exec.Command("ip", "addr", "add", "dev", "wave", "192.168.10.1/24"))
		cmds = append(cmds, exec.Command("ip", "addr", "add", "dev", "wave", "fde9:85f8:a73c:35e5:1234:5678:9101:1/64"))
		cmds = append(cmds, exec.Command("ip", "link", "set", "wave", "up"))
		cmds = append(cmds, exec.Command("iptables", "-A", "FORWARD", "-i", "wave", "-j", "ACCEPT"))
		cmds = append(cmds, exec.Command("iptables", "-A", "FORWARD", "-o", "wave", "-j", "ACCEPT"))
		cmds = append(cmds, exec.Command("iptables", "-t", "nat", "-A", "POSTROUTING", "-j", "MASQUERADE"))
		cmds = append(cmds, exec.Command("ip6tables", "-A", "FORWARD", "-i", "wave", "-j", "ACCEPT"))
		cmds = append(cmds, exec.Command("ip6tables", "-A", "FORWARD", "-o", "wave", "-j", "ACCEPT"))
		cmds = append(cmds, exec.Command("ip6tables", "-t", "nat", "-A", "POSTROUTING", "-j", "MASQUERADE"))
		for _, cmd := range cmds {
			output, err := cmd.CombinedOutput()
			if err != nil {
				return errors.New(string(output))
			}
		}
	}
	return nil
}

//Disable ...
func (t *Tun) Disable() error {
	switch t.endpoint {
	case "local":
		var cmds []*exec.Cmd
		cmds = append(cmds, exec.Command("ip", "route", "del", t.remoteip))
		cmds = append(cmds, exec.Command("ip", "link", "del", "wave"))
		for _, cmd := range cmds {
			output, err := cmd.CombinedOutput()
			if err != nil {
				return errors.New(string(output))
			}
		}
	case "remote":
		cmd := exec.Command("ip", "link", "del", "wave")
		output, err := cmd.CombinedOutput()
		if err != nil {
			return errors.New(string(output))
		}
	}
	return nil
}

//GetInterface ...
func (t *Tun) GetInterface() (*water.Interface, error) {
	itf, err := water.New(t.config)
	if err != nil {
		return nil, err
	}
	return itf, nil
}
