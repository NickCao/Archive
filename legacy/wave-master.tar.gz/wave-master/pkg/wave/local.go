package wave

import (
	"crypto/tls"
	"io"
	"log"
	"strings"

	"github.com/songgao/water"
)

//LocalInstance ...
type LocalInstance struct {
	ConfPath     string
	LocalConf    *LocalConfig
	LocalTLSConf *tls.Config
	TUN          *Tun
}

//NewLocalInstance ...
func NewLocalInstance(path string) (*LocalInstance, error) {
	inst := &LocalInstance{}
	inst.ConfPath = path
	var err error
	inst.LocalConf, err = LoadLocalConfig(inst.ConfPath)
	if err != nil {
		return nil, err
	}
	remoteip := strings.Split(inst.LocalConf.RemoteAddr, ":")[0]
	tun := NewTun("local", inst.LocalConf.DefaultGW, remoteip)
	err = tun.Enable()
	if err != nil {
		return nil, err
	}
	inst.TUN = tun
	inst.LocalTLSConf, err = GetLocalTLSConfig(inst.LocalConf)
	if err != nil {
		return nil, err
	}
	return inst, nil
}

//Destroy ...
func (inst *LocalInstance) Destroy() {
	inst.TUN.Disable()
}

//Run ...
func (inst *LocalInstance) Run() {
	for i := 0; i < inst.LocalConf.Threads; i++ {
		itf, err := inst.TUN.GetInterface()
		if err != nil {
			log.Print(err)
			return
		}
		go inst.StartThread(itf)
	}
}

//StartThread ...
func (inst *LocalInstance) StartThread(itf *water.Interface) {
	conn, err := tls.Dial("tcp", inst.LocalConf.RemoteAddr, inst.LocalTLSConf)
	if err != nil {
		log.Print(err)
		go inst.StartThread(itf)
		return
	}
	done := make(chan struct{}, 2)
	go func(itf *water.Interface, done chan struct{}) {
		io.Copy(conn, itf)
		done <- struct{}{}
	}(itf, done)
	go func(itf *water.Interface, done chan struct{}) {
		io.Copy(itf, conn)
		done <- struct{}{}
	}(itf, done)
	<-done
	<-done
	go inst.StartThread(itf)
}
