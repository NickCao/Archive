# wave

Wave - the state-of-art TLS based VPN written in Go

This package has entered mantainance phase
And tcp over tcp is indeed a bad idea....
Good boys should never even think about it...