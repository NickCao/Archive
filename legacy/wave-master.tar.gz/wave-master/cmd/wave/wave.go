package main

import (
	"flag"
	"log"

	"gitlab.com/nickcao/wave/pkg/wave"
)

var confpath = flag.String("c", "", "the path to the config file")
var mode = flag.String("m", "local", "local or remote, censored or not")

func main() {
	flag.Parse()
	if len(*confpath) == 0 {
		log.Fatal("please specify the config file")
	}
	switch *mode {
	case "local":
		instance, err := wave.NewLocalInstance(*confpath)
		if err != nil {
			log.Fatal(err)
		}
		defer instance.Destroy()
		instance.Run()
		for {
		}
	case "remote":
		instance, err := wave.NewRemoteInstance(*confpath)
		if err != nil {
			log.Fatal(err)
		}
		defer instance.Destroy()
		instance.Run()
	default:
		log.Fatal("Unrecognized mode")
	}

}
