package protocolz

import (
	"crypto/tls"
	"crypto/x509"
	"errors"
	"io/ioutil"
	"path"
	"strings"
)

func loadCerts(endpoint, dir string) (*tls.Certificate, *x509.CertPool, error) {
	var rendpoint string
	switch endpoint {
	case "client":
		rendpoint = "server"
	case "server":
		rendpoint = "client"
	default:
		return nil, nil, errors.New("Unrecognized endpoint type")
	}
	certFiles, err := ioutil.ReadDir(dir)
	if err != nil {
		return nil, nil, err
	}
	certPool := x509.NewCertPool()
	for _, file := range certFiles {
		name := file.Name()
		if strings.HasPrefix(name, rendpoint+"CA") {
			caCert, err := ioutil.ReadFile(path.Join(dir, name))
			if err != nil {
				return nil, nil, err
			}
			ok := certPool.AppendCertsFromPEM(caCert)
			if !ok {
				return nil, nil, errors.New("Failed to load cert: " + name)
			}
		}
	}
	endpointCert, err := tls.LoadX509KeyPair(path.Join(dir, endpoint+"cert.pem"), path.Join(dir, endpoint+"key.pem"))
	if err != nil {
		return nil, nil, err
	}
	return &endpointCert, certPool, nil
}

//GetTLSConfig endpoint is "client" or "server", dir is dir...
func GetTLSConfig(endpoint, dir string) (*tls.Config, error) {
	endpointCert, certPool, err := loadCerts(endpoint, dir)
	if err != nil {
		return nil, err
	}
	switch endpoint {
	case "client":
		tlsConfig := &tls.Config{
			Certificates: []tls.Certificate{*endpointCert},
			RootCAs:      certPool,
			MinVersion:   tls.VersionTLS13,
			MaxVersion:   tls.VersionTLS13,
		}
		return tlsConfig, nil
	case "server":
		tlsConfig := &tls.Config{
			Certificates:    []tls.Certificate{*endpointCert},
			ClientAuth:      tls.RequireAndVerifyClientCert,
			ClientCAs:       certPool,
			MinVersion:      tls.VersionTLS13,
			MaxVersion:      tls.VersionTLS13,
			Max0RTTDataSize: 16384,
			Accept0RTTData:  true,
		}
		return tlsConfig, nil
	default:
		return nil, errors.New("Unrecognized endpoint type")
	}
}
