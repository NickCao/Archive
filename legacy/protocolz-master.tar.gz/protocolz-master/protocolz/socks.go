package protocolz

import (
	"context"
	"net"

	socks5 "github.com/armon/go-socks5"
)

type lazyResolver struct{}

func (l lazyResolver) Resolve(ctx context.Context, name string) (context.Context, net.IP, error) {
	return ctx, nil, nil
}

type dialFunc func(ctx context.Context, network, addr string) (net.Conn, error)

// NewSocksServer : well...
func NewSocksServer(dialfunc dialFunc) (*socks5.Server, error) {
	socksConfig := &socks5.Config{Dial: dialfunc, Resolver: lazyResolver{}}
	return socks5.New(socksConfig)
}
