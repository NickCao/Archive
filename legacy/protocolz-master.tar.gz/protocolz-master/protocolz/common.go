package protocolz

//Params :used to transer command to server (encoded with gob)
type Params struct {
	Command string
	Network string
	Addr    string
}
