package protocolz

import (
	"errors"
	"io"
)

func pipe(src, dst io.ReadWriter, errs chan error) {
	_, err := io.Copy(dst, src)
	if err != nil {
		errs <- err
	}
	errs <- nil
	return
}

//BlockingForward :bidirectionally foward byte stream between c1 and c2
func BlockingForward(c1, c2 io.ReadWriter) error {
	errs := make(chan error, 2)
	go pipe(c1, c2, errs)
	go pipe(c2, c1, errs)
	e1 := <-errs
	e2 := <-errs
	if e1 != nil || e2 != nil {
		return errors.New("Error in forwarding")
	}
	return nil
}
