package protocolz

import (
	"crypto/tls"
	"log"
	"net"
)

//ConnPool :to pre-establish connections
type ConnPool struct {
	Size      int
	Pool      chan net.Conn
	Addr      string
	TLSConfig *tls.Config
	Stopch    chan struct{}
	ErrCount  int
}

//NewConnPool :get a new connpool
func NewConnPool(size int, addr string, conf *tls.Config) *ConnPool {
	return &ConnPool{size, make(chan net.Conn, size), addr, conf, make(chan struct{}), 0}
}

//Start :start filling the pool
func (p *ConnPool) Start() {
	go processPool(p)
}

//Stop :s graceful shutdown
func (p *ConnPool) Stop() {
	go func() {
		p.Stopch <- struct{}{}
	}()
}

//Get : get a fresh net.Conn
func (p *ConnPool) Get() (net.Conn, error) {
	select {
	case conn := <-p.Pool:
		return conn, nil
	default:
		conn, err := tls.Dial("tcp", p.Addr, p.TLSConfig)
		if err != nil {
			return nil, err
		}
		return conn, nil
	}
}

func processPool(p *ConnPool) {
Loop:
	for {
		select {
		case <-p.Stopch:
			close(p.Pool)
			for conn := range p.Pool {
				conn.Close()
			}
			return
		default:
			conn, err := tls.Dial("tcp", p.Addr, p.TLSConfig)
			if err != nil {
				log.Print(err)
				p.ErrCount = p.ErrCount + 1
				if p.ErrCount > 3 {
					log.Fatal(err)
				}
				continue Loop
			}
			p.ErrCount = 0
			p.Pool <- conn
		}
	}
}
