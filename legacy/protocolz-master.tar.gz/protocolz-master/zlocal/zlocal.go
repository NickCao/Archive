package main

import (
	"context"
	"encoding/gob"
	"flag"
	"log"
	"net"
	"os"
	"path"

	pz "gitlab.com/nickcao/protocolz/protocolz"
)

var (
	saddr    = flag.String("s", "localhost:8080", "the server to connect")
	laddr    = flag.String("l", "0.0.0.0:1080", "the addr for socks5 server")
	certDir  = flag.String("c", "", "path to certs")
	connPool *pz.ConnPool
)

func main() {
	flag.Parse()
	var err error
	if len(*certDir) == 0 {
		exepath, err := os.Executable()
		if err != nil {
			log.Fatal(err)
		}
		*certDir = path.Join(path.Dir(exepath), "certs")
	}
	tlsConfig, err := pz.GetTLSConfig("client", *certDir)
	if err != nil {
		log.Fatal(err)
	}
	socksServer, err := pz.NewSocksServer(RemoteDial)
	if err != nil {
		log.Fatal(err)
	}
	connPool = pz.NewConnPool(8, *saddr, tlsConfig)
	connPool.Start()
	defer connPool.Stop()
	err = socksServer.ListenAndServe("tcp", *laddr)
	if err != nil {
		log.Fatal(err)
	}
}

func RemoteDial(ctx context.Context, network, addr string) (net.Conn, error) {
	param := pz.Params{
		Command: "c",
		Network: network,
		Addr:    addr,
	}
	conn, err := connPool.Get()
	if err != nil {
		log.Print(err)
		return nil, err
	}
	encoder := gob.NewEncoder(conn)
	err = encoder.Encode(param)
	if err != nil {
		conn.Close()
		return nil, err
	}
	return conn, nil
}
