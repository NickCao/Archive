Protocolz -- a TLS secured network tunnel with socks5 capability

This package has entered mantainance phase in favor of v2ray as a alternative