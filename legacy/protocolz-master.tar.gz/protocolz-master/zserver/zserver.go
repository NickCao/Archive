package main

import (
	"crypto/tls"
	"encoding/gob"
	"flag"
	"log"
	"net"
	"os"
	"path"

	pz "gitlab.com/nickcao/protocolz/protocolz"
)

var (
	certDir = flag.String("c", "", "path to certs")
	laddr   = flag.String("l", "0.0.0.0:8080", "the addr to listen on")
)

func main() {
	flag.Parse()
	if len(*certDir) == 0 {
		exepath, err := os.Executable()
		if err != nil {
			log.Fatal(err)
		}
		*certDir = path.Join(path.Dir(exepath), "certs")
	}
	tlsConfig, err := pz.GetTLSConfig("server", *certDir)
	if err != nil {
		log.Fatal(err)
	}
	ln, err := tls.Listen("tcp", *laddr, tlsConfig)
	if err != nil {
		log.Fatal(err)
	}
	defer ln.Close()
	for {
		conn, err := ln.Accept()
		if err != nil {
			log.Print(err)
			continue
		}
		go handleConn(conn)
	}
}

func handleConn(conn net.Conn) {
	defer conn.Close()
	decoder := gob.NewDecoder(conn)
	param := &pz.Params{}
	err := decoder.Decode(param)
	if err != nil {
		log.Print(err)
		return
	}
	switch param.Command {
	case "c":
		conn2, err := net.Dial(param.Network, param.Addr)
		if err != nil {
			log.Print(err)
			return
		}
		defer conn2.Close()
		err = pz.BlockingForward(conn, conn2)
		if err != nil {
			log.Print(err)
			return
		}
		return
	default:
		log.Print("bad params")
		return
	}
}
