package refuse

//TODO: fill the structs with proper go types
//and write conversion funcs for c types

type FUSE_FileInfo struct {
	Flags       int
	Writepage   uint
	DirectIO    uint
	KeepCache   uint
	Flush       uint
	Nonseekable uint
	Padding     uint
	Fh          uint64
	LockOwner   uint64
	PollEvents  uint64
}

type FUSE_Conninfo struct {
	ProtoMajor          uint
	ProtoMinor          uint
	MaxWrite            uint
	MaxRead             uint
	MaxReadahead        uint
	Capable             uint
	Want                uint
	MaxBackground       uint
	CongestionThreshold uint
	TimeGran            uint
	Reserved            [22]uint
}

type SYS_Stat struct {
}

type FUSE_Config struct {
	SetGid           int
	SetUid           int
	SetMode          int
	EntryTimeout     float64
	NegativeTimeout  float64
	AttrTimeout      float64
	Intr             int
	IntrSignal       int
	Remember         int
	HardRemove       int
	UseIno           int
	ReaddirIno       int
	DirectIO         int
	KernelCache      int
	AutoCache        int
	AcAttrTimeoutSet int
	NullpathOK       int
	ShowHelp         int
}

type FUSE_Filldir func(buf []byte, name string, stat SYS_Stat, offset int, flags int) int
