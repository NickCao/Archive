package main

import (
	"os"

	"gitlab.com/NickCao/refuse"
)

func main() {
	i := &refuse.ImplBase{}
	refuse.SetImpl(i)
	refuse.Serve(os.Args)
}
