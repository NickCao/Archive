package refuse

import (
	"log"
	"syscall"
)

//ImplBase is a noop struct that implements interface Impl, embed it for free lunch.
//But this fuse lib only wraps a subset of libfuse (A.K.A. only the essential part....)
type ImplBase struct {
}

func (_ *ImplBase) Getattr(path string, st *SYS_Stat, fi *FUSE_FileInfo) (int, syscall.Errno) {
	return -1, syscall.ENOSYS
}

func (_ *ImplBase) Mkdir(path string, mode int) (int, syscall.Errno) {
	return -1, syscall.ENOSYS
}

func (_ *ImplBase) Rmdir(path string) (int, syscall.Errno) {
	return -1, syscall.ENOSYS
}

func (_ *ImplBase) Rename(src string, dst string, flags uint) (int, syscall.Errno) {
	return -1, syscall.ENOSYS
}

func (_ *ImplBase) Chmod(path string, mode int, fi *FUSE_FileInfo) (int, syscall.Errno) {
	return -1, syscall.ENOSYS
}

func (_ *ImplBase) Chown(path string, uid int, gid int, fi *FUSE_FileInfo) (int, syscall.Errno) {
	return -1, syscall.ENOSYS
}

func (_ *ImplBase) Read(path string, buf []byte, size uint, offset int, fi *FUSE_FileInfo) (int, syscall.Errno) {
	return -1, syscall.ENOSYS
}

func (_ *ImplBase) Write(path string, buf []byte, size uint, offset int, fi *FUSE_FileInfo) (int, syscall.Errno) {
	return -1, syscall.ENOSYS
}

func (_ *ImplBase) Readdir(path string, buf []byte, fill FUSE_Filldir, offset int, fi *FUSE_FileInfo, flags int) (int, syscall.Errno) {
	return -1, syscall.ENOSYS
}

func (_ *ImplBase) Init(conn *FUSE_Conninfo, cfg *FUSE_Config) {
	log.Print(conn)
	log.Print(cfg)
}

func (_ *ImplBase) Destroy() {

}

func (_ *ImplBase) Access(path string, mode int) (int, syscall.Errno) {
	return -1, syscall.ENOSYS
}

func (_ *ImplBase) Create(path string, mode int, fi *FUSE_FileInfo) (int, syscall.Errno) {
	return -1, syscall.ENOSYS
}
