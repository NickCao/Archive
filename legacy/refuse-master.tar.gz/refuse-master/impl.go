package refuse

import "syscall"

//Impl is the interface type for a implemented filesystem
type Impl interface {
	Getattr(path string, st *SYS_Stat, fi *FUSE_FileInfo) (int, syscall.Errno)
	Mkdir(path string, mode int) (int, syscall.Errno)
	Rmdir(path string) (int, syscall.Errno)
	Rename(src string, dst string, flags uint) (int, syscall.Errno)
	Chmod(path string, mode int, fi *FUSE_FileInfo) (int, syscall.Errno)
	Chown(path string, uid int, gid int, fi *FUSE_FileInfo) (int, syscall.Errno)
	Read(path string, buf []byte, size uint, offset int, fi *FUSE_FileInfo) (int, syscall.Errno)
	Write(path string, buf []byte, size uint, offset int, fi *FUSE_FileInfo) (int, syscall.Errno)
	Readdir(path string, buf []byte, fill FUSE_Filldir, offset int, fi *FUSE_FileInfo, flags int) (int, syscall.Errno)
	Init(conn *FUSE_Conninfo, cfg *FUSE_Config)
	Destroy()
	Access(path string, mode int) (int, syscall.Errno)
	Create(path string, mode int, fi *FUSE_FileInfo) (int, syscall.Errno)
}
