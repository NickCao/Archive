package refuse

//TODO: Update all the shims to match the libfuse api

/*
#cgo pkg-config: fuse3
#define FUSE_USE_VERSION 31
#include <fuse.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

typedef const char * constchar;

extern int Shim_getattr(const char *, struct stat *, struct fuse_file_info *fi);
extern int Shim_mkdir(const char *, mode_t);
extern int Shim_rmdir(const char *);
extern int Shim_rename(const char *, const char *, unsigned int flags);
extern int Shim_chmod(const char *, mode_t, struct fuse_file_info *fi);
extern int Shim_chown(const char *, uid_t, gid_t, struct fuse_file_info *fi);
extern int Shim_read(const char *, char *, size_t, off_t, struct fuse_file_info *);
extern int Shim_write(const char *, const char *, size_t, off_t, struct fuse_file_info *);
extern int Shim_readdir(const char *, void *, fuse_fill_dir_t, off_t, struct fuse_file_info *, enum fuse_readdir_flags);
extern void* Shim_init(struct fuse_conn_info *conn, struct fuse_config *cfg);
extern void Shim_destroy(void *private_data);
extern int Shim_access(const char *, int);
extern int Shim_create(const char *, mode_t, struct fuse_file_info *);


static struct fuse_operations refuse_oper = {
	.init       = Shim_init,
	.destroy	= Shim_destroy,
	.getattr	= Shim_getattr,
	.mkdir		= Shim_mkdir,
	.rmdir		= Shim_rmdir,
	.rename		= Shim_rename,
	.chmod		= Shim_chmod,
	.chown		= Shim_chown,
	.read		= Shim_read,
	.write		= Shim_write,
	.readdir	= Shim_readdir,
	.access		= Shim_access,
	.create		= Shim_create

};

static inline int refuse_entrypoint(int argc, char *argv[]){
	return fuse_main(argc, argv, &refuse_oper, NULL);
};

static inline void setErrno(int err) {
      errno = err;
};
*/
import "C"

import (
	"log"
	"unsafe"
)

var realImpl Impl

func SetImpl(i Impl) {
	realImpl = i
}

func Serve(args []string) {
	argv := make([](*C.char), len(args))
	for i, s := range args {
		cs := C.CString(s)
		defer C.free(unsafe.Pointer(cs))
		argv[i] = cs
	}
	C.refuse_entrypoint(C.int(len(args)), &argv[0])
}

//export Shim_init
func Shim_init(conn *C.struct_fuse_conn_info, cfg *C.struct_fuse_config) unsafe.Pointer {
	connInfo := &FUSE_Conninfo{}
	connInfo.ProtoMajor = uint(conn.proto_major)
	connInfo.ProtoMinor = uint(conn.proto_minor)
	connInfo.MaxWrite = uint(conn.max_write)
	connInfo.MaxRead = uint(conn.max_read)
	connInfo.MaxReadahead = uint(conn.max_readahead)
	connInfo.Capable = uint(conn.capable)
	connInfo.Want = uint(conn.want)
	connInfo.MaxBackground = uint(conn.max_background)
	connInfo.CongestionThreshold = uint(conn.congestion_threshold)
	connInfo.TimeGran = uint(conn.time_gran)
	//connInfo.Reserved = [22]uint(conn.reserved)
	//who knows how?

	config := &FUSE_Config{}
	config.SetUid = int(cfg.set_uid)
	config.SetGid = int(cfg.set_gid)
	config.SetMode = int(cfg.set_mode)
	config.EntryTimeout = float64(cfg.entry_timeout)
	config.NegativeTimeout = float64(cfg.negative_timeout)
	config.AttrTimeout = float64(cfg.attr_timeout)
	config.Intr = int(cfg.intr)
	config.IntrSignal = int(cfg.intr_signal)
	config.Remember = int(cfg.remember)
	config.HardRemove = int(cfg.hard_remove)
	config.UseIno = int(cfg.use_ino)
	config.ReaddirIno = int(cfg.readdir_ino)
	config.DirectIO = int(cfg.direct_io)
	config.KernelCache = int(cfg.kernel_cache)
	config.AutoCache = int(cfg.auto_cache)
	config.AcAttrTimeoutSet = int(cfg.ac_attr_timeout_set)
	config.NullpathOK = int(cfg.nullpath_ok)
	config.ShowHelp = int(cfg.show_help)
	realImpl.Init(connInfo, config)
	//the privatedata is not supported
	return nil
}

//export Shim_destroy
func Shim_destroy(_ unsafe.Pointer) {
	realImpl.Destroy()
}

//export Shim_getattr
func Shim_getattr(path C.constchar, stat *C.struct_stat, fi *C.struct_fuse_file_info) C.int {
	sysStat := &SYS_Stat{}
	fileInfo := &FUSE_FileInfo{}
	ret, errno := realImpl.Getattr(C.GoString(path), sysStat, fileInfo)
	//TODO: fix the SYS_Stat struct
	fi.flags = C.int(fileInfo.Flags)
	fi.writepage = fileInfo.Writepage
	fi.fh = C.ulong(fileInfo.Fh)
	fi.lock_owner = C.ulong(fileInfo.LockOwner)


	C.setErrno(C.int(errno))
	return C.int(ret)
}

//export Shim_mkdir
func Shim_mkdir(path C.constchar, mode C.mode_t) C.int {
	C.setErrno(C.ENOSYS)
	return -1
}

//export Shim_rmdir
func Shim_rmdir(path C.constchar) C.int {
	C.setErrno(C.ENOSYS)
	return -1
}

//export Shim_rename
func Shim_rename(src C.constchar, dst C.constchar, flags C.uint) C.int {
	C.setErrno(C.ENOSYS)
	return -1
}

//export Shim_chmod
func Shim_chmod(path C.constchar, mode C.mode_t, fi *C.struct_fuse_file_info) C.int {
	C.setErrno(C.ENOSYS)
	return -1
}

//export Shim_chown
func Shim_chown(path C.constchar, uid C.uid_t, gid C.gid_t, fi *C.struct_fuse_file_info) C.int {
	C.setErrno(C.ENOSYS)
	return -1
}

//export Shim_read
func Shim_read(path C.constchar, buf *C.char, size C.size_t, offset C.off_t, fi *C.struct_fuse_file_info) C.int {
	C.setErrno(C.ENOSYS)
	return -1
}

//export Shim_readdir
func Shim_readdir(path C.constchar, buf unsafe.Pointer, fill C.fuse_fill_dir_t, offset C.off_t, fi *C.struct_fuse_file_info, flags C.enum_fuse_readdir_flags) C.int {
	C.setErrno(C.ENOSYS)
	return -1
}

//export Shim_write
func Shim_write(path C.constchar, data C.constchar, size C.size_t, offset C.off_t, fi *C.struct_fuse_file_info) C.int {
	C.setErrno(C.ENOSYS)
	return -1
}

//export Shim_access
func Shim_access(path C.constchar, mode C.int) C.int {
	C.setErrno(C.ENOSYS)
	return -1
}

//export Shim_create
func Shim_create(path C.constchar, mode C.mode_t, fi *C.struct_fuse_file_info) C.int {
	C.setErrno(C.ENOSYS)
	return -1
}
