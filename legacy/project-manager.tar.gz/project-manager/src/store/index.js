import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    endpoint: "http://52.41.243.213:8080"
  },
  mutations: {
  },
  actions: {
  },
  modules: {
  }
})
