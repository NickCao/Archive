<template>
    <InvoiceSingle class="ma-5" v-bind:oid="$route.params.oid"></InvoiceSingle>
</template>

<script>
    import InvoiceSingle from "../components/InvoiceSingle.vue";
    export default {
        name: 'Invoice',
        data: () => ({}),
        components: {
            'InvoiceSingle': InvoiceSingle,
        }
    }
</script>
