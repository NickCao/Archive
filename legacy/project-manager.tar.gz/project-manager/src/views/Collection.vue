<template>
    <CollectionSingle class="ma-5" v-bind:oid="$route.params.oid"></CollectionSingle>
</template>

<script>
    import CollectionSingle from "../components/CollectionSingle.vue";
    export default {
        name: 'Collection',
        data: () => ({}),
        components: {
            'CollectionSingle': CollectionSingle,
        }
    }
</script>
