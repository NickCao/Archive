<template>
    <v-tabs>
        <v-tab>项目详情</v-tab>
        <v-tab-item>
            <ProjectSingle class="ma-5" v-bind:oid="$route.params.oid"></ProjectSingle>
        </v-tab-item>

        <v-tab>到款信息</v-tab>
        <v-tab-item>
            <CollectionList class="ma-5" v-bind:filter="parent_filter"></CollectionList>
        </v-tab-item>

        <v-tab>开票信息</v-tab>
        <v-tab-item>
            <InvoiceList class="ma-5" v-bind:filter="parent_filter"></InvoiceList>
        </v-tab-item>

        <v-tab>发货信息</v-tab>
        <v-tab-item></v-tab-item>
        <v-tab>验收</v-tab>
        <v-tab-item></v-tab-item>
    </v-tabs>
</template>

<script>
    import ProjectSingle from '../components/ProjectSingle.vue'
    import CollectionList from '../components/CollectionList.vue'
    import InvoiceList from "../components/InvoiceList.vue";

    export default {
        name: 'Project',
        computed: {
            parent_filter: function () {
                return '{"parentOid":{"$eq":"' + this.$route.params.oid + '"}}'
            }
        },
        data: () => ({}),
        components: {
            'ProjectSingle': ProjectSingle,
            'CollectionList': CollectionList,
            'InvoiceList': InvoiceList
        }
    }
</script>
