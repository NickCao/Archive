<template>
  <div>
    <ProjectList class="ma-5"></ProjectList>
  </div>
</template>

<script>
  import ProjectList from '../components/ProjectList.vue'
  export default {
    name: 'Home',
    components: {
      'ProjectList': ProjectList
    }
  }
</script>
