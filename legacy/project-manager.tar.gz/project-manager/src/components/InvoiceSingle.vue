<template>
    <v-form v-model="valid">
        <v-text-field label="工作令" v-model="invoiceInfo.projectId" disabled></v-text-field>
        <v-menu v-model="invoiceDatePicker" :close-on-content-click="false" :nudge-right="40"
                transition="scale-transition" offset-y min-width="290px">
            <template v-slot:activator="{ on }">
                <v-text-field v-model="invoice.invoiceDate" label="开票日期" prepend-icon="mdi-calendar" readonly
                              v-on="on">
                </v-text-field>
            </template>
            <v-date-picker v-model="invoice.invoiceDate" @input="invoiceDatePicker = false"></v-date-picker>
        </v-menu>
        <v-text-field label="发票号码" v-model="invoice.invoiceId" :rules="invoiceIdRules"></v-text-field>
        <v-text-field label="公司名称" v-model="invoiceInfo.company" disabled></v-text-field>
        <v-text-field label="合同号" v-model="invoice.contractId"></v-text-field>
        <v-text-field label="收货单号" v-model="invoice.shippingId"></v-text-field>
        <v-text-field label="开票内容" v-model="invoice.content"></v-text-field>
        <v-text-field label="不含税金额" v-model="invoice.amountNoTax"></v-text-field>
        <v-text-field label="税额" v-model="invoice.amountTax"></v-text-field>
        <v-text-field label="含税金额" v-model="amountAll" disabled></v-text-field>
        <v-text-field label="快递单号" v-model="invoice.logisticId"></v-text-field>
        <v-text-field label="开票次数/百分比" v-model="invoice.ratio"></v-text-field>
        <v-text-field label="申请人" v-model="invoice.submitter"></v-text-field>
        <v-text-field label="采购" v-model="invoice.buyer"></v-text-field>
        <v-btn class="ma-2" large tile color="indigo" dark @click="commit()">保存</v-btn>
        <v-btn class="ma-2" large tile dark @click="load()">重置</v-btn>
    </v-form>
</template>

<script>
    export default {
        name: 'CollectionSingle',
        props: ['oid'],
        computed: {
            amountAll: function () {
                return this.invoice.amountNoTax + this.invoice.amountTax
            }
        },
        data: () => ({
            valid: false,
            invoiceDatePicker: false,
            invoiceIdRules: [
                v => !!v || '发票号不能为空'
            ],
            invoice: {
                parentOid: "",
                invoiceDate: "",
                invoiceId: "",
                contractId: "",
                shippingId: "",
                content: "",
                amountNoTax: "",
                amountTax: "",
                logisticId: "",
                ratio: "",
                submitter: "",
                buyer: ""
            },
            invoiceInfo: {
                company: "",
                projectId: ""
            }
        }),
        mounted: function () {
            this.load()
        },
        methods: {
            load: function () {
                //TODO: compute the invoiceInfo object
                this.$http.get(this.$store.state.endpoint + "/invoice/" + this.oid).then((resp) => (this.invoice = resp.data))
            },
            commit: function () {
                this.$http.put(this.$store.state.endpoint + "/invoice/" + this.oid, this.invoice)
            }
        }
    }
</script>
