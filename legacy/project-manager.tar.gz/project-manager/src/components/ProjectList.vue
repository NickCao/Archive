<template>
    <v-card>
        <v-card-title>
            {{ note }}项目列表
            <v-spacer></v-spacer>
            <v-text-field v-model="search" append-icon="mdi-magnify" label="Search" single-line hide-details>
            </v-text-field>
        </v-card-title>
        <v-data-table :headers="headers" :items="projects" :items-per-page="10" class="elevation-1" :search="search"
                      @click:row="toProject">
        </v-data-table>
    </v-card>
</template>

<script>
    export default {
        name: 'ProjectList',
        props: ['filter', 'note'],
        data: () => ({
            headers: [
                {text: '项目编号', value: 'projectId'},
                {text: '项目名称', value: 'projectName'},
                {text: '用户单位', value: 'company'},
            ],
            projects: [],
            search: ""
        }),
        mounted: function () {
            this.load()
        },
        methods: {
            load: function () {
                this.$http.get(this.$store.state.endpoint + "/project", {
                    params: {
                        filter: this.filter
                    }
                }).then((resp) => (this.projects = resp.data))
            },
            toProject: function (item) {
                this.$router.push({name: "Project", params: {oid: item._id.$oid}})
            }
        }
    }
</script>
