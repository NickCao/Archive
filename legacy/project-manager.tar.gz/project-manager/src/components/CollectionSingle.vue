<template>
    <v-form v-model="valid">
        <v-menu v-model="collectionDatePicker" :close-on-content-click="false" :nudge-right="40"
                transition="scale-transition" offset-y min-width="290px">
            <template v-slot:activator="{ on }">
                <v-text-field v-model="collection.collectionDate" label="到款日期" prepend-icon="mdi-calendar" readonly
                              v-on="on">
                </v-text-field>
            </template>
            <v-date-picker v-model="collection.collectionDate" @input="collectionDatePicker = false"></v-date-picker>
        </v-menu>
        <v-text-field label="凭证号" v-model="collection.collectionId" :rules="collectionIdRules"></v-text-field>
        <v-text-field label="客户公司名称" v-model="collectionInfo.company" disabled></v-text-field>
        <v-text-field label="工作令" v-model="collectionInfo.projectId" disabled></v-text-field>
        <v-text-field label="收入金额" v-model="collection.amount"></v-text-field>
        <v-text-field label="备注" v-model="collection.note"></v-text-field>
        <v-text-field label="收款比例" v-model="collection.ratio"></v-text-field>
        <v-btn class="ma-2" large tile color="indigo" dark @click="commit()">保存</v-btn>
        <v-btn class="ma-2" large tile dark @click="load()">重置</v-btn>
    </v-form>
</template>

<script>
    export default {
        name: 'CollectionSingle',
        props: ['oid'],
        data: () => ({
            valid: false,
            collectionDatePicker: false,
            collectionIdRules: [
                v => !!v || '收款凭证号不能为空'
            ],
            collection: {
                parentOid: "",
                collectionDate: "",
                collectionId: "",
                amount: "",
                note: "",
                ratio: ""
            },
            collectionInfo: {
                company: "",
                projectId: ""
            }
        }),
        mounted: function () {
            this.load()
        },
        methods: {
            load: function () {
                //TODO: compute the collectionInfo object
                this.$http.get(this.$store.state.endpoint + "/collection/" + this.oid).then((resp) => (this.collection = resp.data))
            },
            commit: function () {
                this.$http.put(this.$store.state.endpoint + "/collection/" + this.oid, this.collection)
            }
        }
    }
</script>
