<template>
    <v-form v-model="valid">
        <v-text-field label="项目编号" :rules="projectIdRules" v-model="project.projectId"></v-text-field>
        <v-text-field label="项目名称" v-model="project.projectName"></v-text-field>
        <v-text-field label="用户单位" v-model="project.company"></v-text-field>
        <v-text-field label="订单号/合同号" v-model="project.contract"></v-text-field>
        <v-menu v-model="contractDatePicker" :close-on-content-click="false" :nudge-right="40"
                transition="scale-transition" offset-y min-width="290px">
            <template v-slot:activator="{ on }">
                <v-text-field v-model="project.contractDate" label="合同签订日期" prepend-icon="mdi-calendar" readonly
                              v-on="on">
                </v-text-field>
            </template>
            <v-date-picker v-model="project.contractDate" @input="contractDatePicker = false"></v-date-picker>
        </v-menu>
        <v-menu v-model="shippingDatePicker" :close-on-content-click="false" :nudge-right="40"
                transition="scale-transition"
                offset-y min-width="290px">
            <template v-slot:activator="{ on }">
                <v-text-field v-model="project.shippingDate" label="交货日期" prepend-icon="mdi-calendar" readonly
                              v-on="on">
                </v-text-field>
            </template>
            <v-date-picker v-model="project.shippingDate" @input="shippingDatePicker = false"></v-date-picker>
        </v-menu>
        <v-text-field label="合同金额 (含税)" v-model="project.contractSum"></v-text-field>
        <v-text-field label="合同金额（不含税）" v-model="project.contractSumNoTax"></v-text-field>
        <v-text-field label="开票金额" v-model="projectInfo.invoiceSum" disabled></v-text-field>
        <v-text-field label="收款金额" v-model="projectInfo.collectionSum" disabled></v-text-field>
        <v-text-field label="对方公司采购" v-model="project.buyer"></v-text-field>
        <v-menu v-model="implDatePicker" :close-on-content-click="false" :nudge-right="40"
                transition="scale-transition"
                offset-y min-width="290px">
            <template v-slot:activator="{ on }">
                <v-text-field v-model="project.implDate" label="项目开工日期" prepend-icon="mdi-calendar" readonly
                              v-on="on">
                </v-text-field>
            </template>
            <v-date-picker v-model="project.implDate" @input="implDatePicker = false"></v-date-picker>
        </v-menu>
        <v-text-field label="客户联络人" v-model="project.contact"></v-text-field>
        <v-menu v-model="finalDatePicker" :close-on-content-click="false" :nudge-right="40"
                transition="scale-transition"
                offset-y min-width="290px">
            <template v-slot:activator="{ on }">
                <v-text-field v-model="project.finalDate" label="终验收日期" prepend-icon="mdi-calendar" readonly
                              v-on="on">
                </v-text-field>
            </template>
            <v-date-picker v-model="project.finalDate" @input="finalDatePicker = false"></v-date-picker>
        </v-menu>
        <v-text-field label="送货地点" v-model="project.shippingLocation"></v-text-field>
        <v-text-field label="送货单开具日期" v-model="projectInfo.shippingTicketDate" disabled></v-text-field>
        <v-text-field label="付款方式" v-model="project.paymentMethod"></v-text-field>
        <v-btn class="ma-2" large tile color="indigo" dark @click="commit()">保存</v-btn>
        <v-btn class="ma-2" large tile dark @click="load()">重置</v-btn>
    </v-form>
</template>

<script>
    export default {
        name: 'ProjectSingle',
        props: ['oid'],
        data: () => ({
            valid: false,
            contractDatePicker: false,
            shippingDatePicker: false,
            implDatePicker: false,
            finalDatePicker: false,
            projectIdRules: [
                v => !!v || '项目编号不能为空'
            ],
            project: {
                projectId: "",
                projectName: "",
                company: "",
                contract: "",
                contractDate: "",
                shippingDate: "",
                contractSum: "",
                contractSumNoTax: "",
                buyer: "",
                implDate: "",
                contact: "",
                finalDate: "",
                shippingLocation: "",
                paymentMethod: ""
            },
            projectInfo: {
                invoiceSum: "",
                collectionSum: "",
                shippingTicketDate: ""
            }
        }),
        mounted: function () {
            this.load()
        },
        methods: {
            load: function () {
                //TODO: compute the projectInfo object
                this.$http.get(this.$store.state.endpoint + "/project/" + this.oid).then((resp) => (this.project = resp.data))
            },
            commit: function () {
                this.$http.put(this.$store.state.endpoint + "/project/" + this.oid, this.project)
            }
        }
    }
</script>
