<template>
    <v-card>
        <v-card-title>
            {{ note }}开票列表
            <v-spacer></v-spacer>
            <v-text-field v-model="search" append-icon="mdi-magnify" label="Search" single-line hide-details>
            </v-text-field>
        </v-card-title>
        <v-data-table :headers="headers" :items="invoices" :items-per-page="10" class="elevation-1" :search="search"
                      @click:row="toInvoice">
        </v-data-table>
    </v-card>
</template>

<script>
    export default {
        name: 'InvoiceList',
        props: ['filter', 'note'],
        data: () => ({
            search: "",
            headers: [
                {text: '开票日期', value: 'invoiceDate'},
                {text: '发票号码', value: 'invoiceId'},
                {text: '开票内容', value: 'content'},
            ],
            invoices: []
        }),
        mounted: function () {
            this.load()
        },
        methods: {
            load: function () {
                this.$http.get(this.$store.state.endpoint + "/invoice", {
                    params: {
                        filter: this.filter
                    }
                }).then((resp) => (this.invoices = resp.data))
            },
            toInvoice: function (item) {
                this.$router.push({name: "Invoice", params: {oid: item._id.$oid}})
            }
        }
    }
</script>
