<template>
    <v-card>
        <v-card-title>
            {{ note }}收款列表
            <v-spacer></v-spacer>
            <v-text-field v-model="search" append-icon="mdi-magnify" label="Search" single-line hide-details>
            </v-text-field>
        </v-card-title>
        <v-data-table :headers="headers" :items="collections" :items-per-page="10" class="elevation-1" :search="search"
                      @click:row="toCollection">
        </v-data-table>
    </v-card>
</template>

<script>
    export default {
        name: 'CollectionList',
        props: ['filter', 'note'],
        data: () => ({
            search: "",
            headers: [
                {text: '凭证号', value: 'collectionId'},
                {text: '到款日期', value: 'collectionDate'},
                {text: '收入金额', value: 'amount'},
            ],
            collections: []
        }),
        mounted: function () {
            this.load()
        },
        methods: {
            load: function () {
                this.$http.get(this.$store.state.endpoint + "/collection", {
                    params: {
                        filter: this.filter
                    }
                }).then((resp) => (this.collections = resp.data))
            },
            toCollection: function (item) {
                this.$router.push({name: "Collection", params: {oid: item._id.$oid}})
            }
        }
    }
</script>
