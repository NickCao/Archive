import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import Project from '../views/Project.vue'
import Collection from '../views/Collection.vue'
import Invoice from "../views/Invoice.vue";

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/project/:oid',
    name: 'Project',
    component: Project
  },
  {
    path: '/collection/:oid',
    name: 'Collection',
    component: Collection
  },
  {
    path: '/invoice/:oid',
    name: 'Invoice',
    component: Invoice
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
