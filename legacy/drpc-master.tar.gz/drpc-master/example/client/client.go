package main

import (
	"bytes"
	"io"
	"os"

	"gitlab.com/nickcao/drpc"
)

func main() {
	clnt := drpc.NewClient("127.0.0.1:8080")
	io := struct {
		io.Reader
		io.Writer
	}{bytes.NewBuffer([]byte("example text")), os.Stdout}
	io2 := io
	clnt.Call("echo", io)
	clnt.Call("upper", io2)
}
