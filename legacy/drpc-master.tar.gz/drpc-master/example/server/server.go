package main

import (
	"io"
	"io/ioutil"
	"strings"

	"gitlab.com/nickcao/drpc"
)

func main() {
	serv := drpc.NewServer()
	serv.Register(echo, "echo", "just a sample func")
	serv.Register(upper, "upper", "to upper")
	serv.Run("127.0.0.1:8080")
}

func echo(conn io.ReadWriter) {
	io.Copy(conn, conn)
}

func upper(conn io.ReadWriter) {
	data, _ := ioutil.ReadAll(conn)
	conn.Write([]byte(strings.ToUpper(string(data))))
}

func req(conn io.ReadWriter) {

}
