package drpc

import (
	"io"
	"net/http"
	"net/url"
)

//Client ...
type Client struct {
	host   string
	client *http.Client
}

//NewClient ...
func NewClient(host string) *Client {
	return &Client{
		host:   host,
		client: &http.Client{},
	}
}

//Call ...
func (clnt *Client) Call(name string, rw io.ReadWriter) error {
	u := url.URL{
		Scheme: "http",
		Host:   clnt.host,
		Path:   "/endpoints/" + name,
	}
	resp, err := clnt.client.Post(u.String(), "application/binary", rw)
	if err != nil {
		return err
	}
	io.Copy(rw, resp.Body)
	return nil
}
