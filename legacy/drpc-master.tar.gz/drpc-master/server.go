package drpc

import (
	"bytes"
	"io"

	"github.com/gin-gonic/gin"
)

//Server ...
type Server struct {
	eng  *gin.Engine
	impl map[string]func(io.ReadWriter)
	doc  map[string]string
}

//NewServer ...
func NewServer() *Server {
	serv := &Server{}
	serv.impl = make(map[string]func(io.ReadWriter))
	serv.doc = make(map[string]string)
	serv.eng = gin.New()
	serv.eng.Use(gin.Logger(), gin.Recovery())
	serv.eng.POST("/endpoints/:name", serv.callhandler)
	serv.eng.GET("/doc/", serv.dochandler)
	return serv
}

//Register ...
func (serv *Server) Register(f func(io.ReadWriter), name, doc string) {
	serv.doc[name] = doc
	serv.impl[name] = f
}

//Run ...
func (serv *Server) Run(addr ...string) error {
	return serv.eng.Run(addr...)
}

func (serv *Server) callhandler(c *gin.Context) {
	if serv.impl[c.Param("name")] == nil {
		c.AbortWithStatus(404)
		return
	}
	r, err := c.GetRawData()
	if err != nil {
		c.AbortWithStatus(400)
		return
	}
	rw := struct {
		io.Reader
		io.Writer
	}{bytes.NewBuffer(r), c.Writer}
	serv.impl[c.Param("name")](rw)
}

func (serv *Server) dochandler(c *gin.Context) {
	c.JSON(200, serv.doc)
}
