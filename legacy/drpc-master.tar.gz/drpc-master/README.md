# dRPC

A not drop-in substitute for gRPC