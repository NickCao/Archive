use std::fs::File;
use memmap::MmapOptions;
use rayon::prelude::*;
use rayon::iter::ParallelBridge;
use std::iter::successors;
use std::hash::Hasher;
use std::collections::hash_map::DefaultHasher;
#[macro_use]
extern crate clap;
use clap::App;

const MB :usize = 1024*1024;


fn main() -> std::io::Result<()>{
    let yaml = load_yaml!("cli.yaml");
    let matches = App::from_yaml(yaml).get_matches();
    let f = File::open(matches.value_of("file").unwrap())?;
    let mut m = MmapOptions::new();
    match matches.value_of("filesize"){
        Some(s) => {m.len(s.parse().unwrap_or(0));},
        None => {}
    };
    let m = unsafe{m.map(&f)?};
    let counter = successors(Some(0), |x| -> Option<usize> {Some(x+1)});
    m.chunks(matches.value_of("chunksize").unwrap_or("64").parse().unwrap_or(64)*MB).zip(counter).par_bridge().map(|(c,i)|-> (u64,usize){
        let mut ha = DefaultHasher::new();
        ha.write(c);
        (ha.finish(),i)
    }).for_each(|(h,i)|{
        println!("{:04}:{:016X}",i,h);
    });
    Ok(())
}