Archlinux nvidia-prime like package
==================================

Assumptions
-----------

* You are running Archlinux
* You don't have bumblebee installed
* You installed NVIDIA drivers using https://wiki.archlinux.org/index.php/NVIDIA
* You have no xorg config file that will interfere with ArchPrime

Notes
-----

* You may have to run the following command on xserver start when switched to nvidia

```
xrandr --setprovideroutputsource modesetting NVIDIA-0
xrandr --auto
```

Contact
-------

* Nick Cao <nickcao@nichi.co>
