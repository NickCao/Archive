#include "sort.h"
#include <cstring>

void rec_mergesort(int *a, int *b, int lower, int upper) {
    if (upper - lower < 2)
        return;

    int interval = (upper - lower) / 3;
    int lower_mid = lower + interval;
    int upper_mid = lower + 2 * interval + 1;

    rec_mergesort(b, a, lower, lower_mid);
    rec_mergesort(b, a, lower_mid, upper_mid);
    rec_mergesort(b, a, upper_mid, upper);

    int i = lower, j = lower_mid, k = upper_mid, l = lower;
    int max, min;

    while (i < lower_mid && j < upper_mid && k < upper) {
        compare(b[i], b[j], b[k], &max, &min);
        if (min == b[i])
            a[l++] = b[i++];
        else if (min == b[j])
            a[l++] = b[j++];
        else
            a[l++] = b[k++];
    }

    while (i < lower_mid && j < upper_mid) {
        compare(b[i], b[j], b[j], &max, &min);
        a[l++] = b[i] == min ? b[i++] : b[j++];
    }

    while (j < upper_mid && k < upper) {
        compare(b[j], b[k], b[k], &max, &min);
        a[l++] = b[j] == min ? b[j++] : b[k++];
    }

    while (i < lower_mid && k < upper) {
        compare(b[i], b[k], b[k], &max, &min);
        a[l++] = b[i] == min ? b[i++] : b[k++];
    }

    memcpy(a + l, b + i, (lower_mid - i) * sizeof(int));
    memcpy(a + l + (lower_mid - i), b + j, (upper_mid - j) * sizeof(int));
    memcpy(a + l + (lower_mid - i) + (upper_mid - j), b + k, (upper - k) * sizeof(int));
}

void mergesort(int *a, int n) {
    int b[n];
    memcpy(b, a, n * sizeof(int));
    rec_mergesort(b, a, 0, n);
    memcpy(a, b, n * sizeof(int));
}

void sort(int n, int limit, int *a) {
    mergesort(a, n);
}
