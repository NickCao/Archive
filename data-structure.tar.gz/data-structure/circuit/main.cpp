#include <iostream>
#include <string>


struct node {
    int index;
    node *zero, *one;
    int i_cache = -1;
    bool in_range_cache = false;

    node() : index(-1), zero(nullptr), one(nullptr) {}

    bool in_range(int i, int k) {
        if (i == i_cache) {
            return in_range_cache;
        }
        bool res;
        if (zero == nullptr && one == nullptr)
            res = index <= i + k + 1 && index >= i - k - 1;
        else if (zero == nullptr)
            res = one->in_range(i, k);
        else if (one == nullptr)
            res = zero->in_range(i, k);
        else
            res = zero->in_range(i, k) || one->in_range(i, k);
        i_cache = i;
        in_range_cache = res;
        return res;
    }
};

int main() {
    std::iostream::sync_with_stdio(false);
    int n, k;
    std::cin >> n >> k;

    auto root = new node();
    std::string lines[n];
    for (int i = 0; i < n; i++) {
        std::string line;
        std::cin >> line;
        lines[i] = line;
        auto cur = root;
        for (auto &c: line) {
            switch (c) {
                case '0':
                    if (cur->zero == nullptr) cur->zero = new node;
                    cur = cur->zero;
                    break;
                case '1':
                    if (cur->one == nullptr) cur->one = new node;
                    cur = cur->one;
                    break;
                default:
                    break;
            }
        }
        cur->index = i;
    }

    for (int i = 0; i < n; i++) {
        auto line = lines[i];
        auto dst = root;
        for (auto &c : line) {
            if (c == '0') {
                if (dst->one != nullptr && dst->one->in_range(i, k))
                    dst = dst->one;
                else
                    dst = dst->zero;
            } else {
                if (dst->zero != nullptr && dst->zero->in_range(i, k))
                    dst = dst->zero;
                else
                    dst = dst->one;
            }
        }
        std::cout << dst->index << std::endl;
    }
}
