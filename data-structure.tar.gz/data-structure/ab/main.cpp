#include <cmath>
#include <cstdio>
#include <cstring>

#define MAX 50001 * 2 * 4

using namespace std;

// start: fft算法, ref: https://oi-wiki.org/math/poly/fft/#_10
struct comp {
    double r, i;

    explicit comp(double r = 0, double i = 0) : r(r), i(i) {}

    comp operator+(const comp &b) const { return comp(r + b.r, i + b.i); }

    comp operator-(const comp &b) const { return comp(r - b.r, i - b.i); }

    comp operator*(const comp &b) const { return comp(r * b.r - i * b.i, r * b.i + i * b.r); }
};

void change(comp y[], int len) {
    int i, j, k;
    for (int i = 1, j = len / 2; i < len - 1; i++) {
        if (i < j) {
            comp tmp = y[i];
            y[i] = y[j];
            y[j] = tmp;
        }
        k = len / 2;
        while (j >= k) {
            j = j - k;
            k = k / 2;
        }
        if (j < k) j += k;
    }
}

void fft(comp y[], int len, int on) {
    change(y, len);
    for (int h = 2; h <= len; h <<= 1) {
        comp wn(cos(2 * M_PI / h), sin(on * 2 * M_PI / h));
        for (int j = 0; j < len; j += h) {
            comp w(1, 0);
            for (int k = j; k < j + h / 2; k++) {
                comp u = y[k];
                comp t = w * y[k + h / 2];
                y[k] = u + t;
                y[k + h / 2] = u - t;
                w = w * wn;
            }
        }
    }
    if (on == -1) {
        for (int i = 0; i < len; i++) {
            y[i].r /= len;
        }
    }
}
// end: fft算法

comp a[MAX], b[MAX];
char sa[MAX / 2], sb[MAX / 2];
int c[MAX];

int main() {
    int n;
    scanf("%d", &n);
    for (int l = 0; l < n; l++) {
        scanf("%s%s", sa, sb);
        int la = strlen(sa);
        int lb = strlen(sb);

        int len = 1;
        while (len < la * 2 || len < lb * 2)
            len *= 2;

        for (int i = 0; i < len; i++)
            a[i] = i < la ? comp(sa[la - 1 - i] - '0', 0) : comp(0, 0);

        for (int i = 0; i < len; i++)
            b[i] = i < lb ? comp(sb[lb - 1 - i] - '0', 0) : comp(0, 0);

        fft(a, len, 1);
        fft(b, len, 1);

        for (int i = 0; i < len; i++)
            a[i] = a[i] * b[i];

        fft(a, len, -1);

        for (int i = 0; i < len; i++)
            c[i] = round(a[i].r);

        for (int i = 0; i < len; i++) {
            c[i + 1] += c[i] / 10;
            c[i] %= 10;
        }

        bool start = false;
        for (int i = la + lb - 1; i >= 0; i--) {
            if (!start && c[i] <= 0 && i > 0)
                continue;
            start = true;
            printf("%c", c[i] + '0');
        }
        printf("\n");
    }
}
