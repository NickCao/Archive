#include <iostream>

#define MAX 100

using namespace std;

template<class T>
class FIFO {
private:
    T buffer[MAX];
    int cap;
    int size;
    int miss;

    void push(T x) {
        if (size < cap) {
            buffer[size] = x;
            size++;
            return;
        }
        for (int i = 0; i < cap - 1; i++) {
            buffer[i] = buffer[i + 1];
        }
        buffer[cap - 1] = x;
    }

public:
    explicit FIFO(int _cap = 0) {
        cap = _cap;
        size = 0;
        miss = 0;
    }

    ~FIFO() = default;

    bool find(T x) {
        for (int i = 0; i < size; i++) {
            if (x == buffer[i]) return true;
        }
        miss++;
        this->push(x);
        return false;
    }

    int miss_count() {
        return miss;
    }
};

int main() {
    int n, m;
    cin >> n >> m;
    FIFO<int> f(n);
    for (int i = 0; i < m; i++) {
        int d;
        cin >> d;
        f.find(d);
    }
    cout << f.miss_count() << endl;
    return 0;
}
