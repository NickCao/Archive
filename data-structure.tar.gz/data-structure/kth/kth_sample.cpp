#include "kth.h"
#include <cstdlib>
#include <cmath>
#include <functional>

template<class T, class Comp = std::less<T>>
class FibHeap {
public:

    class FibNode {
    public:
        explicit FibNode(T k)
                : key(std::move(k)), mark(false), p(nullptr), left(nullptr), right(nullptr), child(nullptr),
                  degree(-1) {
        }

        ~FibNode() = default;

        T key;
        bool mark;
        FibNode *p;
        FibNode *left;
        FibNode *right;
        FibNode *child;
        int degree;
    };

    FibHeap() : FibHeap(std::less<T>()) {
    }

    explicit FibHeap(Comp comp)
            : n(0), min(nullptr), comp(comp) {
    }

    void delete_fibnodes(FibNode *x) {
        if (!x)
            return;

        FibNode *cur = x;
        while (true) {
            if (cur->left && cur->left != x) {
                FibNode *tmp = cur;
                cur = cur->left;
                if (tmp->child)
                    delete_fibnodes(tmp->child);
                delete tmp;
            } else {
                if (cur->child)
                    delete_fibnodes(cur->child);
                delete cur;
                break;
            }
        }
    }

    void insert(FibNode *x) {
        x->degree = 0;
        x->p = nullptr;
        x->child = nullptr;
        x->mark = false;
        if (min == nullptr) {
            min = x->left = x->right = x;
        } else {
            min->left->right = x;
            x->left = min->left;
            min->left = x;
            x->right = min;
            if (comp(x->key, min->key)) {
                min = x;
            }
        }
        ++n;
    }


    void cut(FibNode *x, FibNode *y) {
        if (x->right == x) {
            y->child = nullptr;
        } else {
            x->right->left = x->left;
            x->left->right = x->right;
            if (y->child == x) {
                y->child = x->right;
            }
        }
        y->degree--;
        min->right->left = x;
        x->right = min->right;
        min->right = x;
        x->left = min;
        x->p = nullptr;
        x->mark = false;
    }

    void cascading_cut(FibNode *y) {
        FibNode *z;
        z = y->p;
        if (z != nullptr) {
            if (y->mark == false) {
                y->mark = true;
            } else {
                cut(y, z);
                cascading_cut(z);
            }
        }
    }


    T &top() {
        return min->key;
    }

    void pop() {
        if (n == 0)
            return;
        FibNode *z, *x1, *next;
        FibNode **childList;

        z = min;
        if (z != nullptr) {
            x1 = z->child;
            if (x1 != nullptr) {
                childList = new FibNode *[z->degree];
                next = x1;
                for (int i = 0; i < (int) z->degree; i++) {
                    childList[i] = next;
                    next = next->right;
                }
                for (int i = 0; i < (int) z->degree; i++) {
                    x1 = childList[i];
                    min->left->right = x1;
                    x1->left = min->left;
                    min->left = x1;
                    x1->right = min;
                    x1->p = nullptr;
                }
                delete[] childList;
            }
            z->left->right = z->right;
            z->right->left = z->left;
            if (z == z->right) {
                min = nullptr;
            } else {
                min = z->right;
                FibNode *w, *next1, *x, *y, *temp;
                FibNode **a, **rootList;
                int d, rootSize;
                int maxDegree = static_cast<int>(floor(
                        log(static_cast<double>(n)) / log(static_cast<double>(1 + sqrt(static_cast<double>(5))) / 2)));

                a = new FibNode *[maxDegree + 2];
                std::fill_n(a, maxDegree + 2, nullptr);
                w = min;
                rootSize = 0;
                next1 = w;
                do {
                    rootSize++;
                    next1 = next1->right;
                } while (next1 != w);
                rootList = new FibNode *[rootSize];
                for (int i = 0; i < rootSize; i++) {
                    rootList[i] = next1;
                    next1 = next1->right;
                }
                for (int i = 0; i < rootSize; i++) {
                    w = rootList[i];
                    x = w;
                    d = x->degree;
                    while (a[d] != nullptr) {
                        y = a[d];
                        if (comp(y->key, x->key)) {
                            temp = x;
                            x = y;
                            y = temp;
                        }
                        y->left->right = y->right;
                        y->right->left = y->left;
                        if (x->child != nullptr) {
                            x->child->left->right = y;
                            y->left = x->child->left;
                            x->child->left = y;
                            y->right = x->child;
                        } else {
                            x->child = y;
                            y->right = y;
                            y->left = y;
                        }
                        y->p = x;
                        x->degree++;
                        y->mark = false;
                        a[d] = nullptr;
                        d++;
                    }
                    a[d] = x;
                }
                delete[] rootList;
                min = nullptr;
                for (int i = 0; i < maxDegree + 2; i++) {
                    if (a[i] != nullptr) {
                        if (min == nullptr) {
                            min = a[i]->left = a[i]->right = a[i];
                        } else {
                            min->left->right = a[i];
                            a[i]->left = min->left;
                            min->left = a[i];
                            a[i]->right = min;
                            if (comp(a[i]->key, min->key)) {
                                min = a[i];
                            }
                        }
                    }
                }
                delete[] a;
            }
            n--;
        }
        FibNode *x = z;
        delete x;
    }

    FibNode *push(T k) {
        auto *x = new FibNode(std::move(k));
        insert(x);
        return x;
    }

    int n{};
    FibNode *min;
    Comp comp;

};


enum color_t {
    RED, BLACK, NO
};

struct node_t {
    unsigned key{};
    unsigned value{};
    node_t *left = nullptr;
    node_t *right = nullptr;
    node_t *parent = nullptr;
    color_t color = NO;
};

class rbtree_t {
    node_t *root;

public:
    rbtree_t() : root(nullptr) {}

    void insert(unsigned key, unsigned value) {
        if (root == nullptr) {
            root = new node_t();
            root->key = key;
            root->value = value;
            root->parent = nullptr;
            root->color = BLACK;
        } else {
            auto linker = root;
            auto *new_node = new node_t();
            new_node->key = key;
            new_node->value = value;

            while (linker != nullptr) {
                if (linker->key > key) {
                    if (linker->left == nullptr) {
                        linker->left = new_node;
                        new_node->color = RED;
                        new_node->parent = linker;
                        break;
                    } else { linker = linker->left; }
                } else {
                    if (linker->right == nullptr) {
                        linker->right = new_node;
                        new_node->parent = linker;
                        break;
                    } else { linker = linker->right; }
                }
            }
            node_t *z = new_node;
            while (z->parent->color == RED) {
                auto grandparent = z->parent->parent;
                auto uncle = root;
                if (z->parent == grandparent->left) {
                    if (grandparent->right) { uncle = grandparent->right; }
                    if (uncle->color == RED) {
                        z->parent->color = BLACK;
                        uncle->color = BLACK;
                        grandparent->color = RED;
                        if (grandparent->key != root->key) { z = grandparent; }
                        else { break; }
                    } else if (z == grandparent->left->right) {
                        l_rotate(z->parent);
                    } else {
                        z->parent->color = BLACK;
                        grandparent->color = RED;
                        r_rotate(grandparent);
                        if (grandparent->key != root->key) { z = grandparent; }
                        else { break; }
                    }
                } else {
                    if (grandparent->left) { uncle = grandparent->left; }
                    if (uncle->color == RED) {
                        z->parent->color = BLACK;
                        uncle->color = BLACK;
                        grandparent->color = RED;
                        if (grandparent->key != root->key) { z = grandparent; }
                        else { break; }
                    } else if (z == grandparent->right->left) {
                        r_rotate(z->parent);
                    } else {
                        z->parent->color = BLACK;
                        grandparent->color = RED;
                        l_rotate(grandparent);
                        if (grandparent->key != root->key) { z = grandparent; }
                        else { break; }
                    }
                }
            }
            root->color = BLACK;
        }
    }

    node_t *search(unsigned key) {
        auto temp = root;
        if (temp == nullptr) { return nullptr; }

        while (temp) {
            if (key == temp->key) { return temp; }
            else if (key < temp->key) { temp = temp->left; }
            else { temp = temp->right; }
        }
        return nullptr;
    }

    static void l_rotate(node_t *x) {
        auto *nw_node = new node_t();
        if (x->right->left) { nw_node->right = x->right->left; }
        nw_node->left = x->left;
        nw_node->key = x->key;
        nw_node->value = x->value;
        nw_node->color = x->color;
        x->key = x->right->key;
        x->value = x->right->value;

        x->left = nw_node;
        if (nw_node->left) { nw_node->left->parent = nw_node; }
        if (nw_node->right) { nw_node->right->parent = nw_node; }
        nw_node->parent = x;

        if (x->right->right) { x->right = x->right->right; }
        else { x->right = nullptr; }

        if (x->right) { x->right->parent = x; }
    }

    static void r_rotate(node_t *x) {
        auto *nw_node = new node_t();
        if (x->left->right) { nw_node->left = x->left->right; }
        nw_node->right = x->right;
        nw_node->key = x->key;
        nw_node->value = x->value;
        nw_node->color = x->color;

        x->key = x->left->key;
        x->value = x->left->value;
        x->color = x->left->color;

        x->right = nw_node;
        if (nw_node->left) { nw_node->left->parent = nw_node; }
        if (nw_node->right) { nw_node->right->parent = nw_node; }
        nw_node->parent = x;

        if (x->left->left) { x->left = x->left->left; }
        else { x->left = nullptr; }

        if (x->left) { x->left->parent = x; }
    }
    void RB_Delete_Fixup(node_t* z) {
        while(z->value != root->value && z->color == BLACK) {
            auto sibling = root;
            if(z->parent->left == z) {
                if(z->parent->right){ sibling = z->parent->right; }
                if(sibling) {
                    //CASE -- 1
                    if(sibling->color == RED) {
                        sibling->color = BLACK;
                        z->parent->color = RED;
                        l_rotate(z->parent);
                        sibling = z->parent->right;
                    }
                    //CASE -- 2
                    if(sibling->left == nullptr && sibling->right == nullptr) {
                        sibling->color = RED;
                        z = z->parent;
                    }
                    else if(sibling->left->color == BLACK && sibling->right->color == BLACK) {
                        sibling->color = RED;
                        z = z->parent;
                    }
                        //CASE -- 3
                    else if(sibling->right->color == BLACK) {
                        sibling->left->color = BLACK;
                        sibling->color = RED;
                        r_rotate(sibling);
                        sibling = z->parent->right;
                    } else {
                        sibling->color = z->parent->color;
                        z->parent->color = BLACK;
                        if(sibling->right){ sibling->right->color = BLACK; }
                        l_rotate(z->parent);
                        z = root;
                    }
                }
            } else {
                if(z->parent->right == z){
                    if(z->parent->left){ sibling = z->parent->left; }
                    if(sibling) {
                        //CASE -- 1
                        if(sibling->color == RED){
                            sibling->color = BLACK;
                            z->parent->color = RED;
                            r_rotate(z->parent);
                            sibling = z->parent->left;
                        }
                        //CASE -- 2
                        if(sibling->left == nullptr && sibling->right == nullptr) {
                            sibling->color = RED;
                            z = z->parent;
                        }
                        else if(sibling->left->color == BLACK && sibling->right->color == BLACK) {
                            sibling->color = RED;
                            z = z->parent;
                        }
                            //CASE -- 3 
                        else if(sibling->left->color == BLACK) {
                            sibling->right->color = BLACK;
                            sibling->color = RED;
                           l_rotate(sibling);
                            sibling = z->parent->left;
                        } else {
                            sibling->color = z->parent->color;
                            z->parent->color = BLACK;
                            if(sibling->left){ sibling->left->color = BLACK; }
                            l_rotate(z->parent);
                            z = root;
                        }
                    }
                }

            }
        }
        z->color = BLACK;
    }
    void remove_node(node_t* parent, node_t* curr, int stuff) {
        if(curr == nullptr) { return; }
        if(curr->value == stuff) {
            //CASE -- 1
            if(curr->left == nullptr && curr->right == nullptr) {
                if(parent->value == curr->value){ root = nullptr; }
                else if(parent->right == curr) {
                    RB_Delete_Fixup(curr);
                    parent->right = nullptr;
                }
                else {
                    RB_Delete_Fixup(curr);
                    parent->left = nullptr;
                }
            }
                //CASE -- 2
            else if(curr->left != nullptr && curr->right == nullptr) {
                int swap = curr->value;
                curr->value = curr->left->value;
                curr->left->value = swap;
                remove_node(curr, curr->right, stuff);
            }
            else if(curr->left == nullptr && curr->right != nullptr) {
                int swap = curr->value;
                curr->value = curr->right->value;
                curr->right->value = swap;
                remove_node(curr, curr->right, stuff);
            }
                //CASE -- 3
            else {
                bool flag = false;
                node_t* temp = curr->right;
                while(temp->left) { flag = true; parent = temp; temp = temp->left; }
                if(!flag) { parent = curr; }
                int swap = curr->value;
                curr->value = temp->value;
                temp->value = swap;
                remove_node(parent, temp, swap);
            }
        }
    }

    void remove(unsigned key) {
        auto temp = root;
        auto parent = temp;
        bool flag = false;
        if(!temp) { remove_node(nullptr, nullptr, key); }

        while(temp) {
            if(key == temp->value) { flag = true;
                remove_node(parent, temp, key); break; }
            else if(key < temp->value) { parent = temp ; temp = temp->left; }
            else { parent = temp ; temp = temp->right; }
        }
    }
};


int *ax, *ay, *az;

struct triple {
    int x, y, z;

    explicit triple(int x = 0, int y = 0, int z = 0) : x(x), y(y), z(z) {};

    friend bool operator<(const triple &l, const triple &r) {
        return compare(ax[l.x], ay[l.y], az[l.z], ax[r.x], ay[r.y], az[r.z]) == 1;
    }

};

void get_kth(int n, int k, int *x, int *y, int *z) {
    ax = new int[n];
    ay = new int[n];
    az = new int[n];
    for (int i = 0; i < n; i++) {
        ax[i] = i + 1;
        ay[i] = i + 1;
        az[i] = i + 1;
    }
    qsort(ax, n, sizeof(int),
          [](const void *b, const void *a) { return compare(*(int *) a, 1, 1, *(int *) b, 1, 1); });
    qsort(ay, n, sizeof(int),
          [](const void *b, const void *a) { return compare(1, *(int *) a, 1, 1, *(int *) b, 1); });
    qsort(az, n, sizeof(int),
          [](const void *b, const void *a) { return compare(1, 1, *(int *) a, 1, 1, *(int *) b); });

    FibHeap<triple> pq;
    pq.push(triple(0, 0, 0));
    rbtree_t set;

    triple top;
    for (int i = 1; i <= k; i++) {
        top = pq.top();
        pq.pop();
        if (top.x + 1 < n && set.search((top.x + 1) * n * n + top.y * n + top.z) == nullptr) {
            set.insert((top.x + 1) * n * n + top.y * n + top.z, 0);
            pq.push(triple(top.x + 1, top.y, top.z));
        }
        if (top.y + 1 < n && set.search(top.x * n * n + (top.y + 1) * n + top.z) == nullptr) {
            set.insert(top.x * n * n + (top.y + 1) * n + top.z, 0);
            pq.push(triple(top.x, top.y + 1, top.z));
        }
        if (top.z + 1 < n && set.search(top.x * n * n + top.y * n + (top.z + 1)) == nullptr) {
            set.insert(top.x * n * n + top.y * n + (top.z + 1), 0);
            pq.push(triple(top.x, top.y, top.z + 1));
        }
    }

    *x = ax[top.x];
    *y = ay[top.y];
    *z = az[top.z];
}