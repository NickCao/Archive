#include <string>
#include <iostream>

struct node {
    char data;
    unsigned freq;
    node *left, *right;

    node(char data, unsigned freq) : data(data), freq(freq), left(nullptr), right(nullptr) {}

    node(char data, unsigned freq, node *l, node *r) : node(data, freq) {
        left = l;
        right = r;
    }
};

struct heap {
    int size;
    struct node **array;

    explicit heap(int size) : size(size), array(new node *[size]) {}

    void minify(int i) {
        int min = i;
        int l = 2 * i + 1;
        int r = 2 * i + 2;
        if (l < size && array[l]->freq < array[min]->freq)
            min = l;

        if (r < size && array[r]->freq < array[min]->freq)
            min = r;

        if (min != i) {
            std::swap(array[min], array[i]);
            minify(min);
        }
    }

    node *min() {
        struct node *tmp = array[0];
        array[0] = array[size - 1];
        size--;
        minify(0);
        return tmp;
    }
};

struct node *huffman(char *data, int *freq, int size) {
    auto min_heap = new heap(size);
    for (int i = 0; i < size; i++)
        min_heap->array[i] = new node(data[i], freq[i]);
    for (int i = min_heap->size / 2 - 1; i >= 0; i--)
        min_heap->minify(i);

    while (min_heap->size != 1) {
        auto left = min_heap->min();
        auto right = min_heap->min();
        auto top = new node('*', left->freq + right->freq, left, right);
        min_heap->size++;
        int i = min_heap->size - 1;
        while (i && top->freq < min_heap->array[(i - 1) / 2]->freq) {
            min_heap->array[i] = min_heap->array[(i - 1) / 2];
            i = (i - 1) / 2;
        }
        min_heap->array[i] = top;
    }
    return min_heap->min();
}

void traverse(struct node *root, int *record, int top, std::string *code) {
    if (root->left) {
        record[top] = 0;
        traverse(root->left, record, top + 1, code);
    }
    if (root->right) {
        record[top] = 1;
        traverse(root->right, record, top + 1, code);
    }
    if (!(root->left || root->right))
        for (int i = 0; i < top; i++)
            code[root->data - 'a'].push_back(record[i] + '0');
}

int main() {
    std::iostream::sync_with_stdio(false);
    std::string raw;
    std::cin >> raw;

    int freq[26] = {0};
    for (auto &c: raw)
        freq[c - 'a']++;

    char word[26];
    for (char i = 'a'; i <= 'z'; i++)
        word[i - 'a'] = i;

    struct node *root = huffman(word, freq, 26);
    std::string code[26];
    int record[100];
    traverse(root, record, 0, code);

    int sum = 0;
    for (int i = 0; i < 26; i++)
        sum += code[i].length() * freq[i];
    std::cout << sum << std::endl;

    for (char i = 'a'; i <= 'z'; i++)
        std::cout << i << " " << code[i - 'a'] << std::endl;
}
