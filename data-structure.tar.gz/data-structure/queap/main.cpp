#include <cstdio>
#include <cstdlib>

#define MAX_SIZE 1000001

int daily_cases[MAX_SIZE];
int backtrack_days[MAX_SIZE];
int sliding_max[MAX_SIZE];
int dq[MAX_SIZE*10];
int front = 0, end = 0;

int count_lower(int n, int val) {
    int count = 0;
    for (int i = 1; i <= n; i++) {
        if (sliding_max[i] < val)
            count++;
        else
            break;
    }
    return count;
}

int main() {
    int n;
    scanf("%d", &n);
    for (int i = 1; i <= n; i++)
        scanf("%d", &daily_cases[i]);
    for (int i = 1; i <= n; i++)
        scanf("%d", &backtrack_days[i]);

    dq[0] = 0;
    end++;
    for (int i = 1; i <= n; i++) {
        sliding_max[i] = daily_cases[dq[front]];
        while ((end > front) && dq[front] < i - backtrack_days[i])
            front++;
        while ((end > front) && daily_cases[i] >= daily_cases[dq[end - 1]])
            end--;
        dq[end] = i;
        end++;
    }
    qsort(sliding_max + 1, n, sizeof(int), [](const void *a, const void *b) { return (*(int *) a - *(int *) b); });

    int t;
    scanf("%d", &t);
    for (int i = 1; i <= t; i++) {
        int p, q;
        scanf("%d%d", &p, &q);
        int l = count_lower(n, p);
        int m = count_lower(n, q);
        printf("%d %d\n", l, m - l);
    }
    return 0;
}
