#include <string>
#include <iostream>

using namespace std;

int cost(const char *s1, const char *s2, int l1, int l2, int k) {
    if (abs(l1 - l2) > k)
        return -1;

    int dp[2][l2 + 1];
    bool flag;

    for (int i = 0; i <= l1; i++) {
        flag = i & 1;
        int start = i - k > 0 ? i - k : 0;
        int end = i + k < l2 ? i + k : l2;
        dp[flag][end + 1] = 0;
        dp[flag][start - 1] = 0;
        for (int j = start; j <= end; j++) {
            if (i == 0 || j == 0)
                dp[flag][j] = 0;
            else if (s1[i - 1] == s2[j - 1])
                dp[flag][j] = dp[1 - flag][j - 1] + 1;
            else
                dp[flag][j] = dp[1 - flag][j] > dp[flag][j - 1] ? dp[1 - flag][j] : dp[flag][j - 1];
        }
    }
    return (l1 - dp[flag][l2]) + (l2 - dp[flag][l2]) <= k ? (l1 - dp[flag][l2]) + (l2 - dp[flag][l2]) : -1;
}

int main() {
    ios::sync_with_stdio(false);
    int n, m, k;
    cin >> n >> m >> k;
    char *s1 = new char[n];
    char *s2 = new char[m];
    cin >> s1 >> s2;
    cout << cost(s1, s2, n, m, k) << endl;
}
