#include <cstdint>
#include <cstdio>

const int MAX_N = 16777216;

struct bitset {
    uint64_t *bits;
    uint64_t size;

    explicit bitset(uint64_t cap) {
        bits = new uint64_t[cap / 64 + 1];
        size = 0;
    }

    void set(uint64_t i, bool v) {
        bits[i / 64] ^= (-v ^ bits[i / 64]) & (1UL << i % 64);
        size = i + 1 > size ? i + 1 : size;
    }

    bool get(uint64_t i) {
        return (bits[i / 64] >> i % 64) & 1U;
    }

    void succ() {
        bool carry = 1;
        for (uint64_t i = 0; carry != 0; i++) {
            bool tmp = get(i) & carry;
            set(i, get(i) ^ carry);
            carry = tmp;
        }
    }

    bool contains_reverse(bitset *b) {
        for (uint64_t i = 0; i <= size - b->size; i++) {
            for (int64_t j = 0; j < b->size; j++)
                if (get(i + j) != b->get(b->size - j - 1))
                    goto diff;
            return true;
            diff:;
        }
        return false;
    }

    void print_reverse() {
        for (uint64_t i = 0; i < size; i++) {
            printf("%d", get(size - i - 1));
        }
        printf("\n");
    }
};

int main() {
    int c;
    int n = 0;
    auto bs = new bitset(MAX_N);
    while (c = getchar(), c != '\n')
        bs->set(n++, c - '0');

    auto ts = new bitset(MAX_N);
    for (uint64_t len = 0;; len++) {
        for (uint64_t i = 0; i < len; i++)
            ts->set(i, 0);
        while (bs->contains_reverse(ts) && ts->size <= len)
            ts->succ();
        if(!bs->contains_reverse(ts)){
            ts->print_reverse();
            return 0;
        }
    }
}
