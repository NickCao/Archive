#include "temperature.h"
#include <cstdlib>
#include <tuple>

struct point_set {
    int n;
    const int *x, *y, *t;

    point_set(int n, const int *x, const int *y, const int *t) : n(n), x(x), y(y), t(t) {}

    std::pair<point_set *, point_set *> divide(bool direction) {
        std::tuple<int, int, int> points[n];
        for (int i = 0; i < n; i++)
            points[i] = std::make_tuple(x[i], y[i], t[i]);

        __compar_fn_t comp;
        if (direction) {
            comp = [](const void *a, const void *b) {
                return std::get<0>(*(std::tuple<int, int, int> *) a) -
                       std::get<0>(*(std::tuple<int, int, int> *) b);
            };
        } else {
            comp = [](const void *a, const void *b) {
                return std::get<1>(*(std::tuple<int, int, int> *) a) -
                       std::get<1>(*(std::tuple<int, int, int> *) b);
            };
        }
        qsort(points, n, sizeof(std::tuple<int, int, int>), comp);

        int *sx = new int[n];
        int *sy = new int[n];
        int *st = new int[n];
        for (int i = 0; i < n; i++)
            std::tie(sx[i], sy[i], st[i]) = points[i];

        auto p1 = new point_set(n / 2, sx, sy, st);
        auto p2 = new point_set(n - n / 2, sx + n / 2, sy + n / 2, st + n / 2);
        return std::make_pair(p1, p2);
    }
};

struct rectangle {
    int x1, y1;
    int x2, y2;
    int min, max;

    rectangle(int x1, int y1, int x2, int y2) : x1(x1), y1(y1), x2(x2), y2(y2), min(-1), max(-1) {};

    explicit rectangle(point_set *p) {
        if (p->n == 0)
            abort();

        for (int i = 0; i < p->n; i++) {
            if (i == 0) {
                max = min = p->t[0];
                x1 = x2 = p->x[0];
                y1 = y2 = p->y[0];
                continue;
            }

            max = p->t[i] > max ? p->t[i] : max;
            min = p->t[i] < min ? p->t[i] : min;
            x2 = p->x[i] > x2 ? p->x[i] : x2;
            y2 = p->y[i] > y2 ? p->y[i] : y2;
            x1 = p->x[i] < x1 ? p->x[i] : x1;
            y1 = p->y[i] < y1 ? p->y[i] : y1;
        }
    }

    bool intersect(rectangle *b) const {
        return !(x1 > b->x2 || b->x1 > x2 || y1 > b->y2 || b->y1 > y2);
    }

    bool in(rectangle *b) const {
        return x1 >= b->x1 && x2 <= b->x2 && y1 >= b->y1 && y2 <= b->y2;
    }
};

struct node {
    explicit node(point_set *p) : geom(rectangle(p)) {}

    rectangle geom;
    node *left{}, *right{};
};

node *buildKdTree(point_set *p, const int depth) {
    if (p->n == 0)
        return nullptr;

    node *r = new node(p);
    r->left = nullptr;
    r->right = nullptr;

    if (p->n == 1) {
        return r;
    }

    auto tup = p->divide(depth % 2 == 0);
    r->left = buildKdTree(tup.first, depth + 1);
    r->right = buildKdTree(tup.second, depth + 1);
    return r;
}

node *root;

void init(int n, const int *x, const int *y, const int *t) {
    root = buildKdTree(new point_set{n, x, y, t}, 0);
}

void bounded_traverse(node *r, rectangle *g, int *min, int *max) {
    if (r == nullptr)
        return;

    if (r->geom.in(g)) {
        if (*min == -1 && *max == -1) {
            *min = r->geom.min;
            *max = r->geom.max;
        } else {
            *min = r->geom.min < *min ? r->geom.min : *min;
            *max = r->geom.max > *max ? r->geom.max : *max;
        }
        return;
    }

    if (r->left->geom.in(g)) {
        if (*min == -1 && *max == -1) {
            *min = r->left->geom.min;
            *max = r->left->geom.max;
        } else {
            *min = r->left->geom.min < *min ? r->left->geom.min : *min;
            *max = r->left->geom.max > *max ? r->left->geom.max : *max;
        }
    } else if (r->left->geom.intersect(g)) {
        bounded_traverse(r->left, g, min, max);
    }

    if (r->right->geom.in(g)) {
        if (*min == -1 && *max == -1) {
            *min = r->right->geom.min;
            *max = r->right->geom.max;
        } else {
            *min = r->right->geom.min < *min ? r->right->geom.min : *min;
            *max = r->right->geom.max > *max ? r->right->geom.max : *max;
        }
    } else if (r->right->geom.intersect(g)) {
        bounded_traverse(r->right, g, min, max);
    }
}

void query(int x1, int x2, int y1, int y2, int *min, int *max) {
    *min = -1;
    *max = -1;
    bounded_traverse(root, new rectangle(x1, y1, x2, y2), min, max);
}
