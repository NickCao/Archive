#include <iostream>
#include <tuple>
#include <utility>

struct queue {

    struct node {
        std::tuple<int, int> data;
        node *next;

        explicit node(std::tuple<int, int> d) : data(std::move(d)), next(nullptr) {}
    };

    node *first, *last;

    queue() {
        first = last = nullptr;
    }

    void push(std::tuple<int, int> x) {
        node *temp = new node(x);
        if (last == nullptr) {
            first = last = temp;
            return;
        }
        last->next = temp;
        last = temp;
    }

    void pop() {
        if (first == nullptr)
            return;
        first = first->next;
        if (first == nullptr)
            last = nullptr;
    }

    std::tuple<int, int> front() {
        return first->data;
    }

    std::tuple<int, int> end() {
        return last->data;
    }

    bool empty() {
        return first == nullptr;
    }
};


int main() {
    std::iostream::sync_with_stdio(false);
    int n, m;
    std::cin >> n >> m;

    bool visited[n][m];
    int dist[n][m];
    queue q;
    for (int y = 0; y < n; y++) {
        for (int x = 0; x < m; x++) {
            visited[y][x] = false;
            char c;
            std::cin >> c;
            if (c == '0') {
                q.push(std::make_tuple(y, x));
                visited[y][x] = true;
                dist[y][x] = 0;
            }
        }
    }

    while (!q.empty()) {
        auto u = q.front();
        q.pop();
        int y = std::get<0>(u);
        int x = std::get<1>(u);
        if (y + 1 < n && !visited[y + 1][x]) {
            q.push(std::make_tuple(y + 1, x));
            visited[y + 1][x] = true;
            dist[y + 1][x] = dist[y][x] + 1;
        }
        if (y - 1 >= 0 && !visited[y - 1][x]) {
            q.push(std::make_tuple(y - 1, x));
            visited[y - 1][x] = true;
            dist[y - 1][x] = dist[y][x] + 1;
        }
        if (x + 1 < m && !visited[y][x + 1]) {
            q.push(std::make_tuple(y, x + 1));
            visited[y][x + 1] = true;
            dist[y][x + 1] = dist[y][x] + 1;
        }
        if (x - 1 >= 0 && !visited[y][x - 1]) {
            q.push(std::make_tuple(y, x - 1));
            visited[y][x - 1] = true;
            dist[y][x - 1] = dist[y][x] + 1;
        }
    }

    int time = 0;
    for (int y = 0; y < n; y++)
        for (int x = 0; x < m; x++)
            time += dist[y][x];
    std::cout << time << std::endl;
    return 0;
}
