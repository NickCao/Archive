#include<iostream>
#include<cstdio>

using namespace std;

// start: 快排板子，ref: https://oi-wiki.org/basic/quick-sort/
struct Range {
    int start, end;

    explicit Range(int s = 0, int e = 0) { start = s, end = e; }
};

template<typename T>
void quick_sort(T arr[], const int len) {
    if (len <= 0) return;
    Range r[len];
    int p = 0;
    r[p++] = Range(0, len - 1);
    while (p) {
        Range range = r[--p];
        if (range.start >= range.end) continue;
        T mid = arr[range.end];
        int left = range.start, right = range.end - 1;
        while (left < right) {
            while (arr[left] < mid && left < right) left++;
            while (arr[right] >= mid && left < right) right--;
            std::swap(arr[left], arr[right]);
        }
        if (arr[left] >= arr[range.end])
            std::swap(arr[left], arr[range.end]);
        else
            left++;
        r[p++] = Range(range.start, left - 1);
        r[p++] = Range(left + 1, range.end);
    }
}
// end: 快排板子

double xs[200001], ys[200001];

int main() {
    int n;
    scanf("%d", &n);
    for (int i = 1; i <= n; i++)
        scanf("%lf", &xs[i]);
    for (int i = 1; i <= n; i++)
        scanf("%lf", &ys[i]);
    quick_sort(xs + 1, n);
    quick_sort(ys + 1, n);

    int m;
    scanf("%d", &m);
    for (int i = 0; i < m; i++) {
        int x, y;
        scanf("%d%d", &x, &y);
        // 二分查找
        int left = 0;
        int right = n;
        int curr = 0;
        while (left <= right) {
            int middle = (left + right) >> 1;
            // ToLeft测试
            if (xs[middle] * ys[middle] - ys[middle] * x - y * xs[middle] > 0) {
                right = middle - 1;
            } else {
                curr = middle;
                left = middle + 1;
            }
        }
        printf("%d\n", curr);
    }
}