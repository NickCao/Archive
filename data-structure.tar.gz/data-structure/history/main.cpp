#include <iostream>

enum color_t {
    RED, BLACK, NO
};

struct node_t {
    unsigned key{};
    unsigned value{};
    node_t *left = nullptr;
    node_t *right = nullptr;
    node_t *parent = nullptr;
    color_t color = NO;
};

class rbtree_t {
    node_t *root;

public:
    rbtree_t() : root(nullptr) {}

    void insert(unsigned key, unsigned value) {
        if (root == nullptr) {
            root = new node_t();
            root->key = key;
            root->value = value;
            root->parent = nullptr;
            root->color = BLACK;
        } else {
            auto linker = root;
            auto *new_node = new node_t();
            new_node->key = key;
            new_node->value = value;

            while (linker != nullptr) {
                if (linker->key > key) {
                    if (linker->left == nullptr) {
                        linker->left = new_node;
                        new_node->color = RED;
                        new_node->parent = linker;
                        break;
                    } else { linker = linker->left; }
                } else {
                    if (linker->right == nullptr) {
                        linker->right = new_node;
                        new_node->parent = linker;
                        break;
                    } else { linker = linker->right; }
                }
            }
            node_t *z = new_node;
            while (z->parent->color == RED) {
                auto grandparent = z->parent->parent;
                auto uncle = root;
                if (z->parent == grandparent->left) {
                    if (grandparent->right) { uncle = grandparent->right; }
                    if (uncle->color == RED) {
                        z->parent->color = BLACK;
                        uncle->color = BLACK;
                        grandparent->color = RED;
                        if (grandparent->key != root->key) { z = grandparent; }
                        else { break; }
                    } else if (z == grandparent->left->right) {
                        l_rotate(z->parent);
                    } else {
                        z->parent->color = BLACK;
                        grandparent->color = RED;
                        r_rotate(grandparent);
                        if (grandparent->key != root->key) { z = grandparent; }
                        else { break; }
                    }
                } else {
                    if (grandparent->left) { uncle = grandparent->left; }
                    if (uncle->color == RED) {
                        z->parent->color = BLACK;
                        uncle->color = BLACK;
                        grandparent->color = RED;
                        if (grandparent->key != root->key) { z = grandparent; }
                        else { break; }
                    } else if (z == grandparent->right->left) {
                        r_rotate(z->parent);
                    } else {
                        z->parent->color = BLACK;
                        grandparent->color = RED;
                        l_rotate(grandparent);
                        if (grandparent->key != root->key) { z = grandparent; }
                        else { break; }
                    }
                }
            }
            root->color = BLACK;
        }
    }

    node_t *search(unsigned key) {
        auto temp = root;
        if (temp == nullptr) { return nullptr; }

        while (temp) {
            if (key == temp->key) { return temp; }
            else if (key < temp->key) { temp = temp->left; }
            else { temp = temp->right; }
        }
        return nullptr;
    }

    static void l_rotate(node_t *x) {
        auto *nw_node = new node_t();
        if (x->right->left) { nw_node->right = x->right->left; }
        nw_node->left = x->left;
        nw_node->key = x->key;
        nw_node->value = x->value;
        nw_node->color = x->color;
        x->key = x->right->key;
        x->value = x->right->value;

        x->left = nw_node;
        if (nw_node->left) { nw_node->left->parent = nw_node; }
        if (nw_node->right) { nw_node->right->parent = nw_node; }
        nw_node->parent = x;

        if (x->right->right) { x->right = x->right->right; }
        else { x->right = nullptr; }

        if (x->right) { x->right->parent = x; }
    }

    static void r_rotate(node_t *x) {
        auto *nw_node = new node_t();
        if (x->left->right) { nw_node->left = x->left->right; }
        nw_node->right = x->right;
        nw_node->key = x->key;
        nw_node->value = x->value;
        nw_node->color = x->color;

        x->key = x->left->key;
        x->value = x->left->value;
        x->color = x->left->color;

        x->right = nw_node;
        if (nw_node->left) { nw_node->left->parent = nw_node; }
        if (nw_node->right) { nw_node->right->parent = nw_node; }
        nw_node->parent = x;

        if (x->left->left) { x->left = x->left->left; }
        else { x->left = nullptr; }

        if (x->left) { x->left->parent = x; }
    }
};


int main() {
    rbtree_t tree;
    unsigned n;
    scanf("%u", &n);

    unsigned ans = 0;
    for (int i = 0; i < n; i++) {
        unsigned id;
        scanf("%u", &id);
        id ^= ans;

        auto res = tree.search(id);
        if (res == nullptr) {
            ans = i + 1;
            tree.insert(id, i);
        } else {
            ans = res->value + 1;
            res->value = i;
        }
        printf("%u\n", ans);
    }
}
