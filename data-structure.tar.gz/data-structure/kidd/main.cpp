#include <string>
#include <iostream>

using namespace std;

typedef long long ll;

struct node {
    int s, e;
    ll sum, add_v;
    node *l, *r;

    node(int _s, int _e) : s(_s), e(_e), sum(0), add_v(0), l(nullptr), r(nullptr) {}

    ~node() {
        delete l;
        delete r;
    }

    void lp() {
        if (s == e || add_v == 0) return;
        l->add_v += add_v;
        l->sum += add_v * (l->e - l->s + 1);
        r->add_v += add_v;
        r->sum += add_v * (r->e - r->s + 1);
        add_v = 0;
    }

    void range_add(int x, int y, ll v) {
        if (s == x && e == y) {
            add_v += v;
            sum += v * (e - s + 1);
            return;
        }

        int m = (s + e) >> 1;
        if (s != e && l == nullptr) {
            l = new node(s, m);
            r = new node(m + 1, e);
        }

        lp();
        if (x <= m) l->range_add(x, min(y, m), v);
        if (y > m) r->range_add(max(x, m + 1), y, v);
        if (l == nullptr) return;
        sum = l->sum + r->sum;
    }

    ll range_sum(int x, int y) {
        if (s == x && e == y) return sum;
        if (l == nullptr) return (sum / (e - s + 1)) * (y - x + 1);
        int m = (s + e) >> 1;
        lp();
        if (y <= m) return l->range_sum(x, y);
        if (x > m) return r->range_sum(x, y);
        return l->range_sum(x, m) + r->range_sum(m + 1, y);
    }
};

int main() {
    int n, m;
    cin >> n >> m;

    auto root = new node(0, n - 1);

    for (int x = 0; x < m; x++) {
        char op;
        int i, j;
        cin >> op >> i >> j;
        switch (op) {
            case 'H':
                root->range_add(i - 1, j - 1, 1);
                break;
            case 'Q':
                cout << root->range_sum(i - 1, j - 1) << endl;
                break;
            default:
                break;
        }
    }

    return 0;
}