#include "crc32.h"
#include <string>
#include <cmath>
#include <cstring>

struct avl {
    z_crc_t key;
    int value;
    struct avl *left;
    struct avl *right;
} *r;

class avl_tree {
public:
    int height(avl *);

    int difference(avl *);

    avl *rr_rotat(avl *);

    avl *ll_rotat(avl *);

    avl *lr_rotat(avl *);

    avl *rl_rotat(avl *);

    avl *balance(avl *);

    avl *insert(avl *, int);

    void show(avl *, int);

    avl_tree() {
        r = nullptr;
    }
};

int avl_tree::height(avl *t) {
    int h = 0;
    if (t != nullptr) {
        int l_height = height(t->left);
        int r_height = height(t->right);
        int max_height = l_height > r_height ? l_height : r_height;
        h = max_height + 1;
    }
    return h;
}

int avl_tree::difference(avl *t) {
    int l_height = height(t->left);
    int r_height = height(t->right);
    int b_factor = l_height - r_height;
    return b_factor;
}

avl *avl_tree::rr_rotat(avl *parent) {
    avl *t;
    t = parent->right;
    parent->right = t->left;
    t->left = parent;
    return t;
}

avl *avl_tree::ll_rotat(avl *parent) {
    avl *t;
    t = parent->left;
    parent->left = t->right;
    t->right = parent;
    return t;
}

avl *avl_tree::lr_rotat(avl *parent) {
    avl *t;
    t = parent->left;
    parent->left = rr_rotat(t);
    return ll_rotat(parent);
}

avl *avl_tree::rl_rotat(avl *parent) {
    avl *t;
    t = parent->right;
    parent->right = ll_rotat(t);
    return rr_rotat(parent);
}

avl *avl_tree::balance(avl *t) {
    int bal_factor = difference(t);
    if (bal_factor > 1) {
        if (difference(t->left) > 0)
            t = ll_rotat(t);
        else
            t = lr_rotat(t);
    } else if (bal_factor < -1) {
        if (difference(t->right) > 0)
            t = rl_rotat(t);
        else
            t = rr_rotat(t);
    }
    return t;
}

avl *avl_tree::insert(avl *r, int v) {
    if (r == NULL) {
        r = new avl;
        r->key = v;
        r->left = NULL;
        r->right = NULL;
        return r;
    } else if (v < r->key) {
        r->left = insert(r->left, v);
        r = balance(r);
    } else if (v >= r->key) {
        r->right = insert(r->right, v);
        r = balance(r);
    }
    return r;
}

void avl_tree::show(avl *p, int l) {
    int i;
    if (p != NULL) {
        show(p->right, l + 1);
        cout << " ";
        if (p == r)
            cout << "Root -> ";
        for (i = 0; i < l && p != r; i++)
            cout << " ";
        cout << p->key;
        show(p->left, l + 1);
    }
}


const int max_s = pow(18, 5);

void gen_string(int n, unsigned char *buf, int *len);

int main() {
    int n;
    scanf("%d", &n);

    auto salt = new unsigned char[4];
    scanf("%s", (char *) salt);
    auto len_salt = strlen((char *) (salt));

    auto hashes = new z_crc_t[n];
    for (int i = 0; i < n; i++) {
        scanf("%x", &hashes[i]);
    }

    rbtree table;
    auto buf = new unsigned char[5];
    for (int i = 0; i < max_s; i++) {
        int len = 0;
        gen_string(i, buf, &len);
        z_crc_t h = crc32(crc32(0, buf, len), salt, len_salt);
        auto p = table.TreeSearch(h);
        if (p != nullptr) {
            p->value = -1;
        } else {
            table.InsertNode(h, i);
        }
    }
    return 0;

    for (int i = 0; i < n; i++) {
        auto it = table.TreeSearch(hashes[i]);
        if (it == nullptr) {
            printf("No\n");
            continue;
        }
        int len = 0;
        gen_string(it->value, buf, &len);
        printf("%s\n", (char *) buf);
    }
}


const unsigned char char_set[] = "0123456789tsinghua";

void gen_string(int n, unsigned char *buf, int *len) {
    if (n == -1) {
        strcpy((char *) buf, "Duplicate");
        return;
    }
    buf[*len] = char_set[n % 18];
    *len += 1;
    int next = n / 18;
    if (next != 0) {
        gen_string(next, buf, len);
    } else {
        buf[*len] = '\0';
    }
}

