#include <cstring>
#include <cstdio>

const int MAX_N = 2e7;
char str[MAX_N];
int next[MAX_N];
int count[MAX_N];

int main() {
    scanf("%s", str);
    int n = strlen(str);

    for (int i = 1; i < n; i++) {
        int j = next[i - 1];
        while (j && str[i] != str[j])
            j = next[j - 1];
        if (str[i] == str[j])
            j++;
        next[i] = j;
    }

    for (int i = 0; i < n; i++)
        count[next[i]]++;

    for (int i = n - 1; i > 0; i--)
        count[next[i - 1]] += count[i];

    long long sum = 0;
    for (int i = 0; i < n; i++)
        sum += count[i];

    printf("%lld\n", sum);
}
