from modules.data import Database
l_db = Database()
import time

def stop(update, context):
    id = update.message.from_user.id
    chat_id = update.message.chat_id
    message_id = update.message.message_id
    info = l_db.get_account_info(id)
    if info == None:
        context.bot.send_message(chat_id=chat_id,reply_to_message_id=message_id, text="你还没法退学呢....")
        return
    l_db.r.delete("account_info:"+str(id))
    context.bot.send_message(chat_id=chat_id,reply_to_message_id=message_id, text="您退学了!")