from modules.data import Database,parse_int
l_db = Database()

def level(update, context):
    id = update.message.from_user.id
    chat_id = update.message.chat_id
    message_id = update.message.message_id
    info = l_db.get_account_info(id)

    if info == None:
        context.bot.send_message(chat_id=chat_id,reply_to_message_id=message_id,text="你还没有帐号呢，快点/start@tunatoken_bot")
        return

    if len(context.args) == 0:
        context.bot.send_message(chat_id=chat_id,reply_to_message_id=message_id,text="你的level是"+str(int(info[b"level"]))+"呢")
    elif len(context.args) == 1:
        dinfo = l_db.username2info(context.args[0])
        if dinfo == None:
            context.bot.send_message(chat_id=chat_id,reply_to_message_id=message_id,text="我不认识"+context.args[0]+"呢")
            return
        context.bot.send_message(chat_id=chat_id,reply_to_message_id=message_id,text=context.args[0]+"的level是"+str(int(dinfo[b"level"]))+"呢")
    elif len(context.args) == 2:
        if int(info[b"level"]) < 10:
            context.bot.send_message(chat_id=chat_id,reply_to_message_id=message_id,text="你没有权限改别人的level呢")
        else:
            dinfo = l_db.username2info(context.args[0])
            if dinfo == None:
                context.bot.send_message(chat_id=chat_id,reply_to_message_id=message_id,text="我不认识"+context.args[0]+"呢")
                return
            newlevel = parse_int(context.args[1])
            if newlevel == None:
                context.bot.send_message(chat_id=chat_id, reply_to_message_id=message_id, text="level要是整数哦")
                return

            dinfo[b"level"] = str(newlevel)
            l_db.set_account_info(str(int(l_db.get_username2id(context.args[0]))),dinfo)

            context.bot.send_message(chat_id=chat_id,reply_to_message_id=message_id,text=context.args[0]+"的新level是"+str(newlevel))
    else:
        context.bot.send_message(chat_id=chat_id, reply_to_message_id=message_id, text="参数数量不对啦！试试/level，或者/level 用户名 新level")