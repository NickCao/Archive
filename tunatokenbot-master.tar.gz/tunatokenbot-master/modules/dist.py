import uuid,random
from telegram import InlineKeyboardMarkup, InlineKeyboardButton
from modules.data import Database,parse_int
l_db = Database()

def dist(update, context):
    username = update.message.from_user.username
    id = update.message.from_user.id
    chat_id = update.message.chat_id
    message_id = update.message.message_id

    info = l_db.get_account_info(id)
    if info == None:
        context.bot.send_message(chat_id=chat_id,reply_to_message_id=message_id,text="你还没有帐号呢，快点/start@tunatoken_bot")
        return

    if len(context.args) != 2:
        context.bot.send_message(chat_id=chat_id, reply_to_message_id=message_id, text="参数数量不对啦！试试/dist 钱数 个数")
        return

    amount = parse_int(context.args[0])
    parts = parse_int(context.args[1])

    if amount == None or parts == None:
        context.bot.send_message(chat_id=chat_id, reply_to_message_id=message_id, text="参数都要是整数哦")
        return 

    if amount > int(info[b"balance"]):
        context.bot.send_message(chat_id=chat_id, reply_to_message_id=message_id, text="您没这么多钱呢！（只剩"+str(int(info[b"balance"]))+"了呢")
        return

    if parts <= 0:
        context.bot.send_message(chat_id=chat_id, reply_to_message_id=message_id, text="pia！这叫我怎么分！")
        return

    if amount < 0 and int(info[b"level"]) < 5:
        context.bot.send_message(chat_id=chat_id, reply_to_message_id=message_id, text="pia！好孩子不要这样做哦！")
        return    

    dist_id = str(uuid.uuid4().int)
    dist_info = {"amount":amount,"parts":parts,"from": username}
    l_db.set_dist_info(dist_id,dist_info)

    info[b"balance"] = int(info[b"balance"])-amount
    l_db.set_account_info(id, info)

    reply_markup = InlineKeyboardMarkup([[InlineKeyboardButton(text=context.args[0]+" tokens in "+context.args[1]+" parts",callback_data="dist:"+dist_id)]])
    context.bot.send_message(chat_id=chat_id,text=username+"的红包",reply_markup=reply_markup)

def dist_callback(update, context):
    id = update.callback_query.from_user.id
    info = l_db.get_account_info(id)

    if info == None:
        context.bot.answer_callback_query(update.callback_query.id, text="你还没有帐号呢，快点/start@tunatoken_bot")
        return

    dist_id = str(update.callback_query.data.split(":")[1])
    dist_info = l_db.get_dist_info(dist_id)
    
    if dist_info == None or int(dist_info[b"parts"]) <= 0 or int(dist_info[b"amount"]) <= 0:
        l_db.r.delete("dist_info:"+dist_id)
        context.bot.answer_callback_query(update.callback_query.id, text="这个红包没了呢")
        update.callback_query.edit_message_text(dist_info[b"from"].decode("utf-8")+"的红包退学了")
        return
    
    amount = 0
    if int(dist_info[b"parts"]) > 1:
        amount = random.randint(0, int(dist_info[b"amount"]))
    else:
        amount = int(dist_info[b"amount"])
    dist_info[b"amount"] = int(dist_info[b"amount"]) - amount
    dist_info[b"parts"] = int(dist_info[b"parts"]) - 1
    l_db.set_dist_info(dist_id,dist_info)

    info[b"balance"] = int(info[b"balance"]) + amount
    l_db.set_account_info(id, info)
    context.bot.answer_callback_query(update.callback_query.id, text="你抢到了"+str(amount)+"个token")

    if int(dist_info[b"parts"]) >= 1:
        reply_markup = InlineKeyboardMarkup([[InlineKeyboardButton(text=str(int(dist_info[b"amount"]))+" tokens in "+str(int(dist_info[b"parts"]))+" parts",callback_data="dist:"+dist_id)]])
        update.callback_query.edit_message_reply_markup(reply_markup)
    else:
        l_db.r.delete("dist_info:"+dist_id)
        update.callback_query.edit_message_text(dist_info[b"from"].decode("utf-8")+"的红包退学了")