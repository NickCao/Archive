import random,time
from modules.data import Database
l_db = Database()


def lottery(update, context):
    username = update.message.from_user.username
    id = update.message.from_user.id
    chat_id = update.message.chat_id
    message_id = update.message.message_id
    info = l_db.get_account_info(id)   
    if info == None:
        context.bot.send_message(chat_id=chat_id,reply_to_message_id=message_id,text="你还没有帐号呢，快点/start@tunatoken_bot")
        return

    if time.time() - float(info[b"last_lottery"]) < 30 and int(info[b"level"]) < 5:
        context.bot.send_message(chat_id=chat_id,reply_to_message_id=message_id,text="你不是刚来过吗！不要心急啦....")
        return

    b = random.randint(1,60)*random.choice([-1,10])
    info[b"balance"] = int(info[b"balance"]) + b
    info[b"last_lottery"] = time.time()
    l_db.set_account_info(id, info)
    if b > 0:
        context.bot.send_message(chat_id=chat_id, reply_to_message_id=message_id, text="你得到了"+str(b)+"个token")
    else:
        context.bot.send_message(chat_id=chat_id, reply_to_message_id=message_id, text="你血亏了"+str(abs(b))+"个token")