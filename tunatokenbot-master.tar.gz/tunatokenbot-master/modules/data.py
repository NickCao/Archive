import redis
class Database:
    def __init__(self):
        self.r = redis.Redis(host='localhost', port=6379, db=0)
    def get_account_info(self, userid):
        if not self.r.exists("account_info:"+str(userid)):
            return None
        return self.r.hgetall("account_info:"+str(userid))
    def set_account_info(self, userid, info):
        self.r.hmset("account_info:"+str(userid), info)
    def get_username2id(self, username):
        if not self.r.hexists("username2id", str(username)):
            return None
        return str(int(self.r.hget("username2id", str(username))))
    def set_username2id(self, username, id):
        self.r.hset("username2id", str(username), str(id))
    def username2info(self, username):
        id = self.get_username2id(str(username))
        if id == None:
            return None
        return self.get_account_info(id)
    def get_dist_info(self, dist_id):
        if not self.r.exists("dist_info:"+str(dist_id)):
            return None
        return self.r.hgetall("dist_info:"+str(dist_id))
    def set_dist_info(self, dist_id, info):
        self.r.hmset("dist_info:"+str(dist_id), info)

def parse_int(value):
    try:
        return int(value)
    except ValueError:
        return None