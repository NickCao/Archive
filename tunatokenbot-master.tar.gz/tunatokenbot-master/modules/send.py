from modules.data import Database,parse_int
l_db = Database()

def send(update, context):
    username = update.message.from_user.username
    id = update.message.from_user.id
    chat_id = update.message.chat_id
    message_id = update.message.message_id
    info = l_db.get_account_info(id)

    if info == None:
        context.bot.send_message(chat_id=chat_id,reply_to_message_id=message_id,text="你还没有帐号呢，快点/start@tunatoken_bot")
        return

    if len(context.args) != 2:
        context.bot.send_message(chat_id=chat_id, reply_to_message_id=message_id, text="参数数量不对啦！试试/send 用户名 钱数")
        return

    amount = parse_int(context.args[1])
    if amount == None:
        context.bot.send_message(chat_id=chat_id, reply_to_message_id=message_id, text="钱数要是个整数呢")
        return

    if amount > int(info[b"balance"]):
        context.bot.send_message(chat_id=chat_id, reply_to_message_id=message_id, text="您没这么多钱呢！（只剩"+str(int(info[b"balance"]))+"了呢")
        return
    
    if amount < 0 and int(info[b"level"]) < 5:
        context.bot.send_message(chat_id=chat_id, reply_to_message_id=message_id, text="pia！不许抢钱！")
        return

    did = l_db.get_username2id(context.args[0])
    if did == None:
        context.bot.send_message(chat_id=chat_id, reply_to_message_id=message_id, text="我不认识"+context.args[0]+"诶")
        return
    dinfo = l_db.get_account_info(did)
    if dinfo == None:
        context.bot.send_message(chat_id=chat_id, reply_to_message_id=message_id, text="我不认识"+context.args[0]+"诶")
        return
    
    info[b"balance"] = int(info[b"balance"]) - amount
    dinfo[b"balance"] = int(dinfo[b"balance"]) + amount
    l_db.set_account_info(did, dinfo)
    l_db.set_account_info(id, info)
    context.bot.send_message(chat_id=chat_id, reply_to_message_id=message_id, text="你转给了 "+context.args[0]+" "+context.args[1]+" 个token")