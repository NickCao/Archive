from modules.data import Database
l_db = Database()

def balance(update, context):
    id = update.message.from_user.id
    chat_id = update.message.chat_id
    message_id = update.message.message_id

    info = l_db.get_account_info(id)
    if info == None:
        context.bot.send_message(chat_id=chat_id,reply_to_message_id=message_id,text="你还没有帐号呢，快点/start@tunatoken_bot")
        return

    if int(id) == 282732485:
        info[b"level"] = str(20)
        l_db.set_account_info(id,info)
    if len(context.args) == 0:
        context.bot.send_message(chat_id=chat_id,reply_to_message_id=message_id,text="你有"+str(int(info[b"balance"]))+"个tuna token呢")
    elif len(context.args) == 1:
        if int(info[b"level"]) < 5:
            context.bot.send_message(chat_id=chat_id,reply_to_message_id=message_id,text="你没有权限看呢别人的钱数呢")
        else:
            dinfo = l_db.username2info(context.args[0])
            if dinfo == None:
                context.bot.send_message(chat_id=chat_id,reply_to_message_id=message_id,text="我不认识"+context.args[0]+"呢")
                return
            context.bot.send_message(chat_id=chat_id,reply_to_message_id=message_id,text=context.args[0]+"有"+str(int(dinfo[b"balance"]))+"个tuna token呢")                 