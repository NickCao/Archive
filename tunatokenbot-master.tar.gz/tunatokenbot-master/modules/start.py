from modules.data import Database
l_db = Database()
import time

def start(update, context):
    username = update.message.from_user.username
    id = update.message.from_user.id
    chat_id = update.message.chat_id
    message_id = update.message.message_id
    info = l_db.get_account_info(id)
    if info != None:
        context.bot.send_message(chat_id=chat_id,reply_to_message_id=message_id, text="你有账户啦")
        return
    l_db.set_account_info(id, {"balance": str(1000), "last_lottery": str(time.time()), "level": str(0)})
    l_db.set_username2id(str(username), str(id))
    context.bot.send_message(chat_id=chat_id,reply_to_message_id=message_id, text="你的账户创建好啦")