#!/bin/python

from modules.dist import dist,dist_callback
from modules.balance import balance
from modules.lottery import lottery
from modules.start import start
from modules.level import level
from modules.send import send
from modules.stop import stop
from telegram.ext import Updater
from telegram.ext import CallbackQueryHandler
from telegram.ext import CommandHandler
import logging

def main():
    logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',level=logging.INFO)
    logger = logging.getLogger(__name__)
    updater = Updater(token='847932064:AAEk1BQOjCFQoSmB_9mJzuRQUUxEvpi1N6E', use_context=True)
    dispatcher = updater.dispatcher

    dist_callback_handler = CallbackQueryHandler(dist_callback)
    balance_handler = CommandHandler('balance', balance)
    dist_handler = CommandHandler('dist', dist)
    send_handler = CommandHandler('send', send)
    lottery_handler = CommandHandler('lottery', lottery)
    start_handler = CommandHandler('start', start)
    level_handler = CommandHandler('level', level)
    stop_handler = CommandHandler('stop', stop)

    dispatcher.add_handler(dist_callback_handler)
    dispatcher.add_handler(balance_handler)
    dispatcher.add_handler(dist_handler)
    dispatcher.add_handler(send_handler)
    dispatcher.add_handler(lottery_handler)
    dispatcher.add_handler(start_handler)
    dispatcher.add_handler(level_handler)
    dispatcher.add_handler(stop_handler)
    updater.start_polling()


if __name__ == "__main__":
    main()