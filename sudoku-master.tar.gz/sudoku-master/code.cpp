#pragma comment(linker, "/STACK:1073741824")
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>

using namespace std;

// Generator Start
bool rc[10][10], cc[10][10], bc[10][10];

int bl(int x, int y)
{
    return ((x - 1) / 3) * 3 + (y - 1) / 3;
}

int getone_form(int p[][10], int x, int y)
{
    //cout<<x<<" "<<y<<endl;
    if (x == 10 && y == 1)
    {
        return 1;
    }
    int block = bl(x, y), cnt = 0;
    for (int q, i = 1; i < 40; i++)
    {
        q = rand() % 9 + 1;
        if (!rc[x][q] && !cc[y][q] && !bc[block][q])
        {
            p[x][y] = q;
            rc[x][q] = 1;
            cc[y][q] = 1;
            bc[block][q] = 1;
            cnt += getone_form(p, x + y / 9, y % 9 + 1);
            if (cnt)
            {
                return 1;
            }
            rc[x][q] = 0;
            cc[y][q] = 0;
            bc[block][q] = 0;
        }
    }
    p[x][y] = 0;
    return cnt;
}

int getone_answer(int p[][10], int x, int y)
{
    int cnt = 0;
    if (x == 10 && y == 1)
    {
        return 1;
    }
    if (p[x][y])
    {
        return getone_answer(p, x + (y / 9), y % 9 + 1);
    }
    else
    {
        int block = bl(x, y);
        for (int q = 1; q <= 9; q++)
        {
            if (!rc[x][q] && !cc[y][q] && !bc[block][q])
            {
                p[x][y] = q;
                rc[x][q] = 1;
                cc[y][q] = 1;
                bc[block][q] = 1;
                cnt += getone_answer(p, x + (y / 9), y % 9 + 1);
                rc[x][q] = 0;
                cc[y][q] = 0;
                bc[block][q] = 0;
            }
        }
        p[x][y] = 0;
        return cnt;
    }
}

void pre()
{
    memset(rc, 0, sizeof(rc));
    memset(cc, 0, sizeof(cc));
    memset(bc, 0, sizeof(bc));
}

void form_soduko()
{
    srand(time(0) * time(0) - 0x5e2d6aa * rand() + time(0) * 338339);
    pre();
    int ini[10][10];
    memset(ini, 0, sizeof(ini));
    int opr[10][10];
    getone_form(ini, 1, 1);
    /*for(int i=1;i<=9;i++)
	{
	  for(int j=1;j<=9;j++)
	    cout<<ini[i][j]<<" ";
	  cout<<endl;
    }*/
    int met;
    do
    {
        memcpy(opr, ini, sizeof(ini));
        int sum = 45;
        while (sum)
        {
            int x = rand() % 9 + 1, y = rand() % 9 + 1;
            if (opr[x][y])
            {
                sum--;
                opr[x][y] = 0;
            }
        }
        pre();
        for (int x = 1; x <= 9; x++)
            for (int y = 1; y <= 9; y++)
                if (opr[x][y])
                {
                    rc[x][opr[x][y]] = 1;
                    cc[y][opr[x][y]] = 1;
                    bc[bl(x, y)][opr[x][y]] = 1;
                }
        met = getone_answer(opr, 1, 1);
    } while (met != 1);
    for (int i = 1; i <= 9; i++)
    {
        for (int j = 1; j <= 9; j++)
            cout << opr[i][j] << " ";
        cout << endl;
    }
}
// Generator End

//Solver Start
struct Cell
{
    Cell *left;
    Cell *right;
    Cell *up;
    Cell *down;
    Cell *head;
    int cell_id[3];
    int size;
};

//global variable for storing the state
int tmp_store[9][9];
int solution_count = 0;
std::string solution_string[2];
auto RootCell = new Cell;
Cell *solution[10000];
Cell *original[10000];
bool constraints[9 * 9 * 9][9 * 9 * 4] = {{0}};

void reset()
{
    solution_count = 0;
    solution_string[0] = "";
    solution_string[1] = "";
    RootCell = new Cell;
    for (int i = 0; i < 10000; i++)
    {
        solution[i] = NULL;
        original[i] = NULL;
    }
}

void hide_col(Cell *col_head)
{
    //Hide the col_head itself
    col_head->left->right = col_head->right;
    col_head->right->left = col_head->left;
    //Hide the cells under it
    for (auto cell = col_head->down; cell != col_head; cell = cell->down)
    {
        for (auto tmp = cell->right; tmp != cell; tmp = tmp->right)
        {
            tmp->down->up = tmp->up;
            tmp->up->down = tmp->down;
            tmp->head->size--;
        }
    }
}

void unhide_col(Cell *col_head)
{
    //We do it in the reverse order to not disturb the sequence
    for (auto cell = col_head->up; cell != col_head; cell = cell->up)
    {
        for (auto tmp = cell->left; tmp != cell; tmp = tmp->left)
        {
            tmp->head->size++;
            tmp->down->up = tmp;
            tmp->up->down = tmp;
        }
    }
    col_head->left->right = col_head;
    col_head->right->left = col_head;
}

void print_answer(int answer[9][9])
{
    for (int i = 0; i < 9; i++)
    {
        for (int j = 0; j < 9; j++)
        {
            solution_string[solution_count] += char(answer[i][j] + '0');
            if (j != 8)
            {
                solution_string[solution_count] += ' ';
            }
        }
        solution_string[solution_count] += "\n";
    }
}

void set_answer(int answer[9][9])
{

    for (int i = 0; solution[i] != NULL; i++)
    {
        answer[solution[i]->cell_id[1] - 1][solution[i]->cell_id[2] - 1] = solution[i]->cell_id[0];
    }
    for (int i = 0; original[i] != NULL; i++)
    {
        answer[original[i]->cell_id[1] - 1][original[i]->cell_id[2] - 1] = original[i]->cell_id[0];
    }
}

void copy_a(int answer[9][9])
{
    for (int i = 0; i < 9; i++)
    {
        for (int j = 0; j < 9; j++)
        {
            tmp_store[i][j] = answer[i][j];
        }
    }
}

void search_for_solution(int gen)
{

    if (RootCell->right == RootCell)
    {
        int answer[9][9];
        set_answer(answer);
        print_answer(answer);
        copy_a(answer);
        solution_count++;
        return;
    }

    if (solution_count >= 2)
    {
        return;
    }

    //Find the col with the smallest number of crossing rows and hide it
    auto col_head = RootCell->right;
    for (auto tmp = col_head->right; tmp != RootCell; tmp = tmp->right)
    {
        if ((tmp->size) < (col_head->size))
        {
            col_head = tmp;
        }
    }
    hide_col(col_head);

    for (auto tmp = col_head->down; tmp != col_head; tmp = tmp->down)
    {
        //Also hide the crossing rows and cols
        solution[gen] = tmp;
        for (auto cell = tmp->right; cell != tmp; cell = cell->right)
        {
            hide_col(cell->head);
        }

        search_for_solution(gen + 1);

        //Still the reverse order
        tmp = solution[gen];
        solution[gen] = NULL;
        col_head = tmp->head;
        for (auto cell = tmp->left; cell != tmp; cell = cell->left)
        {
            unhide_col(cell->head);
        }
    }

    unhide_col(col_head);
}

void init_constraints(bool constraints[9 * 9 * 9][9 * 9 * 4])
{
    //Constraint 1: one number a cell
    int j = 0, counter = 0;
    for (int i = 0; i < 9 * 9 * 9; i++)
    {
        constraints[i][j] = 1;
        counter++;
        if (counter >= 9)
        {
            j++;
            counter = 0;
        }
    }

    //Constraint 2: one number a row
    int x = 0;
    counter = 1;
    for (j = 9 * 9; j < 2 * 9 * 9; j++)
    {
        for (int i = x; i < counter * 9 * 9; i += 9)
            constraints[i][j] = 1;

        if ((j + 1) % 9 == 0)
        {
            x = counter * 9 * 9;
            counter++;
        }
        else
            x++;
    }

    //Constraint 3: one number a col
    j = 2 * 9 * 9;
    for (int i = 0; i < 9 * 9 * 9; i++)
    {
        constraints[i][j] = 1;
        j++;
        if (j >= 3 * 9 * 9)
            j = 2 * 9 * 9;
    }

    //Constraint 4: one number a square
    x = 0;
    for (j = 3 * 9 * 9; j < 4 * 9 * 9; j++)
    {

        for (int l = 0; l < 3; l++)
        {
            for (int k = 0; k < 3; k++)
                constraints[x + l * 9 + k * 9 * 9][j] = 1;
        }

        int temp = j + 1 - 3 * 9 * 9;

        if (temp % (3 * 9) == 0)
            x += (3 - 1) * 9 * 9 + (3 - 1) * 9 + 1;
        else if (temp % 9 == 0)
            x += 9 * (3 - 1) + 1;
        else
            x++;
    }
}

void init_dancing_links(bool constraints[9 * 9 * 9][9 * 9 * 4])
{

    auto root = new Cell;
    root->left = root;
    root->right = root;
    root->down = root;
    root->up = root;
    root->size = -1;
    root->head = root;

    auto tmp = root;

    //Init the col heads
    for (int i = 0; i < 9 * 9 * 4; i++)
    {
        auto new_cell = new Cell;
        new_cell->up = new_cell;
        new_cell->down = new_cell;
        new_cell->head = new_cell;
        new_cell->right = root;
        new_cell->left = tmp;
        new_cell->size = 0;
        tmp->right = new_cell;
        tmp = new_cell;
    }
    int inititial_cell_id[3] = {0, 1, 1};
    for (int i = 0; i < 9 * 9 * 9; i++)
    {
        auto col_head = root->right;
        Cell *prev = NULL;

        if (i != 0 && i % 81 == 0)
        {
            inititial_cell_id[0] -= 8;
            inititial_cell_id[1] += 1;
            inititial_cell_id[2] -= 8;
        }
        else if (i != 0 && i % 9 == 0)
        {
            inititial_cell_id[0] -= 8;
            inititial_cell_id[2] += 1;
        }
        else
        {
            inititial_cell_id[0] += 1;
        }

        for (int j = 0; j < 9 * 9 * 4; j++, col_head = col_head->right)
        {
            //for all the constrained joints
            if (constraints[i][j])
            {
                auto new_cell = new Cell;
                new_cell->cell_id[0] = inititial_cell_id[0];
                new_cell->cell_id[1] = inititial_cell_id[1];
                new_cell->cell_id[2] = inititial_cell_id[2];
                if (prev == NULL)
                {
                    //Link it back
                    prev = new_cell;
                    prev->right = new_cell;
                }
                new_cell->left = prev;
                new_cell->right = prev->right;
                new_cell->right->left = new_cell;
                prev->right = new_cell;
                new_cell->head = col_head;
                new_cell->down = col_head;
                new_cell->up = col_head->up;
                col_head->up->down = new_cell;
                col_head->size++;
                col_head->up = new_cell;
                if (col_head->down == col_head)
                    col_head->down = new_cell;
                prev = new_cell;
            }
        }
    }

    RootCell = root;
}

void set_question(int question[9][9])
{
    int index = 0;
    for (int i = 0; i < 9; i++)
        for (int j = 0; j < 9; j++)
            if (question[i][j] > 0)
            {
                Cell *col_head = NULL;
                Cell *tmp = NULL;
                for (col_head = RootCell->right; col_head != RootCell; col_head = col_head->right)
                {
                    for (tmp = col_head->down; tmp != col_head; tmp = tmp->down)
                        if (tmp->cell_id[0] == question[i][j] && (tmp->cell_id[1] - 1) == i && (tmp->cell_id[2] - 1) == j)
                            goto found;
                }
            found:
                hide_col(col_head);
                original[index] = tmp;
                index++;
                for (auto cell = tmp->right; cell != tmp; cell = cell->right)
                {
                    hide_col(cell->head);
                }
            }
}

void solve(int question[9][9])
{
    init_constraints(constraints);
    init_dancing_links(constraints);
    set_question(question);
    search_for_solution(0);
}

void read_question(int question[9][9])
{
    for (int x = 0; x < 9; x++)
    {
        for (int y = 0; y < 9; y++)
        {
            char in;
            std::cin >> in;
            if (in == '-')
            {
                question[x][y] = 0;
            }
            else
            {
                question[x][y] = int(in - '0');
            }
        }
    }
}
//Solver End

int main()
{
start:
    int op;
    std::cin >> op;
    switch (op)
    {
    case 1:
        form_soduko();
        break;
    case 2:
        int question[9][9];
        read_question(question);
        solve(question);
        if (solution_count == 0)
        {
            std::cout << "No_solution" << std::endl;
        }
        else if (solution_count == 1)
        {
            std::cout << "OK" << std::endl;
            std::cout << solution_string[0];
        }
        else if (solution_count == 2)
        {
            std::cout << "Multiple_solutions" << std::endl;
            std::cout << solution_string[0] << std::endl;
            std::cout << solution_string[1];
        }
    }
    return 0;
}