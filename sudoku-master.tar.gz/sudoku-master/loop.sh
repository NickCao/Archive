#!/bin/bash
echo "2" > data.tmp
echo 1 | ./sudoku >> data.tmp
cat data.tmp | ./sudoku
rm data.tmp
