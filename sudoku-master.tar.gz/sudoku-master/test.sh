#!/bin/bash
./case0.sh | ./sudoku
./case1.sh | ./sudoku
./loop.sh
./loop.sh
