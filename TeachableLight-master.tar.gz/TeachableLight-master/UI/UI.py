#!/usr/bin/python3
# coding=utf-8
import os
import threading
import gi
import redis
import time

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
from gi.repository import GLib
redis_server = 'localhost'
redis_port = 6379
redis_db = 0


class Mockr(object):
    def __init__(self):
        pass
    def set(self, key, value):
        pass
    def get(self, key):
        return b'default'

try:
    test = os.environ["TEST"]
except Exception:
    test = '0'

if test == '1':
    r = Mockr()
else:
    print("Connecting, wait a minute")
    r = redis.StrictRedis(host=redis_server, port=redis_port, db=redis_db)
    print("Connected")
    r.set('desb', '0')
    r.set('auto', '0')
    r.set('user', 'default')
    r.set('switch', '0')


# noinspection PyUnusedLocal
class Handler:
    @staticmethod
    def onDeleteWindow(*args):
        try:
            pass
        finally:
            r.set('desb', '0')
            r.set('auto', '0')
            r.set('switch', '0')
            Gtk.main_quit(*args)

    @staticmethod
    def switch(switch, state):
        r.set('switch', '1' if state else '0')
        print("Switch:" + ("On" if state else "Off"))

    @staticmethod
    def auto(switch, state):
        r.set('auto', '1' if state else '0')
        print("Auto:" + ("On" if state else "Off"))

    @staticmethod
    def bri(adj):
        v = int(adj.get_value())
        r.set('desb', str(v))
        print("Brightness:" + str(v))


builder = Gtk.Builder()
builder.add_from_file(os.path.dirname(os.path.realpath(__file__)) + "/TeachableLight.glade")
builder.connect_signals(Handler())
window = builder.get_object("mainwindow")
window.show_all()

textview = builder.get_object("textview")
buffer = Gtk.TextBuffer()
textview.set_buffer(buffer)

def bset():
    try:
        buffer.set_text(r.get("user").decode())
    except Exception:
        exit(0)
def update_buffer():
    while True:
        GLib.idle_add(bset)
        time.sleep(0.5)

t = threading.Thread(target=update_buffer)
t.setDaemon(True)
t.start()
Gtk.main()
