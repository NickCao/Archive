# coding=utf-8
import os
import shutil

import numpy as np
import tensorflow as tf


class Network(object):
    def __init__(self, user='default'):
        self.user = str(user)
        envb = tf.feature_column.numeric_column('envb')
        if not (os.path.exists('./models/model-' + self.user)):
            shutil.copytree('./models/model-template', './models/model-' + self.user)
        self.estimator = tf.estimator.DNNRegressor(
            feature_columns=[envb],
            hidden_units=[5, 10, 15, 10, 5],
            dropout=0.01,
            model_dir='./models/model-' + self.user
        )
        print(self.user + "'s network initialized")

    def train(self, envb, desb):
        train_input_fn = tf.estimator.inputs.numpy_input_fn(
            x={"envb": np.array([envb])},
            y=np.array([desb]),
            batch_size=1,
            num_epochs=10,
            shuffle=True)
        self.estimator.train(input_fn=train_input_fn, steps=5)
        print(self.user + "'s network trained: " + str([envb, desb]))

    def predict(self, envb):
        predict_input_fn = tf.estimator.inputs.numpy_input_fn(
            x={"envb": np.array([envb])},
            shuffle=False)
        res = round(float(list(self.estimator.predict(input_fn=predict_input_fn))[0]['predictions']))
        print(self.user + "'s network predicted: " + str([envb, res]))
        return res

    def _pretrain(self):
        train_input_fn = tf.estimator.inputs.numpy_input_fn(
            x={"envb": np.array(range(0, 101))},  # Input features
            y=np.array(range(100, -1, -1)),  # Output
            batch_size=100,
            num_epochs=20,
            shuffle=True)
        self.estimator.train(input_fn=train_input_fn, steps=5)
        print("network pretrained")
