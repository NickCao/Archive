# coding=utf-8
import os

import cv2
import face_recognition


class Recognizer(object):

    def __init__(self):
        self.known_users_encoding = {}
        for known_user_jpg in os.listdir('./users/known/'):
            known_user_id = str(known_user_jpg.split('.')[0])
            known_user_face = face_recognition.load_image_file("./users/known/" + known_user_id + ".jpg")
            encoding = face_recognition.face_encodings(known_user_face)
            self.known_users_encoding[known_user_id] = encoding[0]
        self.vc = cv2.VideoCapture(0)

    def __del__(self):
        self.vc.release()

    def recognize(self):
        _, frame = self.vc.read()
        cv2.imwrite('./users/unknown.jpg', frame)
        unknown_user_face = face_recognition.load_image_file("./users/unknown.jpg")
        try:
            unknown_user_encoding = face_recognition.face_encodings(unknown_user_face)[0]
        except IndexError:
            return None
        midres = {}
        for known_user_id in self.known_users_encoding:
            distance = face_recognition.face_distance([self.known_users_encoding[known_user_id]], unknown_user_encoding)
            midres[known_user_id] = distance
        shortest_distance = -1
        match = -1
        for id in midres:
            if shortest_distance == -1:
                shortest_distance = midres[id][0]
                match = id
            elif midres[id][0] < shortest_distance:
                shortest_distance = midres[id][0]
                match = id
        return match
