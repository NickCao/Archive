# coding=utf-8
import os

import FaceRecognition as fr
import NeuralNetwork as nn
import redis
import serial


class Mockserial(object):
    def __init__(self):
        self.data = 0

    def write(self, data):
        pass

    def readline(self):
        self.data += 1
        return bytes(str(self.data))


redis_server = str(os.environ['REDIS_SERVER'])
redis_port = int(os.environ['REDIS_PORT'])
redis_db = 0
test = str(os.environ['TEST'])

print("Connecting, wait a minute")
r = redis.StrictRedis(host=redis_server, port=redis_port, db=redis_db)
print("Connected")

if test == '1':
    ser = Mockserial()
else:
    ser = serial.Serial("/dev/arduino")

recognizer = fr.Recognizer()
networks = {}
# noinspection PyBroadException
while not (r.get('switch') == b'0'):
    pass

print("Ready")
user = 'default'
try:
    while True:
        new_user = recognizer.recognize()
        if new_user == None:
            pass
        else:
            user = new_user
        r.set('user', user)
        print("User: "+user)
        try:
            network = networks[user]
        except KeyError:
            networks[user] = nn.Network(user)
        ser.write(b'envb\n')
        # noinspection PyBroadException
        try:
            # noinspection PyUnresolvedReferences
            envb = int(ser.readline().decode())
        except Exception:
            envb = 0
        if r.get('switch') == b'1':
            if r.get('auto') == b'1':
                desb = str(network.predict(envb))
                ser.write(b'desb\n')
                ser.write(bytes(desb + '\n', encoding='UTF-8'))
            else:
                desb = int(r.get('desb').decode())
                ser.write(b'desb\n')
                ser.write(bytes(str(desb) + '\n', encoding='UTF-8'))
                network.train(envb, desb)
        else:
            ser.write(b'desb\n')
            ser.write(b'0\n')
except KeyboardInterrupt:
    exit(0)
