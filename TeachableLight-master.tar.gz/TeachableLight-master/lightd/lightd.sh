./redis-server --protected-mode no &
python3 lightd.py

