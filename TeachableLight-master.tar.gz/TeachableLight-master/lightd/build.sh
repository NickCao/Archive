#!/bin/sh
docker tag lightd:latest lightd:old
docker build --compress  --network host --rm -t lightd:latest .
docker rmi lightd:old
