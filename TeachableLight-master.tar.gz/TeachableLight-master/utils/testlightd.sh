#!/bin/sh
docker run -it --rm -v /home/$USER/TeachableLight/lightd/models:/opt/lightd/models \
    -v /home/$USER/TeachableLight/lightd/users:/opt/lightd/users --device /dev/video0:/dev/video0 -p 6379:6379 lightd:latest
