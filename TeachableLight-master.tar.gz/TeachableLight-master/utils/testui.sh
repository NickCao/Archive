#!/bin/sh
export TEST=1
cd /home/$USER/TeachableLight/UI/
./UI.py
