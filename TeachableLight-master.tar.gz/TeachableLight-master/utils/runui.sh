#!/bin/sh
cd /home/$USER/TeachableLight/UI/
./UI.py
