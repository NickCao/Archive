package main

import (
	"log"
	"net"
	"strconv"

	"github.com/gotk3/gotk3/gtk"
)

func main() {
	gtk.Init(nil)
	win, err := gtk.WindowNew(gtk.WINDOW_TOPLEVEL)
	if err != nil {
		log.Fatal(err)
	}
	win.SetTitle("lsitf")
	win.Connect("destroy", func() {
		gtk.MainQuit()
	})
	textView, err := gtk.TextViewNew()
	if err != nil {
		log.Fatal(err)
	}
	textView.SetCursorVisible(false)
	textView.SetEditable(false)
	buf, err := textView.GetBuffer()
	if err != nil {
		log.Fatal(err)
	}
	buf.SetText(getItfInfo())
	win.Add(textView)
	win.ShowAll()
	gtk.Main()
}

func getItfInfo() string {
	itfs, err := net.Interfaces()
	if err != nil {
		return err.Error()
	}
	var info string
	for j, itf := range itfs {
		info += "index: "
		info += strconv.Itoa(itf.Index)
		info += "\n"

		info += "name: "
		info += itf.Name
		info += "\n"

		info += "mtu: "
		info += strconv.Itoa(itf.MTU)
		info += "\n"

		info += "mac: "
		info += itf.HardwareAddr.String()
		info += "\n"

		info += "flags: "
		info += itf.Flags.String()
		info += "\n"

		info += "addrs: "
		addrs, err := itf.Addrs()
		if err != nil {
			return err.Error()
		}
		for i, addr := range addrs {
			info += addr.String()
			if i < len(addrs)-1 {
				info += "\n               "
			}
		}
		if j < len(itfs)-1 {
			info += "\n-----------------------------------\n"
		}
	}
	return info
}
