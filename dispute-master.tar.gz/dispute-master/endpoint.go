package dispute

import (
	"errors"
	"net"

	"github.com/google/gopacket"

	"github.com/google/gopacket/layers"

	"github.com/google/gopacket/afpacket"
)

//Endpoint the cental, the origin
type Endpoint struct {
	tPkt      *afpacket.TPacket
	sMAC      net.HardwareAddr
	dMAC      net.HardwareAddr
	sIP       net.IP
	dIP       net.IP
	layerETH  *layers.Ethernet
	layerIPv6 *layers.IPv6
	serOpt    gopacket.SerializeOptions
}

//NewEndpoint the varible names should have explained all
func NewEndpoint(itfname string, gatewaymac string, sip string, dip string) (*Endpoint, error) {
	var err error
	var e = &Endpoint{}
	e.tPkt, err = afpacket.NewTPacket(afpacket.OptInterface(itfname), afpacket.SocketRaw)
	if err != nil {
		return nil, err
	}

	var itf *net.Interface
	itf, err = net.InterfaceByName(itfname)
	if err != nil {
		return nil, err
	}
	e.sMAC = itf.HardwareAddr

	e.dMAC, err = net.ParseMAC(gatewaymac)
	if err != nil {
		return nil, err
	}

	e.dIP = net.ParseIP(dip)
	if e.dIP == nil {
		return nil, errors.New("error in parsing dest ip")
	}

	e.sIP = net.ParseIP(sip)
	if e.sIP == nil {
		return nil, errors.New("error in parsing src ip")
	}

	e.serOpt = gopacket.SerializeOptions{
		FixLengths: true,
	}

	e.RefreshLayers()
	return e, nil
}

//RefreshLayers update the layers to serialize
func (e *Endpoint) RefreshLayers() {
	e.layerETH = &layers.Ethernet{
		SrcMAC:       e.sMAC,
		DstMAC:       e.dMAC,
		EthernetType: layers.EthernetTypeIPv6,
	}
	e.layerIPv6 = &layers.IPv6{
		Version:      6,
		TrafficClass: 0, //TODO: who can tell me what i should fill in this field
		FlowLabel:    0,
		Length:       0,
		NextHeader:   146,
		HopLimit:     64,
		SrcIP:        e.sIP,
		DstIP:        e.dIP,
	}
	return
}

//WritePacket write a packet to the interface
func (e *Endpoint) WritePacket(b []byte) error {
	buf := gopacket.NewSerializeBuffer()
	var err error
	err = gopacket.SerializeLayers(buf, e.serOpt, e.layerETH, e.layerIPv6, gopacket.Payload(b))
	if err != nil {
		return err
	}

	err = e.tPkt.WritePacketData(buf.Bytes())
	if err != nil {
		return err
	}

	return nil
}

//ReadPacket read a packet from the interface
func (e *Endpoint) ReadPacket() ([]byte, error) {
	return []byte{}, nil //TODO: stub, to fix
}

//Close don`t forget to call it
func (e *Endpoint) Close() {
	e.tPkt.Close()
	return
}
