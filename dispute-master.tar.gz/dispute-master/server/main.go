package main

import (
	"log"

	"flag"

	"github.com/google/gopacket"
	"github.com/google/gopacket/afpacket"
	"github.com/google/gopacket/layers"
)

var iface = flag.String("i", "wlp7s0", "the interface to listen on")

func main() {
	flag.Parse()

	var err error
	var tpkt *afpacket.TPacket
	var itf = afpacket.OptInterface(*iface)
	var skt afpacket.OptSocketType = afpacket.SocketRaw
	tpkt, err = afpacket.NewTPacket(itf, skt)
	if err != nil {
		log.Fatal("af new: " + err.Error())
	}
	defer tpkt.Close()

	err = tpkt.InitSocketStats()
	if err != nil {
		log.Fatal("init socket: " + err.Error())
	}

	var data []byte
	var eth layers.Ethernet
	var ip6 layers.IPv6
	pkt := []gopacket.LayerType{}
	parser := gopacket.NewDecodingLayerParser(layers.LayerTypeEthernet, &eth, &ip6)
	for true {
		data, _, err = tpkt.ZeroCopyReadPacketData()
		if err != nil {
			log.Println("read packet: " + err.Error())
			continue
		}
		err := parser.DecodeLayers(data, &pkt)
		if err != nil {
			//log.Print("decode packet: " + err.Error())
			//Ignoring the errors for they are bound to occur
		}
		for _, l := range pkt {
			if l == layers.LayerTypeIPv6 {
				if int(ip6.NextHeader) == 146 {
					log.Print(string(ip6.Payload))
				}
				break
			}
		}

	}
}
