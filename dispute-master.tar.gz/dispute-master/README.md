# dispute

What if we go down to the IP layer

This project has reached its EoL
Though it's still WIP
And there are mainly two reasons:
0. Better evasion strategy exists, namely corelated-freedom
1. I failed to find a reliabe and effective way to determine the MAC addr of the gateway
2. The protocol is still subject to DPI
