## Portal - A way out

The portal, to the outside world