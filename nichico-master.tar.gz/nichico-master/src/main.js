import Vue from 'vue'
import VueRouter from 'vue-router'
import './plugins/vuetify'
import App from './App.vue'
import Home from './components/Home.vue'
import Timeline from './components/Timeline.vue'
import NotFound from './components/NotFound.vue'
import Blog from './components/Blog.vue'
import Callback from './components/Callback.vue'
import Commit from './components/Commit.vue'

import axios from 'axios'
import VueAxios from 'vue-axios'
import auth0 from 'auth0-js'

Vue.config.productionTip = false
Vue.use(VueRouter)
Vue.use(VueAxios, axios)
Vue.prototype.$auth = new auth0.WebAuth({
  domain: 'runtimepanic.auth0.com',
  clientID: '3Y74ARgp9ZMa55SGdwV716xfT6aUH1ag',
  redirectUri: window.location.origin + '/',
  responseType: 'token id_token',
  scope: 'openid',
  audience: 'timeline'
})

const router = new VueRouter({
  routes: [
    {
      path: '/',
      component: Home
    },
    {
      path: '/timeline',
      component: Timeline
    },
    {
      path: '/blog',
      component: Blog
    },
    {
      path: '/commit',
      component: Commit
    },
    {
      path: '/access_token*',
      component: Callback
    },
    {
      path: '*',
      component: NotFound
    }
  ]
})

new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
