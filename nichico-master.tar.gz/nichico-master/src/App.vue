<template>
  <v-app>
    <v-navigation-drawer app clipped v-model="drawer.open">
      <v-list>
        <v-list-tile v-on:click="backtoHome">
          <v-list-tile-action>
            <v-icon>dashboard</v-icon>
          </v-list-tile-action>
          <v-list-tile-content>
            <v-list-tile-title>Home</v-list-tile-title>
          </v-list-tile-content>
        </v-list-tile>

        <v-divider></v-divider>

        <v-list-tile v-on:click="toTimeline">
          <v-list-tile-action>
            <v-icon>timeline</v-icon>
          </v-list-tile-action>
          <v-list-tile-content>
            <v-list-tile-title>Timeline</v-list-tile-title>
          </v-list-tile-content>
        </v-list-tile>

        <v-divider></v-divider>

        <v-list-tile v-on:click="toBlog">
          <v-list-tile-action>
            <v-icon>ballot</v-icon>
          </v-list-tile-action>
          <v-list-tile-content>
            <v-list-tile-title>Blog</v-list-tile-title>
          </v-list-tile-content>
        </v-list-tile>

        <v-divider></v-divider>
        <v-list-tile v-on:click="openGitlab">
          <v-list-tile-action>
            <v-icon>code</v-icon>
          </v-list-tile-action>
          <v-list-tile-content>
            <v-list-tile-title>Gitlab</v-list-tile-title>
          </v-list-tile-content>
        </v-list-tile>

        <v-divider></v-divider>

        <v-list-tile v-on:click="sendMail">
          <v-list-tile-action>
            <v-icon>email</v-icon>
          </v-list-tile-action>
          <v-list-tile-content>
            <v-list-tile-title>Email</v-list-tile-title>
          </v-list-tile-content>
        </v-list-tile>

        <v-divider></v-divider>

        <v-list-tile v-on:click="openTelegram">
          <v-list-tile-action>
            <v-icon>message</v-icon>
          </v-list-tile-action>
          <v-list-tile-content>
            <v-list-tile-title>Telegram</v-list-tile-title>
          </v-list-tile-content>
        </v-list-tile>
        <v-divider></v-divider>
        <v-list-tile v-on:click="login">
          <v-list-tile-action>
            <v-icon>account_box</v-icon>
          </v-list-tile-action>
          <v-list-tile-content>
            <v-list-tile-title class="grey--text">Login</v-list-tile-title>
          </v-list-tile-content>
        </v-list-tile>
        <v-divider></v-divider>
      </v-list>
    </v-navigation-drawer>

    <v-toolbar dark color="primary" app clipped-left>
      <v-toolbar-side-icon v-on:click="toggleDrawer"></v-toolbar-side-icon>
      <v-toolbar-title>Nick's Nichijou</v-toolbar-title>
    </v-toolbar>
    <v-content>
      <router-view></router-view>
    </v-content>
  </v-app>
</template>

<script>
export default {
  name: "App",
  data: () => ({
    drawer: {
      open: false
    }
  }),
  methods: {
    toggleDrawer() {
      this.drawer.open = !this.drawer.open;
    },
    openGitlab() {
      window.open("https://gitlab.com/users/NickCao/projects");
      this.drawer.open = false;
    },
    backtoHome() {
      this.$router.push("/");
      this.drawer.open = false;
    },
    toTimeline() {
      this.$router.push("/timeline");
      this.drawer.open = false;
    },
    toBlog() {
      this.$router.push("/blog");
      this.drawer.open = false;
    },
    sendMail() {
      window.open("mailto:nickcao@riseup.net");
      this.drawer.open = false;
    },
    openTelegram() {
      window.open("https://t.me/NickCao/");
      this.drawer.open = false;
    },
    login() {
      this.$auth.authorize();
    }
  }
};
</script>
