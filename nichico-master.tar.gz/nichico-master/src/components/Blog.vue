<template>
  <v-container fill-height>
    <v-layout fill-height>
      <v-flex xs12 fill-height>
        <iframe src="https://runtimepanic.xyz" class="f"></iframe>
      </v-flex>
    </v-layout>
  </v-container>
</template>

<script>
export default {
  data: () => ({
    banner: require("@/assets/img/banner.jpg")
  }),
  methods: {
    backtoHome() {
      this.$router.push("/");
      this.drawer.open = !this.drawer.open;
    }
  }
};
</script>

<style>
.f {
  border: none;
  width: 100%;
  height: 100%;
}
</style>
