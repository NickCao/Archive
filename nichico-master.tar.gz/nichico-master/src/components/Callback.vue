<template>
  <div></div>
</template>

<script>
export default {
  created() {
    this.$auth.parseHash(function(err, res) {
      if (!err) {
        sessionStorage.setItem("itoken", res.idToken);
        sessionStorage.setItem("atoken", res.accessToken);
        sessionStorage.setItem("sub", res.idTokenPayload.sub);
      }
    });
    this.$router.push("/commit");
  }
};
</script>

<style>
</style>