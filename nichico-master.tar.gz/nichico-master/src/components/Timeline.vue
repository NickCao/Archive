<template>
  <v-container grid-list-lg>
    <v-layout wrap justify-center>
      <v-flex xs12 sm11 lg10>
        <v-card>
          <v-img v-bind:src="banner2" aspect-ratio="2.75"></v-img>
          <v-card-text>
            <div class="body-2 w">这个所谓的Timeline也就是一个像Twitter一样的日志啦</div>
            <div class="body-2 w">不定期更新(大概会比博客频繁一些...大概?...)</div>
          </v-card-text>
        </v-card>
      </v-flex>
      <v-flex xs12 sm11 lg10 v-for="post in posts" v-bind:key="post">
        <v-card>
          <v-card-text>
            <span class="body-2 w" v-for="tag in post.Tags" v-bind:key="tag">#{{tag}} &nbsp;</span>
            <div class="body-2 w">{{post.Body}}</div>
          </v-card-text>
          <v-layout align-center justify-end mr-2>
            <v-card-actions>
              <div class="caption w grey--text">{{post.ID}}</div>
            </v-card-actions>
          </v-layout>
        </v-card>
      </v-flex>
    </v-layout>
  </v-container>
</template>

<script>
export default {
  data: () => ({
    banner2: require("@/assets/img/banner2.jpg"),
    posts: [
      {
        Author: "NickCao",
        Tags: ["Load", "ing....."],
        Body: "heroku真垃圾...",
        ID: "01D3QN6WAE9R3JTVW4E81D8WJ6"
      }
    ]
  }),
  mounted() {
    this.axios
      .get("https://starliner-nickcao.herokuapp.com/timeline/16")
      .then(response => {
        this.posts = response.data;
      });
  }
};
</script>

<style>
.w {
  word-wrap: break-word;
}
</style>
