<template>
  <v-container>
    <v-layout justify-center>
      <v-flex xs12 sm11 lg10>
        <v-card>
          <v-img v-bind:src="banner" aspect-ratio="2.75"></v-img>
          <v-card-text>
            <div class="body-2 w">这就是Nick的个人站点啦</div>
            <div class="body-2 w">(后端狗强行凑出的SPA......)</div>
            <div class="body-2 w">目前还只是个Work in Progress，没多少内容</div>
            <div class="body-2 w">但你可以看看blog(deprecated)，也可以刷刷timeline....</div>
            <div class="body-2 w">BTW, I use Arch....</div>
          </v-card-text>
          <v-card-actions>
            <v-btn flat color="orange" v-on:click="toBlog">Blog</v-btn>
            <v-btn flat color="blue" v-on:click="toTimeline">Timeline</v-btn>
          </v-card-actions>
        </v-card>
      </v-flex>
    </v-layout>
  </v-container>
</template>

<script>
export default {
  data: () => ({
    banner: require("@/assets/img/banner.jpg")
  }),
  methods: {
    toTimeline() {
      this.$router.push("/timeline");
      this.drawer.open = false;
    },
    toBlog() {
      this.$router.push("/blog");
      this.drawer.open = false;
    }
  }
};
</script>

<style>
.w {
  word-wrap: break-word;
}
</style>
