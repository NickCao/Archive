<template>
  <v-container grid-list-md>
    <v-layout>
      <v-flex>
        <v-card>
          <v-card-text>
            <form>
              <v-layout row wrap>
                <v-flex>
                  <v-text-field v-model="author" label="Author" required box></v-text-field>
                </v-flex>
                <v-flex>
                  <v-text-field v-model="tags" label="Tags" required box></v-text-field>
                </v-flex>
              </v-layout>
              <v-layout>
                <v-flex>
                  <v-textarea v-model="body" label="Body" required box auto-grow></v-textarea>
                </v-flex>
              </v-layout>
              <v-btn v-on:click="submit">submit</v-btn>
            </form>
          </v-card-text>
        </v-card>
      </v-flex>
    </v-layout>
  </v-container>
</template>

<script>
var querystring = require("querystring");
export default {
  data: () => ({
    body: undefined,
    author: undefined,
    tags: undefined
  }),
  methods: {
    submit() {
      var tagarray = this.tags.split(",");
      this.axios
        .post(
          "https://cors-anywhere.herokuapp.com/https://starliner-nickcao.herokuapp.com/commit",
          querystring.stringify({
            author: this.author,
            tags: tagarray,
            body: this.body
          }),
          {
            headers: {
              Authorization: "Bearer " + sessionStorage.getItem("itoken")
            }
          }
        )
        .then(function(response) {
          alert(response);
        })
        .catch(function(error) {
          alert(error);
        });
    }
  }
};
</script>

<style>
</style>
