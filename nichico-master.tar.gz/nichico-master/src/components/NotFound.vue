<template>
  <v-container>
    <v-layout justify-center>
      <v-flex xs12 sm11 lg10>
        <v-card>
          <v-img v-bind:src="banner" aspect-ratio="2.75"></v-img>

          <v-card-title>
            <div>
              <span class="title grey--text">404</span>
              <br>
              <span class="body-2">This page is not found....</span>
            </div>
          </v-card-title>
          <v-card-actions>
            <v-btn flat color="orange" v-on:click="backtoHome">Back to Home</v-btn>
          </v-card-actions>
        </v-card>
      </v-flex>
    </v-layout>
  </v-container>
</template>

<script>
export default {
  data: () => ({
    banner: require("@/assets/img/banner.jpg")
  }),
  methods: {
    backtoHome() {
      this.$router.push("/");
      this.drawer.open = !this.drawer.open;
    }
  }
};
</script>

<style>
</style>
